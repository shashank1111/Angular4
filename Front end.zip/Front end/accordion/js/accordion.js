function toggleChevron(e) {
    $(e.target)
        .prev('.panel-heading')
        .find("i.indicator")
        .toggleClass('glyphicon-menu-down glyphicon-menu-up');
}
$('#accordion1').on('hidden.bs.collapse', toggleChevron);
$('#accordion1').on('shown.bs.collapse', toggleChevron);



$('.closeall').click(function(){
  $('.panel-collapse.in')
    .collapse('hide');
});
$('.openall').click(function(){
  $('.panel-collapse:not(".in")')
    .collapse('show');
});



var data = {
	items: [
    {id: "title1", href: "https://sdnet2013.hosting.deloitte.com/sites/FY17NCReport/Pages/Nominating_Committee_Develop_Candidate_Short_List.aspx"},
    {id: "title5", href: "https://sdnet2013.hosting.deloitte.com/sites/FY17NCReport/Pages/Candidate_Interviews_And_Deliberations.aspx"}
]};

// $(document).ready(function(){
// 	var obj = data.items;
// 	window.location.href = "https://sdnet2013.hosting.deloitte.com/sites/FY17NCReport/Pages/Default.aspx";
// });

$('.panel-title a').on('click', function () {
    var id = this.id;
    var location = window.location.href;
    var obj = data.items;

    for(var i=0 ; i< obj.length ; i++){
    	var objId = obj[i].id;
    	var objHref = obj[i].href;
    	if( objId === id ){ 
    		window.location.href = objHref;
    	}
    }
});