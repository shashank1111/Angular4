angular.module('Acordion', ['ui.bootstrap']);
function AccordionDemoCtrl($scope) {

  $scope.groups = [
    {
      title: "FY17 Nominating Committee Selected",
      items: [{"item-title": "Peter Jackson"}, {"item-title": "Pallav Jackson"}]
    },
    {
      title: "Survey Launched / Interviews Begin",
      items: [{"item-title": "Partner, Principal, Managing Director"}, {"item-title": "Location"}, {"item-title": "Tenure"}, {"item-title": "Gender"}, {"item-title": "Diversity"}]
    },
    {
      title: "Close Survey / Interview End",
      items: [{"item-title": "Six Imperatives"}, {"item-title": "Location"}, {"item-title": "Tenure"}, {"item-title": "Gender"}, {"item-title": "Diversity"}]
    }
  ];
}
