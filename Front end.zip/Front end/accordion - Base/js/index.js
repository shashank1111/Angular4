// <script>

// $(document).on("click","a",function(e){
//    var element =e.target;
//     $.ajax({
//         url: "",
//         type: "POST",
//         data: {'id':$(element).attr("id")}
//     });

// </script>