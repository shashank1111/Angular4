﻿$(document).ready(function () {
    $('#Video1').mouseover(function () {
        $('#Video1a').css('display', 'block');
        $('#Video2a').css('display', 'none');
        $('#Video3a').css('display', 'none');
        $('#Video1active').addClass("active");
        $('#Video2active').removeClass("active");
        $('#Video3active').removeClass("active");
    });
    $('#Video2').mouseover(function () {
        $('#Video1a').css('display', 'none');
        $('#Video2a').css('display', 'block');
        $('#Video3a').css('display', 'none');
        $('#Video2active').addClass("active");
        $('#Video1active').removeClass("active");
        $('#Video3active').removeClass("active");

    });
    $('#Video2').mouseout(function () {
        $('#Video1active').removeClass("active");
        $('#Video2active').addClass("active");
        $('#Video3active').removeClass("active");
        $('#Video1a').css('display', 'none');
        $('#Video2a').css('display', 'block');
        $('#Video3a').css('display', 'none');
    });
    $('#Video3').mouseover(function () {
        $('#Video1a').css('display', 'none');
        $('#Video2a').css('display', 'none');
        $('#Video3a').css('display', 'block');
        $('#Video3active').addClass("active");
        $('#Video1active').removeClass("active");
        $('#Video2active').removeClass("active");
    });
    $('#Video3').mouseout(function () {
        $('#Video1active').removeClass("active");
        $('#Video3active').addClass("active");
        $('#Video2active').removeClass("active");
        $('#Video1a').css('display', 'none');
        $('#Video2a').css('display', 'none');
        $('#Video3a').css('display', 'block');
    });

    
    $("#videoCarousel").swiperight(function() {  
        $(this).carousel('prev');  
    });  

    $("#videoCarousel").swipeleft(function() {  
        $(this).carousel('next');  
    });   
});