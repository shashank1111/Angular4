function RatingVideo() {	
	this.listId = "F98D7D8D-4002-4A17-A6B7-9FC70AD16C41";
	this.title = "Video";
}

// Video Like Functionality Input: VideoID
RatingVideo.prototype.likeVideo = function likeVideo(videoId, callbackSuccess, callbackFail) {
    var liked = true;
    this.registerActionLikeVideo(videoId, liked, callbackSuccess, callbackFail);
	callbackSuccess();    
}

//Video Unlike Functionality Input: VideoID
RatingVideo.prototype.unLikeVideo = function unLikeVideo(videoId, callbackSuccess, callbackFail) {
    var liked = false;
	this.registerActionLikeVideo(videoId, liked, callbackSuccess, callbackFail);
	callbackFail();
    
}

RatingVideo.prototype.registerActionLikeVideo = function registerActionLikeVideo(videoId, liked, callbackSuccess, callbackFail) {
	console.log(this.title);
	console.log(this.listId);
}

//Get Ratings Count Input: VideoID
RatingVideo.prototype.getRating = function getRating(videoId, callbackSuccess, callbackFail) {
        //Json Output 
        var output = {
            VideoId: videoId,
            NumOfLikes: 9,
            IsUserLiked: true
        };
		console.log(output);		
}