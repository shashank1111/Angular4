﻿AuthRedirect();

function AuthRedirect() {
   
    var HostUrl = window.location.host;
    if (HostUrl.split(".", 1) == 'ddnet2013') {
        var ExternalLinksRedirect = {
            "ADFSURL": "https://dauth.us.deloitte.com/adfs/ls/?wa=wsignin1.0&wtrealm=https%3a%2f%2fdgreenroomapp.deloitte.com&wctx=rm%3d1%26id%3dpassive%26ru%3d%252fadfslanding%253fredirect%253d"
        };

    } else if (HostUrl.split(".", 1) == 'qdnet2013') {

        var ExternalLinksRedirect = {
            "ADFSURL": "https://qauth.us.deloitte.com/adfs/ls/?wa=wsignin1.0&wtrealm=https%3a%2f%2fqgreenroomapp.deloitte.com&wctx=rm%3d1%26id%3dpassive%26ru%3d%252fadfslanding%253fredirect%253d"
        };

    } else if (HostUrl.split(".", 1) == 'sdnet2013') {
        var ExternalLinksRedirect = {
            "ADFSURL": "https://dttstsstage.deloitteresources.com/adfs/ls/?wa=wsignin1.0&wtrealm=https%3a%2f%2fsgreenroomapp.deloitte.com&wctx=rm%3d1%26id%3dpassive%26ru%3d%252fadfslanding%253fredirect%253d"
        };

    } else if (HostUrl.split(".", 1) == 'sdnet2') {
        var ExternalLinksRedirect = {
            "ADFSURL": "https://dttstsstage.deloitteresources.com/adfs/ls/?wa=wsignin1.0&wtrealm=https%3a%2f%2fsgreenroomapp.deloitte.com&wctx=rm%3d1%26id%3dpassive%26ru%3d%252fadfslanding%253fredirect%253d"
        };

    } else if (HostUrl.split(".", 1) == 'ldnet2') {
        var ExternalLinksRedirect = {
            "ADFSURL": "https://lauth.us.deloitte.com/adfs/ls/?wa=wsignin1.0&wtrealm=https%3a%2f%2flgreenroomapp.deloitte.com&wctx=rm%3d1%26id%3dpassive%26ru%3d%252fadfslanding%253fredirect%253d"
        };

    } else if (HostUrl.split(".", 1) == 'deloittenet') {
        var ExternalLinksRedirect = {
            "ADFSURL": "https://dttsts.deloitteresources.com/adfs/ls/?wa=wsignin1.0&wtrealm=https%3a%2f%2fgreenroomapp.deloitte.com&wctx=rm%3d1%26id%3dpassive%26ru%3d%252fadfslanding%253fredirect%253d"
        };
    }



    function setCookie(cname, cvalue) {
        document.cookie = cname + "=" + cvalue + ";";
    }

    function getCookie(cname) {
        var name = cname + "=";
        var ca = document.cookie.split(';');
        for (var i = 0; i < ca.length; i++) {
            var c = ca[i];
            while (c.charAt(0) == ' ') {
                c = c.substring(1);
            }
            if (c.indexOf(name) == 0) {
                return c.substring(name.length, c.length);
            }
        }
        return "";
    }

    function checkDDTAuthCookie() {
        
        var user = getCookie("DDTAuth");
        console.log("User :" + user)
        if (user == "") {
            setCookie("DDTAuth", "TRUE");

            // To fix the second query string parameter is getting trimmed off issue we have added 3 times "encodeURIComponent"

            currentURL = encodeURIComponent(encodeURIComponent(encodeURIComponent(document.location)));
            console.log("Before Redirection" + document.location);
            location.replace(ExternalLinksRedirect.ADFSURL + currentURL);
        }
    }

    checkDDTAuthCookie();
}
