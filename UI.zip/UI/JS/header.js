﻿var HostUrl = window.location.host;
if (HostUrl.split(".", 1) == 'ddnet2013') {
    var ExternalLinks = {
        "RatethisappURL": "https://dratethisapp.deloitte.com/rateThisAppService/api/ratethisapp",
        "AccesstokenURL": "https://ddnet2013.hosting.deloitte.com/_vti_bin/Deloitte.InstantFind/AccessTokenService.svc/Accesstoken",
        "InstantFindURL": "https://dapi.instantfind.deloittenet.deloitte.com/v1/_search?q=#Keywords#&group=true&limit=12",
        "DPNURL": "https://people.deloitteresources.com/profile/#Keywords#",
        "s_account": "DeloitteUS-deloitte-does-that-Dev",
    };

} else if (HostUrl.split(".", 1) == 'qdnet2013') {
    var ExternalLinks = {
        "RatethisappURL": "https://qratethisapp.deloitte.com/rateThisAppService/api/ratethisapp",
        "AccesstokenURL": "https://qdnet2013.hosting.deloitte.com/_vti_bin/Deloitte.InstantFind/AccessTokenService.svc/Accesstoken",
        "InstantFindURL": "https://qapi.instantfind.deloittenet.deloitte.com/v1/_search?q=#Keywords#&group=true&limit=12",
        "DPNURL": "https://people.deloitteresources.com/profile/#Keywords#",
        "s_account": "DeloitteUS-deloitte-does-that-Dev",
    };
} else if (HostUrl.split(".", 1) == 'sdnet2013') {
    var ExternalLinks = {
        "RatethisappURL": "https://sratethisapp.deloitte.com/rateThisAppService/api/ratethisapp",
        "AccesstokenURL": "https://sdnet2013.hosting.deloitte.com/_vti_bin/Deloitte.InstantFind/AccessTokenService.svc/Accesstoken",
        "InstantFindURL": "https://sapi.instantfind.deloittenet.deloitte.com/v1/_search?q=#Keywords#&group=true&limit=12",
        "DPNURL": "https://people.deloitteresources.com/profile/#Keywords#",
        "s_account": "DeloitteUS-deloitte-does-that-Dev",
    };

} else if (HostUrl.split(".", 1) == 'sdnet2') {
    var ExternalLinks = {
        "RatethisappURL": "https://sratethisapp.deloitte.com/rateThisAppService/api/ratethisapp",
        "AccesstokenURL": "https://sdnet2.hosting.deloitte.com/_vti_bin/Deloitte.InstantFind/AccessTokenService.svc/Accesstoken",
        "InstantFindURL": "https://sapi.instantfind.deloittenet.deloitte.com/v1/_search?q=#Keywords#&group=true&limit=12",
        "DPNURL": "https://people.deloitteresources.com/profile/#Keywords#",
        "s_account": "DeloitteUS-deloitte-does-that-Dev",
    };

} else if (HostUrl.split(".", 1) == 'deloittenet') {
    var ExternalLinks = {
        "RatethisappURL": "https://ratethisapp.deloitte.com/rateThisAppService/api/ratethisapp",
        "AccesstokenURL": "https://deloittenet.deloitte.com/_vti_bin/Deloitte.InstantFind/AccessTokenService.svc/Accesstoken",
        "InstantFindURL": "https://api.instantfind.deloittenet.deloitte.com/v1/_search?q=#Keywords#&group=true&limit=12",
        "DPNURL": "https://people.deloitteresources.com/profile/#Keywords#",
        "s_account": "DeloitteUS-deloitte-does-that",
    };
} else if (HostUrl.split(".", 1) == 'ldnet2') {
    var ExternalLinks = {
        "RatethisappURL": "https://lratethisapp.deloitte.com/rateThisAppService/api/ratethisapp",
        "AccesstokenURL": "https://ldnet2.hosting.deloitte.com/_vti_bin/Deloitte.InstantFind/AccessTokenService.svc/Accesstoken",
        "InstantFindURL": "https://lapi.instantfind.deloittenet.deloitte.com/v1/_search?q=#Keywords#&group=true&limit=12",
        "DPNURL": "https://people.deloitteresources.com/profile/#Keywords#",
        "s_account": "DeloitteUS-deloitte-does-that-Dev",
    };
}
var loggedInUser;
var User = [];
var UserImage;
var s_account = ExternalLinks.s_account;

$(document).ready(function () {
    var isEditMode = sessionStorage.getItem("EditMode");
    if (window.location.href.substr(window.location.href.lastIndexOf("=") + 1).split(".")[0] == "Design" || isEditMode == "true") {
        sessionStorage.setItem("EditMode", "true");
        $("#ms-designer-ribbon").css('display', 'block');
        $(".landing-header").css('display', 'none');
        $(".search").css('margin-top', '0px !important');
    }
    //For Removing Space
    jQuery('#s4-bodyContainer').html(jQuery('#s4-bodyContainer').html().replace(/\u200B/g, ''));
    // For Ominature Loading
    $.getScript(_spPageContextInfo.webAbsoluteUrl + "/Style Library/DDT App/JS/s_code.js")
    .done(function () {
        loggedInUser = _spPageContextInfo.systemUserKey.split('|')[2];  //currentUser.get_loginName().split('|')[2];
        TrackSiteClicks(loggedInUser);
    }).
     fail(function (jqxhr, settings, exception) {
         console.log('error loading s_code.js');
     });

});
$(window).load(function () {
    loggedInUser = _spPageContextInfo.systemUserKey.split('|')[2];
    HandleUserMenu();
    // To Do - 
    if ((window.location.hostname.split('.', 1)) == 'ddnet2013') {
        $(".dra-main-container").css("display", "none");
        $("#deloitteRateThisApp").css("display", "none");

    }
    // Sharepoint Page Scroll 
    $("#s4-workspace").scroll(function () {
        $(".ui-autocomplete").hide();
    })
    $(".menu-mobile").click(function () {
        $(".search").css("margin-top", "0px !important");
        $(".mobile-menulist").slideToggle();
        $(this).toggleClass("active");
        if($(".menu-mobile").hasClass("active") || $(".search-mobile").hasClass("active")){
          $("app-video-gallery").addClass("mobileHeader");
          $("app-breadcrumb").addClass("mobileHeader");
        }
        else if($(".menu-mobile").hasClass("active") && !$(".search-mobile").hasClass("active")){
          $("app-video-gallery").addClass("mobileHeader");
            $("app-breadcrumb").addClass("mobileHeader");
        }
         else if($(".menu-mobile").hasClass("active") && $(".search-mobile").hasClass("active")){
            $("app-video-gallery").addClass("mobileHeader");
            $("app-breadcrumb").addClass("mobileHeader");
        }
         else if(!$(".menu-mobile").hasClass("active") && !$(".search-mobile").hasClass("active")){
            $("app-video-gallery").removeClass("mobileHeader"); 
            $("app-breadcrumb").removeClass("mobileHeader");
        }
    });
    $(".search-mobile").click(function () {
        $(".mobile-search").slideToggle();
        $(this).toggleClass("active");
         if(!$(".menu-mobile").hasClass("active") && $(".search-mobile").hasClass("active")){
          $("app-video-gallery").addClass("mobileHeader");
            $("app-breadcrumb").addClass("mobileHeader");
        }
        else if($(".menu-mobile").hasClass("active") && !$(".search-mobile").hasClass("active")){
          $("app-video-gallery").addClass("mobileHeader");
            $("app-breadcrumb").addClass("mobileHeader");
        }
         else if($(".menu-mobile").hasClass("active") && $(".search-mobile").hasClass("active")){
            $("app-video-gallery").addClass("mobileHeader");
            $("app-breadcrumb").adddClass("mobileHeader");
        }
         else if(!$(".menu-mobile").hasClass("active") && !$(".search-mobile").hasClass("active")){
            $("app-video-gallery").removeClass("mobileHeader"); 
            $("app-breadcrumb").removeClass("mobileHeader");
        }
    });
    $("#searchm").click(function () {
        $(".searchmobile").slideToggle()
        $(this).toggleClass("active");
    });

    $('input[type="text"]').keyup(function () {
        var length = $(this).val().length
        if (length >= 1) {
            $(".cancel-icon").show();
        } else {
            $(".cancel-icon").hide();
        }
    })
    $(".cancel-icon").click(function () {
        $('input[type="text"]').val("")
        $(this).hide();
    })

    $('input[type="text"]').focus(function () {
        $(this).addClass("active");
        $(".search").addClass("active");
            $("app-main-search ul,app-head-search ul").show();
    });   
    $('input[type="text"]').keyup(function () {
        var length = $(this).val().length
        if (length >= 1) {
            $(".input-close").show();
        } else {
            $(".input-close").hide();
        }
    })
    $(".input-close").click(function () {
        $('input[type="text"]').val("")
        $(this).hide();
    })
    $('input[type="text"]').blur(function () {
        $(this).removeClass("active");
        $(".search").removeClass("active");
        setTimeout(function () {
            $("app-main-search ul,app-head-search ul").hide();
        }, 300);      
    });

});

$(document).ready(function () {

    if ($(window).width() < 767) {
        
        // For making input box cursor bliking inactive on iphones
        $('#s4-workspace').on('scroll', function () {
            var topMargin = ($(".search .search-title").offset().top);

            if ( topMargin < 8) {
                $(".search input").css("font-size", "0px");
            }
            else if ( topMargin > 8) {
                $(".search input").css("font-size", "16px");
            }
        });

        // For making page autoscroll to top on click of search button / hamburger on mobile header
        $('.menu-mobile,.search-mobile').on('click', function () {
            $('#s4-workspace').animate({ scrollTop: 0 }, 900);
            // On document load making font-size 16px
            $(".search input").css("font-size", "16px");
        });
    }
    
});

function HandleUserMenu() {
    if (window.sessionStorage) {
        User = JSON.parse(sessionStorage.getItem("User"));
        if (User == null) {
            GetLoggedInUserDetails();

        }
        else {
            UserImage = ("image" in User);
            UpdateUserMenuDetails();
        }
    }
    else {
        console.log("No Session Storage");
    }

    // Sharepoint Designer Menu
    SP.SOD.executeFunc('sp.js', 'SP.ClientContext', AddSharePointDesignerMenus);
    //Rate This App
    UpdateRateThisAppMenuDetails();
}
function GetLoggedInUserDetails() {
    // Authorization for Instant Find - Need to Verify 
    var accessToken;
    var accessTokenExpiration;

    jQuery.get(ExternalLinks.AccesstokenURL, function (response) {
        accessToken = response.token;
        accessTokenExpiration = response.expires;
        jQuery.ajax({
            url: ExternalLinks.InstantFindURL.replace('#Keywords#', loggedInUser),
            type: 'GET',
            beforeSend: function (xhr) {
                xhr.setRequestHeader("Authorization", "Bearer " + accessToken);
            },
            success: function (response) {
                User = response.categories[0].results[0].content;
                sessionStorage.setItem("User", JSON.stringify(User));
                UserImage = ("image" in response.categories[0].results[0].content);
                UpdateUserMenuDetails();
            },
            error: function (error) {
                console.log(error)
            }
        });
    });
}

function UpdateUserMenuDetails() {
    var destURL = ExternalLinks.DPNURL.replace('#Keywords#', loggedInUser);
    User.image = 'data:image/png;base64,' + User.image;
    $("#imgProfIco").html('<span class="no_imgicon">' + User.preferredName.substring(0, 1) + User.lastName.substring(0, 1) + '</span><img src="' + User.image + '"/>');
    $("#imgProfile").html('<a href="' + destURL + '"target="_blank"><span class="no_imgicon">' + User.preferredName.substring(0, 1) + User.lastName.substring(0, 1) + '</span><img src="' + User.image + '"/></a>');
    $("#divName").html('<a href="' + destURL + '" target="_blank">' + User.preferredName + '</a><a href="' + destURL + '" target="_blank">' + User.lastName + '</a>');
    $("#position").html('<a href="' + destURL + '" target="_blank">' + User.position + '</a>');
    $("#miconprofile").html('<a href="' + destURL + '" target="_blank"><span class="no_imgicon">' + User.preferredName.substring(0, 1) + User.lastName.substring(0, 1) + '</span><img src="' + User.image + '"/>' + User.lastName + '&nbsp' + User.preferredName + '</a>');

    if (UserImage === true) {
        $("#imgProfile").find("span").css("display", "none");
        $("#imgProfIco").find("span").css("display", "none");
        $("#miconprofile").find("span").css("display", "none");
    }
    else {
        $("#imgProfile").find("img").css("display", "none");
        $("#imgProfIco").find("img").css("display", "none");
        $("#miconprofile").find("img").css("display", "none");
    }
}

function AddSharePointDesignerMenus() {
    if ($(window).width() > 1024) {

        var context = new SP.ClientContext.get_current();
        var web = context.get_web();
        var ob = new SP.BasePermissions();
        ob.set(SP.PermissionKind.addAndCustomizePages)

        var isUserHasEditPermissions = web.doesUserHavePermissions(ob)

        context.executeQueryAsync(
        function () {
            if (isUserHasEditPermissions.get_value() == true) {
                $(".userMenu").css('display', 'block');
            } else {
                $('.dropdown-menu .first').css('display', 'none');
            }
        },
        function (a, b) {
            console.log("Error in Retrieving User Permissions from SharePoint");
        });
    }
}

function UpdateRateThisAppMenuDetails() {
    serviceUrl = ExternalLinks.RatethisappURL;
    $("#ratethisApp").rateThisApp({
        applicationKey: "deloittedoesthat",
        userAlias: loggedInUser,
        serviceUri: serviceUrl
    });
    $("#ratethisAppm").rateThisApp({
        applicationKey: "deloittedoesthat",
        userAlias: loggedInUser,
        serviceUri: serviceUrl
    });
}

function TrackSiteClicks(userID) {

    // Uncomment the line below after setting s.pageName to a descriptive page name. Also, delete this comment line before deploying 
    s.pageName = $(document).attr('title');

    // Uncomment the line below after setting s.channel to top level sub-section. Also, delete this comment line before deploying 
    s.channel;

    // Uncomment the line below after setting eVar14/prop14 to correct user ID. Also, delete this comment line before deploying 
    s.eVar14 = s.prop14 = userID;

    /************* DO NOT ALTER ANYTHING BELOW THIS LINE ! **************/
    var s_code = s.t(); if (s_code) document.write(s_code)//--></script>
    if (navigator.appVersion.indexOf('MSIE') >= 0) document.write(unescape('%3C') + '\!-' + '-')
    //--></script><noscript><img src="https://deloitteus.d2.sc.omtrdc.net/b/ss/DeloitteUS-deloitte-does-that-Dev/1/H.25--NS/0"height="1" width="1" border="0" alt="" /></noscript><!--/DO NOT REMOVE/--><!-- End SiteCatalyst code version: H.25. -->

}