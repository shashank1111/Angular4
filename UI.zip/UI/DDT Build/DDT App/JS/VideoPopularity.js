//Loading Sharepoint JS Files
$(document).ready(function () {
    SP.SOD.registerSod('reputation.js', '/_layouts/15/reputation.js');
});

var VideoPopularity = function () { };

VideoPopularity.addView = (function (videoId) {
    //function addView(videoId, callbackfunction) {
    $.ajax({
        url: "/sites/deloittedoesthat/_api/web/lists/getbytitle('VideoPopularity')/items?$filter=VideoID eq '" + videoId + "'",
        method: "GET",
        headers: { "Accept": "application/json; odata=verbose" },
        success: function (data) {
            if (data.d.results.length > 0) // Old Video
            {
                VideoLike(data.d.results[0].ID);
            }
            else   // New Video
            {
                var data = {
                    __metadata: { 'type': getListItemType("VideoPopularity") },
                    VideoID: videoId
                };
                $.ajax({
                    url: "/sites/deloittedoesthat/_api/web/lists/getbytitle('VideoPopularity')/items",
                    type: "POST",
                    contentType: "application/json;odata=verbose",
                    data: JSON.stringify(data),
                    headers: {
                        "Accept": "application/json;odata=verbose",
                        "X-RequestDigest": $("#__REQUESTDIGEST").val()
                    },
                    success: function (data) {
                        VideoLike(data.d.ID);
                    },
                    error: function (data) {
                        console.log(data)
                    }
                });
            }
        },
        error: function (data) {
            // failure(data);
        }
    });

    function getListItemType(name) {
        return "SP.Data." + name[0].toUpperCase() + name.substring(1) + "ListItem";
    }
    function VideoLike(ItemID) {
        var aContextObject = new SP.ClientContext();
        var list = aContextObject.get_web().get_lists().getByTitle("VideoPopularity");
        aContextObject.load(list, 'Id');
        aContextObject.executeQueryAsync(Function.createDelegate(this, function success() {
            var listId = list.get_id().toString();
            var like = true;
            EnsureScriptFunc('reputation.js', 'Microsoft.Office.Server.ReputationModel.Reputation', function () {
                Microsoft.Office.Server.ReputationModel.Reputation.setLike(aContextObject, listId, ItemID, like);
                aContextObject.executeQueryAsync(
                             function () {
                                 console.log('liked It');
                             }, function (sender, args) {
                                 console.log('Error: Looks Like already Liked');
                             });
            });
        }, function (sender, args) {
            console.error('Error: Update Like');
        }));
    }

});
VideoPopularity.getTopViews = (function () {
    //function getTopViews() {
    var query = "<View><Query><OrderBy><FieldRef Name=\"LikesCount\" Ascending=\"FALSE\" /></OrderBy></Query><RowLimit>5</RowLimit></View>";

    var queryload = {
        'query': {
            '__metadata': { 'type': 'SP.CamlQuery' },
            'ViewXml': query
        }
    };
    return $.ajax({
        url: "/sites/deloittedoesthat/_api/web/lists/getbytitle('VideoPopularity')/getitems?$select=VideoID,LikesCount",
        type: "POST",
        contentType: "application/json;odata=verbose",
        data: JSON.stringify(queryload),
        headers: {
            "Accept": "application/json;odata=verbose",
            "X-RequestDigest": $("#__REQUESTDIGEST").val()
        }
    });
});
