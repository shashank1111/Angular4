module.exports = function (grunt) {

    grunt.initConfig({
        pkg: grunt.file.readJSON('package.json'),
        concat: {
            js: {
                src: ['../JS/GetConfigItems.js', '../JS/header.js', '../JS/Analytics.js',
                 '../JS/HomeVideoGallery.js', '../JS/subcategory.js', '../JS/VideoPopularity.js'],
                dest: 'DDT App/JS/build.<%= pkg.name %>.js'
            },
            thirdPartyJS: {
                src: ['../3rdPartyJS/jquery.min.js', '../3rdPartyJS/jquery.mobile.min.js', '../3rdPartyJS/bootstrap.min.js', '../3rdPartyJS/jquery.ratethisapp.min.js'],
                dest: 'DDT App/JS/thirdParty.<%= pkg.name %>.min.js'
            },
            css: {
                src: ['../CSS/ratethisapp-responsive.css ', '../CSS/main.css', '../CSS/sharepoint.css', '../CSS/header.css'],
                dest: 'DDT App/CSS/build.<%= pkg.name %>.css'
            }
        },
        uglify: {
            options: {
                banner: '/*! <%= pkg.name %> <%= grunt.template.today("dd-mm-yyyy") %> */\n'
            },
            dist: {
                files: {
                    'DDT App/JS/build.<%= pkg.name %>.min.js': ['<%= concat.js.dest %>']
                }
            }
        },
        cssmin: {
            dist: {
                files: {
                    'DDT App/CSS/build.<%= pkg.name %>.min.css': ['<%= concat.css.dest %>']
                }
            }
        },
        jshint: {
            files: ['Gruntfile.js', 'src/**/*.js', 'test/**/*.js'],
            options: {
                // options here to override JSHint defaults
                globals: {
                    jQuery: true,
                    console: true,
                    module: true,
                    document: true
                }
            }
        },
        copy: {
            // Copy JavaScript to the output directory, excluding the testing specs
            // This allows us to build source maps correctly
            js: {
                expand: true,
                cwd: '../JS/',
                src: ['VideoPopularity.js', 'RatingVideo.js', 'VideoPlayerRedirection.js','s_code.js', 'AdfsAuthRedirect.js'],
                dest: 'DDT App/JS/',
            },
            css: {
                expand: true,
                cwd: '../CSS/',
                src: ['CommonSearchStyles.css', 'rateThisApp.min.css', 'bootstrap.min.css'],
                dest: 'DDT App/CSS/',
            }
        },
    });

    grunt.loadNpmTasks('grunt-contrib-uglify');
    grunt.loadNpmTasks('grunt-contrib-jshint');
    grunt.loadNpmTasks('grunt-contrib-concat');
    grunt.loadNpmTasks('grunt-contrib-cssmin');
    grunt.loadNpmTasks('grunt-contrib-copy');

    grunt.registerTask('default', ['jshint', 'concat', 'uglify', 'cssmin', 'copy']);

};