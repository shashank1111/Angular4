
$SPBuildPath = $PSScriptRoot + "\DDT Build"
$AngularBuildPath = $PSScriptRoot + "\DDTUIApp"
$DistCopySourcePath = $PSScriptRoot + "\DDTUIApp\dist\*"
$DistCopyDestPath = $PSScriptRoot + "\DDT Build\DDT App Components"
$RenameDDTAPP = $PSScriptRoot + "\DDT Build\DDT App"
$RenameDDTAPPJs = $PSScriptRoot + "\DDT Build\DDT App\JS"
$RenameDDTAPPCSS = $PSScriptRoot + "\DDT Build\DDT App\CSS"
Write-Host "Process Initializing"
<#Remove existing Build files from DDT App and DDT App Components Folders#>
Remove-Item $DistCopyDestPath -recurse
Remove-Item $RenameDDTAPP -recurse
<#SharePoint Files Grunt#>
Set-Location -Path $SPBuildPath
<#Installing grunt#>
npm install
npm install -g grunt-cli@1.2.0 --save-dev
npm install grunt --save-dev
grunt
Write-Host "SharePoint files build completed successfully"
<#Angular Files build#>
Set-Location -Path $AngularBuildPath
npm install
npm install -g @angular/cli@1.0.2 --save-dev
ng build --prod --output-hashing none
Write-Host "Angular files build completed successfully"
<#Copying Angular flies from dist folder to DDT APP Components folder#>
Copy-Item -Path $DistCopySourcePath -Destination $DistCopyDestPath
Write-Host "Dist files copied successfully"



Set-Location -Path $PSScriptRoot
Write-Host "Build Version Rename completed successfully"
Read-Host -Prompt 'Press Any key to exit'


