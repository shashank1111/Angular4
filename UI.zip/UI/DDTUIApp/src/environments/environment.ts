﻿// The file contents for the current environment will overwrite these during build.
// The build system defaults to the dev environment which uses `environment.ts`, but if you do
// `ng build --env=prod` then `environment.prod.ts` will be used instead.
// The list of which env maps to which file can be found in `angular-cli.json`.

export const environment = {
    production: false,

    // API URLs
    subCategoryServiceUrl: 'assets/api/MockJSONs/subCategoryListMock.json',
    solutionServiceUrl: 'assets/api/MockJSONs/solutionListMock.json',
    instantFindSearchUrl: 'assets/api/MockJSONs/instantFindSearchResponseMock.json',
    instantFindProfileUrl: 'assets/api/MockJSONs/instantFindContactSearchResponseMock.json',
    instantFindAccessTokenUrl: 'assets/api/MockJSONs/instantFindAccessTokenMock.json',
    contactServiceUrl: 'assets/api/MockJSONs/contactListMock.json',
    subCategoryNameUrl: 'assets/api/MockJSONs/subCategoryTitleMock.json',
    solutionNameUrl: 'assets/api/MockJSONs/solutionTitleMock.json',
    getAllVideosUrl: 'assets/api/MockJSONs/videoListMock.json',
    getSearchedVideosUrl: 'assets/api/MockJSONs/videoSearchMock.json',
    getVideosByBusinessUrl: 'assets/api/MockJSONs/businessNameFilterListMock.json',
    mainVideoServiceUrl: 'assets/api/MockJSONs/mainVideoMock.json',
    popularVideoServiceUrl: 'assets/api/MockJSONs/popularVideoMock.json',
    getVideosByIdsServiceUrl: 'assets/api/MockJSONs/getVideosByIdsMock.json',
    recommendedVideoSubCatServiceUrl: 'assets/api/MockJSONs/recommendedSubCategoryVideoMock.json',
    recommendedVideoKeywordsServiceUrl: 'assets/api/MockJSONs/recommendedKeywordsVideoMock.json',
    recommendedVideoBySolutionUrl: 'assets/api/MockJSONs/recommendedSolutionVideoMock.json',
    subCategoryVideoListUrl: 'assets/api/MockJSONs/subCategoryVideoListMock.json',
    videoPlayerPageUrl: '/sites/DeloitteDoesThat/Pages/Video_Player.aspx',
    videoGalleryPageUrl: '/sites/DeloitteDoesThat/Pages/Video_Gallery.aspx',
    digsSearchUrl: 'https://search.deloitteresources.com/home?' +
    'k=SEARCHTERM+path:https:%2F%2Fdeloittenet.deloitte.com%2Fsites%2Fdeloittedoesthat&app=dnet',
    dnpProfileUrl: 'https://people.deloitteresources.com/dpn/index.html#/Profile/USERALIAS',
    imageDefaultContact: '../Images/person-placeholder-large.png',
    subcategoryDetailsList: 'assets/api/MockJSONs/subcategoryDetailsMock.json',
    videoCommentsUrl: 'assets/api/MockJSONs/videoCommentListMock.json',
    videoPageUrl: 'assets/api/MockJSONs/videoPageMockList.json',
    getSolutionDetailsUrl: 'assets/api/MockJSONs/solutionDetailsMock.json',
    solutionsBySubCategoryUrl: 'assets/api/MockJSONs/solutionsBySubCategoryMock.json',
    subCategoryBySolutionUrl: 'assets/api/MockJSONs/subCategoryBySolutionMock.json',
    pagesServiceUrl: 'assets/api/MockJSONs/pagesByTagMock.json',
    videoSolutionSubCategoryUrl: 'assets/api/MockJSONs/solutionVideoMock.json',
    getVideoByIdUrl: 'assets/api/MockJSONs/singleVideoMock.json',
    getVideosBySubCategoryUrl: 'assets/api/MockJSONs/videosBySubCategoryMock.json',
    getVideosBySolutionUrl: 'assets/api/MockJSONs/videosBySolutionMock.json',
    getCurrentUserUrl: 'assets/api/MockJSONs/currentUserMock.json',
    getContextInfoUrl: 'assets/api/MockJSONs/digestMock.json',
    postCommentUrl: '',
    multiLinePageSearchView: '',
    solutionDetailsBySubCategory: 'assets/api/MockJSONs/solutionDetailsBySubCategory.json',
    getPageTitleByUrl: 'assets/api/MockJSONs/subCategoryTitleMock.json',
    getPageVideosByPageTitleUrl: 'assets/api/MockJSONs/subCategoryVideoListMock.json',
    getAdfsRefreshUrl: 'https://HOSTNAME/siteAssets/adfsrefresh.html',
    advanceSearchAPIUrl: 'assets/api/MockJSONs/azureSearchResultsMock.json',
    //advanceSearchAPIUrl: 'https://ddtpoc.search.windows.net/indexes/ddtresults0721/docs?api-version=2016-09-01&$skip=SKIPVALUE&$top=5&$count=true&facet=BusinessFunction&facet=Category&search=SEARCHQUERY',
    advanceSearchPageUrl: 'SearchResults.aspx?k=SEARCHTERM',
    businessFuncSearchResultsUrl:'',
    getBuyingPatternsBysubcategoryUrl: 'assets/api/MockJSONs/buyingPatternsMock.json',
    getMutipleSubcategoryMainVideoUrl: 'assets/api/MockJSONs/videoListMock.json'
    
};
