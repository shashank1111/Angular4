﻿export const environment = {
    production: true,

    // API URLs
    subCategoryServiceUrl: 'https://HOSTNAME/sites/DeloitteDoesThat/' +
    '_api/web/lists/GetByTitle(\'Sub Category\')/items?' +
    '$select=Title,IsHomeEnabled,PageUrl,Business_x0020_Function/Title,Category/Title&' +
    '$expand=Business_x0020_Function,Category',
    solutionServiceUrl: 'https://HOSTNAME/sites/DeloitteDoesThat/' +
    '_api/web/lists/GetByTitle(\'Solution\')/items?' +
    '$select=Title,IsHomeEnabled,PageUrl,Sub%5Fx0020%5FCategory/Title&$expand=Sub%5Fx0020%5FCategory&$top=500',
    instantFindSearchUrl: 'https://HOSTNAME/v1/_search?q=SEARCHTEXT&limit=10&types=10',
    instantFindProfileUrl: 'https://HOSTNAME/v1/_search?q=SEARCHTEXT&limit=1',
    instantFindAccessTokenUrl: 'https://HOSTNAME/_vti_bin/Deloitte.InstantFind/AccessTokenService.svc/Accesstoken',
    contactServiceUrl: 'https://HOSTNAME/sites/DeloitteDoesThat/' +
    '_api/web/lists/GetByTitle(\'Contacts\')/items?' +
    '$select=UserAlias,Email,PreferedFirstName,LastName,Description,SubCategory/Title,Solution/Title&' +
    '$expand=SubCategory,Solution&$filter=SubCategory/Title eq \'SUBCATEGORYTITLE\' or Solution/Title eq \'SOLUTIONTITLE\'' +
    '&$orderby=SortBy asc',
    subCategoryNameUrl: 'https://HOSTNAME/sites/DeloitteDoesThat/_api/web/lists/GetByTitle(\'Sub%20Category\')' +
    '/items?$select=Title&$filter=PageUrl eq \'SUBCATEGORYURL\'',
    solutionNameUrl: 'https://HOSTNAME/sites/DeloitteDoesThat/_api/web/lists/GetByTitle(\'Solution\')' +
    '/items?$select=Title&$filter=PageUrl eq \'SOLUTIONURL\'',
    getAllVideosUrl: 'https://HOSTNAME/sites/DeloitteDoesThat/' +
    '_api/web/lists/GetByTitle(\'Video\')/items?' +
    '$select=Title,ID,Description,ThumbnailUrl,TextKeyword&$top=500',
    getSearchedVideosUrl: 'https://HOSTNAME/sites/DeloitteDoesThat/' +
    '_api/web/lists/GetByTitle(\'Video\')/items?' +
    '$select=ID,Title,Description,ThumbnailUrl,TextKeyword&$top=500&' +
    '$filter=((substringof(\'SEARCHTERM\',Title)) or (substringof(\'SEARCHTERM\',TextKeyword)))',
    getVideosByBusinessUrl: 'https://HOSTNAME/sites/DeloitteDoesThat/' +
    '_api/web/lists/GetByTitle(\'Video\')/items?' +
    '$select=Title,ID,Description,ThumbnailUrl,BusinessFunction/Title&$top=500&$expand=BusinessFunction&' +
    '$filter=(BUSINESSFILTERTEXT)',
    mainVideoServiceUrl: 'https://HOSTNAME/sites/DeloitteDoesThat/_api/web/lists/GetByTitle(\'Video\')/items?' +
    '$select=ID,Title,TextKeyword,Description,ThumbnailUrl,IsVideoGalleryFeatured,SubCategory/Title,Solution/Title&$' +
    'filter=IsVideoGalleryFeatured%20eq%201&$expand=SubCategory,Solution',
    getVideosByIdsServiceUrl: 'https://HOSTNAME/sites/DeloitteDoesThat/' +
    '_api/web/lists/GetByTitle(\'Video\')/items?' +
    '$select=Id,Title,ThumbnailUrl&$filter= VIDEOSBYID',
    recommendedVideoSubCatServiceUrl: 'https://HOSTNAME/sites/DeloitteDoesThat/' +
    '_api/web/lists/GetByTitle(\'Video\')/items?' +
    '$select=ID,Title,ThumbnailUrl,SubCategory/Title&$expand=SubCategory&$top=5&' +
    '$filter=(SubCategory/Title eq \'SUBCATEGORY\') and (IsVideoGalleryFeatured ne 1)',
    recommendedVideoBySolutionUrl: 'https://HOSTNAME/sites/DeloitteDoesThat/' +
    '_api/web/lists/GetByTitle(\'Video\')/items?' +
    '$select=ID,Title,ThumbnailUrl,Solution/Title&$expand=Solution&$top=5&' +
    '$filter=(Solution/Title eq \'SOLUTION\') and (IsVideoGalleryFeatured ne 1)',
    recommendedVideoKeywordsServiceUrl: 'https://HOSTNAME/sites/DeloitteDoesThat/' +
    '_api/web/lists/GetByTitle(\'Video\')/items?' +
    '$select=ID,Title,TextKeyword,ThumbnailUrl,SubCategory/Title&$expand=SubCategory&$top=5&' +
    '$filter=(RECOMMENDEDVIDEOKEYWORDSURLSUBTEXT)',
    subCategoryVideoListUrl: 'https://HOSTNAME/sites/DeloitteDoesThat/' +
    '_api/web/lists/GetByTitle(\'Video\')/items?$select=Title,Description,ThumbnailUrl,DMPUrl,IsSubcategoryFeatured,SubCategory/Title&' +
    '$expand=SubCategory&$orderby=IsSubcategoryFeatured desc&$filter=SubCategory/Title eq \'SUBCATEGORYTITLE\'',
    videoPlayerPageUrl: '/sites/DeloitteDoesThat/Pages/Video_Player.aspx',
    videoGalleryPageUrl: '/sites/DeloitteDoesThat/Pages/Video_Gallery.aspx',
    digsSearchUrl: 'https://search.deloitteresources.com/home?' +
    'k=SEARCHTERM+path:https:%2F%2Fdeloittenet.deloitte.com%2Fsites%2Fdeloittedoesthat&app=dnet',
    dnpProfileUrl: 'https://people.deloitteresources.com/dpn/index.html#/Profile/USERALIAS',
    imageDefaultContact: '/sites/DeloitteDoesThat/Style%20Library/DDT%20App/images/person-placeholder-large.png',
    subcategoryDetailsList: 'https://HOSTNAME/sites/DeloitteDoesThat/' +
    '_api/web/lists/GetByTitle(\'Sub%20Category\')/items?' +
    '$select=Title,PageUrl,Category/Title,Business_x0020_Function/Title&' +
    '$expand=Category,Business_x0020_Function&' +
    '$filter=PageUrl eq \'SUBCATEGORYURL\'',
    videoCommentsUrl: 'https://HOSTNAME/sites/DeloitteDoesThat/' +
    '_api/web/lists/GetByTitle(\'Comments\')/items?$select=Modified,Description,CommentedBy/Title,VideoId/Id&' +
    '$expand=CommentedBy,VideoId&$orderby=Modified desc&$filter=VideoId/Id eq \'VIDEOID\'',
    videoPageUrl: 'https://HOSTNAME/sites/DeloitteDoesThat/' +
    '_api/web/lists/GetByTitle(\'Video\')/items?' +
    '$select=Id,Title,Description,ThumbnailUrl,DMPUrl,IsSubcategoryFeatured,SubCategory/Title&$expand=SubCategory',
    getSolutionDetailsUrl: 'https://HOSTNAME/sites/DeloitteDoesThat/' +
    '_api/web/lists/GetByTitle(\'Solution\')/items?$select=Title,ID,' +
    'Sub_x0020_Category/Title&$expand=Sub_x0020_Category&$filter=PageUrl eq \'SOLUTIONURL\'',
    solutionsBySubCategoryUrl: 'https://HOSTNAME/sites/DeloitteDoesThat/' +
    '_api/web/lists/GetByTitle(\'Solution\')/items?' +
    '$select=Id,Title,PageUrl,Sub_x0020_Category/Title&$expand=Sub_x0020_Category&$filter=(Sub_x0020_Category/Id eq \'SUBCATEGORYID\')',
    solutionDetailsBySubCategory: 'https://HOSTNAME/sites/DeloitteDoesThat/' +
    '_api/web/lists/GetByTitle(\'Sub%20Category\')/items?' +
    '$select=Business_x0020_Function/Title,PageUrl,Category/Title&$expand=Business_x0020_Function,Category' +
    '&$filter=Title eq \'SUBCATEGORYNAME\'',
    subCategoryBySolutionUrl: 'https://HOSTNAME/sites/DeloitteDoesThat/' +
    '_api/web/lists/GetByTitle(\'Solution\')/items?' +
    '$select=Sub_x0020_Category/Title,Sub_x0020_Category/Id,Sub_x0020_Category/PageUrl&' +
    '$expand=Sub_x0020_Category&$filter=(Id eq \'SOLUTIONID\')',
    pagesServiceUrl: 'https://HOSTNAME/sites/DeloitteDoesThat/' +
    '_api/web/lists/GetByTitle(\'Pages\')/getitems' +
    '?$select=Id,Title,FileRef,FileLeafRef,QueryWords,DDT_x0020_Name',
    multiLinePageSearchView: '<View scope=\'RecursiveAll\'><Query><Where><Contains><FieldRef Name=\'QueryWords\'/>' +
    '<Value Type=\'Note\'>SEARCHTEXT</Value></Contains></Where></Query></View>',
    videoSolutionSubCategoryUrl: 'https://HOSTNAME/sites/DeloitteDoesThat/' +
    '_api/web/lists/GetByTitle(\'Video\')/items?' +
    '$select=TextKeyword,SubCategory/Title,SubCategory/PageUrl,SubCategory/Id,' +
    'Solution/Title,Solution/PageUrl,Solution/Id&$expand=SubCategory,Solution' +
    '&$filter=(ID eq \'VIDEOID\')',
    getVideoByIdUrl: 'https://HOSTNAME/sites/DeloitteDoesThat/' +
    '_api/web/lists/GetByTitle(\'Video\')/items?$select=Title,Description,Id,ThumbnailUrl,DMPUrl,TextKeyword,' +
    'SubCategory/Title,SubCategory/PageUrl,Solution/Title,Solution/PageUrl&' +
    '$expand=SubCategory,Solution&$filter=Id eq \'VIDEOID\'',
    getVideosBySubCategoryUrl: 'https://HOSTNAME/sites/DeloitteDoesThat/' +
    '_api/web/lists/GetByTitle(\'Video\')/items?$select=Id,Title,Description,ThumbnailUrl,DMPUrl,' +
    'IsSubcategoryFeatured,SubCategory/Title,Solution/Title&' +
    '$expand=SubCategory,Solution&$filter=SubCategory/Title eq \'SUBCATEGORYTITLE\'',
    getVideosBySolutionUrl: 'https://HOSTNAME/sites/DeloitteDoesThat/' +
    '_api/web/lists/GetByTitle(\'Video\')/items?$select=Id,Title,Description,ThumbnailUrl,DMPUrl,' +
    'IsSubcategoryFeatured,SubCategory/Title,Solution/Title&' +
    '$expand=SubCategory,Solution&$filter=Solution/Title eq \'SOLUTION\'',
    getCurrentUserUrl: 'https://HOSTNAME/sites/DeloitteDoesThat/_api/web/currentuser',
    getContextInfoUrl: 'https://HOSTNAME/sites/DeloitteDoesThat/_api/contextinfo',
    postCommentUrl: 'https://HOSTNAME/sites/DeloitteDoesThat/_api/web/lists/getbytitle(\'Comments\')/items',
    getPageTitleByUrl: 'https://HOSTNAME/sites/DeloitteDoesThat/_api/web/lists/GetByTitle(\'LISTNAME\')' +
    '/items?$select=Title&$filter=PageUrl eq \'SUBCATEGORYURL\'',
    getPageVideosByPageTitleUrl: 'https://HOSTNAME/sites/DeloitteDoesThat/_api/web/lists/GetByTitle(\'Video\')/items?' +
    '$select=Id,Title,Description,ThumbnailUrl,DMPUrl,IsSubcategoryFeatured,IsSolutionFeatured,SubCategory/Title,Solution/Title&' +
    '$expand=SubCategory,Solution&$orderby=IsSubcategoryFeatured desc&$orderby=IsSolutionFeatured desc&' +
    '$filter=SubCategory/Title eq \'SUBCATEGORYTITLE\' or Solution/Title eq \'SOLUTIONTITLE\'',
    getAdfsRefreshUrl: 'https://HOSTNAME/siteAssets/adfsrefresh.html',
    advanceSearchAPIUrl: 'https://ddtpoc.search.windows.net/indexes/ddtsearchindex/docs?api-version=2016-09-01&$count=true&facet=businessFunction&facet=subCategory&highlight=name,description&highlightPreTag=%3Cspan%20style=%27font-family:open_bold%27%20class=%27boldFont%27%3E&highlightPostTag=%3C/span%3E&search=SEARCHQUERY',
    advanceSearchPageUrl: 'SearchResults.aspx?k=SEARCHTERM',
    businessFuncSearchResultsUrl: 'https://ddtpoc.search.windows.net/indexes/ddtsearchindex/docs?api-version=2016-09-01&$count=true&highlight=name,description&highlightPreTag=%3Cspan%20style=%27font-family:open_bold%27%20class=%27boldFont%27%3E&highlightPostTag=%3C/span%3E&search=SEARCHQUERY' + 'BUSINESSFUNCTIONQUERY',
    getBuyingPatternsBysubcategoryUrl: 'https://HOSTNAME/sites/DeloitteDoesThat/_api/web/lists/GetByTitle(\'ListName\')/items?$Select=Title,SubCategories,BuyingPatternUrl&$filter=Title%20eq%20%27activeSubcategory%27',
    getMutipleSubcategoryMainVideoUrl: 'https://HOSTNAME/sites/DeloitteDoesThat/_api/web/lists/GetByTitle(\'Video\')/items?' + '$Select=Title,ThumbnailUrl,IsVideoGalleryFeatured,SubCategory/Title,SubCategory/PageUrl&$expand=SubCategory&'
};