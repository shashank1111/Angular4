﻿import { Component, OnInit } from '@angular/core';
import { Observable } from 'rxjs/Observable';
import { Subject } from 'rxjs/Subject';
import 'rxjs/add/Operator/debounceTime';
import 'rxjs/add/Operator/distinctUntilChanged';
const _ = require('underscore')._;

import { environment } from '../../environments/environment';
import { AdvanceSearchService } from '../services/advanceSearch.service';
import { PagerService } from '../services/pagingService';
import { SafeHtmlPipe } from '../safe-html.pipe';


@Component({
    selector: 'advance-search',
    templateUrl: './advance-search.component.html',
    styleUrls: ['./advance-search.component.less']
})
export class AdvanceSearchComponent implements OnInit {
    term$ = new Subject<string>();
    term = '';
    resultsList: any = [];
    filteredList: any = [];

    businessFunctionFacetList = [{ id: "CrossBusiness", value: "Cross-Business" }, { id: "Consulting", value: "Consulting" }, { id: "Advisory", value: "Advisory" }, { id: "Tax", value: "Tax" }, { id: "AuditAssurance", value: "Audit & Assurance" }];
    selectedBusinessFunctionList = [];
    selectedContentType = [];

    //Forming Filter Query
    subQuery1 = '';
    subQuery2 = '';
    filterQuery = '';

    //For Maintaining state of filters
    pageChecked = false;
    videoChecked = false;
    CrossBusinessChecked = false;
    ConsultingChecked = false;
    AdvisoryChecked = false;
    TaxChecked = false;
    AuditAssuranceChecked = false

    //Toggle filter group visibility
    toggleBusiness: boolean;
    toggleContentType: boolean;

    //pagination object 
    pager: any = {};
    pageSize: number = 10;
    pageshown: number = 3;

    constructor(private _advanceSearchService: AdvanceSearchService, private _pagerService: PagerService) { }

    ngOnInit() {
      const searchterm = location.href.substring(location.href.indexOf('?k=') + 3).trim();

      this.term$
            .debounceTime(100)
            .switchMap(term => {
                return this._advanceSearchService.callAzureSearchService(term,this.filterQuery);

            }).subscribe(
            result => this.getResults(result)
        )   

      this.term = decodeURIComponent(searchterm);
      this.term$.next(this.term);
    }
    
    public getResults(result) {
        this.filteredList = [];
        this.resultsList = result;
        this.setPage(1);
    }

    public handleKeyUp(event) {
        //Remove old state of the results shown for last keyword searched
        if (this.term.length === 0) {
            this.filteredList = [];
            this.resultsList = [];
        }

        if (this.term.length > 0) {
            this.term$.next(this.term);
        }
    }

    public getFilteredResults(result) {
        this.filteredList = [];
        this.resultsList = result;
        this.setPage(1);
        //console.log(this.resultsList);
    }

    public refreshData(event) {
        this.term = '';
        this.resultsList = [];
        this.filteredList = [];
        this.businessFunctionFacetList = [];
    }

    public clearFilters() {

        this.pageChecked = false;
        this.videoChecked = false;
        this.CrossBusinessChecked = false;
        this.ConsultingChecked = false;
        this.AdvisoryChecked = false;
        this.TaxChecked = false;
        this.AuditAssuranceChecked = false
        this.filterQuery = '';
        this.selectedContentType = [];
        this.selectedBusinessFunctionList = [];

        this._advanceSearchService.callAzureSearchService(this.term, this.filterQuery)
            .subscribe(
            // set items to json response
            result => this.getFilteredResults(result)
            );
    }

    public filterContentType(event) {
        let contentTypeQuery = '';
        let selectedOption = event.target.value;
        if (event.target.checked === true) {
            this.selectedContentType.push(<string>selectedOption);
        } else {
            this.selectedContentType = this.selectedContentType.filter(value => value !== selectedOption);
        }
        console.log("selectedContentType", this.selectedContentType);

        this.selectedContentType.map((selectContentType, index, arr) => {
            if (index < 1) {
                contentTypeQuery = "(";
            }
            if (arr.length - 1 === index) {
                contentTypeQuery += "contentType eq %27" + encodeURIComponent(selectContentType) + "%27)";
            } else {
                contentTypeQuery += "contentType eq %27" + encodeURIComponent(selectContentType) + "%27 or ";
            }
        });

        if (this.selectedContentType.length < 1) {
            contentTypeQuery = '';
        }

        if (this.subQuery2 != '') {
            this.subQuery1 = contentTypeQuery;
            this.subQuery2 = this.subQuery2.replace("&$filter=", "");
            this.filterQuery = '&$filter=' + this.subQuery1 + ' and ' + this.subQuery2;
        } else {
            this.subQuery1 = contentTypeQuery;
            this.filterQuery = '&$filter=' + this.subQuery1 + this.subQuery2;
        }
        if (this.subQuery1 == '') {
            this.filterQuery = '&$filter=' + this.subQuery1 + this.subQuery2;
        }
        if (this.subQuery1 == '' && this.subQuery2 == '') {
            this.filterQuery = '';
        }

        console.log("contentTypeQuery", contentTypeQuery);

        this._advanceSearchService.callAzureSearchService(this.term, this.filterQuery)
            .subscribe(
            // set items to json response
            result => this.getFilteredResults(result)
            );
    }

    public filterBusinessFunctionResults(event) {
        let businessFuncQuery = '';
        let businessFunction = event.target.value;
        if (event.target.checked === true) {
            this.selectedBusinessFunctionList.push(<string>businessFunction);
        } else {
            this.selectedBusinessFunctionList = this.selectedBusinessFunctionList.filter(value => value !== businessFunction);
        }
        console.log("selectedBusinessFunctionList", this.selectedBusinessFunctionList);

        this.selectedBusinessFunctionList.map((selectBusinessFunction, index, arr) => {
            if (index < 1) {
                businessFuncQuery = "(";
            }
            if (arr.length - 1 === index) {
                businessFuncQuery += "businessFunction eq %27" + encodeURIComponent(selectBusinessFunction) + "%27)";
            } else {
                businessFuncQuery += "businessFunction eq %27" + encodeURIComponent(selectBusinessFunction) + "%27 or ";
            }
        });
        
        if (this.selectedBusinessFunctionList.length < 1) {
            businessFuncQuery = '';
        }
        console.log("businessFuncQuery", businessFuncQuery);
        
        if (this.subQuery2 != '') {
            this.filterQuery = '&$filter=' + this.subQuery1 + ' and ' + this.subQuery2;
        } else {
            this.filterQuery = '&$filter=' + this.subQuery1 + this.subQuery2;
        }
        if (this.subQuery1 == '') {
            this.subQuery2 = businessFuncQuery;
            this.filterQuery = '&$filter=' + this.subQuery1 + this.subQuery2;
        } else {
            this.subQuery2 = businessFuncQuery;
            this.subQuery2 = this.subQuery2.replace("&$filter=", "");
        }
        if (this.subQuery1 == '' && this.subQuery2 == ''){
            this.filterQuery = '';
        }

        this._advanceSearchService.callAzureSearchService(this.term, this.filterQuery)
            .subscribe(
                // set items to json response
            result => this.getFilteredResults(result)
            );
    }

    //Pagination
    setPage(page: number) {
        if (page < 1 || page > this.pager.totalPages) {
            return;
        }
        
        if (this.resultsList.value.length > 0){
          // get pager object from service
            this.pager = this._pagerService.getPager(this.resultsList['@odata.count'], page, this.pageSize, this.pageshown);

          // get current page of items
          this.filteredList = this.resultsList.value.slice(this.pager.startIndex, this.pager.endIndex + 1);
        }

        //console.log(this.filteredList);
    }

    firstEllipses() {

        if (this.pager.startPage < this.pager.pages.length) {
            this.setPage(this.pager.startPage - 1);
        }
        else {
            const getPreviousSet = this.pager.pages[0] - Math.ceil(((this.pager.endPage + 1) - this.pager.startPage) / 2);
            this.setPage(getPreviousSet);
        }
    }

    lastEllipses() {
        if (this.pager.endPage + this.pager.pages.length - 1 > this.pager.totalPages) {
            this.setPage(this.pager.endPage + 1);
        }
        else {
            const getNextSet = this.pager.pages[this.pager.pages.length - 1] + Math.ceil(((this.pager.endPage + 1) - this.pager.startPage) / 2);
            this.setPage(getNextSet);
        }
    }

}
