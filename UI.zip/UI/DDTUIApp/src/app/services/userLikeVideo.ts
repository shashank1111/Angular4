 /* Class UserRatingVideo */
export class UserLikeVideo {
    VideoId: number;
    NumOfLikes: number;
    IsUserLiked: boolean;
}
