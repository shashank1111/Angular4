﻿import { Injectable } from '@angular/core';
import { Http, Response, Headers, URLSearchParams } from '@angular/http';
import { Observable } from 'rxjs/Observable';
import 'rxjs/add/Operator/do';
import 'rxjs/add/Operator/catch';
import 'rxjs/add/Operator/map';

import { environment } from '../../environments/environment';
 
@Injectable()
export class BuyingPatternsService {

  constructor(private _http: Http) { }

  getBuyingPatterns(activeSubcategory) {
      let currentByingPatternListName = window['DDTConfigItems'];

      const headers = new Headers();
      this.createServiceHeader(headers);
      const hostname = location.hostname;
      if (environment.production === true) {
          environment.getBuyingPatternsBysubcategoryUrl = environment.getBuyingPatternsBysubcategoryUrl.replace('HOSTNAME', hostname).replace('ListName', currentByingPatternListName.BuyingPatternsListName).replace('activeSubcategory', activeSubcategory);
      }

      return this._http.get(environment.getBuyingPatternsBysubcategoryUrl, {
          headers: headers
      })
       .map((response) => (response.json()).d.results[0])
      .catch(this.handleError);
  }

  private createServiceHeader(headers: Headers) {
      headers.append('Accept', 'application/json;odata=verbose;charset=utf-8');
  }

  private handleError(error: Response) {
      console.error('BuyingPatternsService Error : ' + error);
      return Observable.of<any>();
  }

}
