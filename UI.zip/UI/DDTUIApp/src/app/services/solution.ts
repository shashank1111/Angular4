﻿/* Defines the solution entity */
export class Solution {
    id: number;
    Name: string;
    Business_x0020_Function: any;
    Category_x0020_Name: string;
    SolutionsServiceUrl: string;
    Sub_x0020_Category: any;
    businessName: string;
    Title: string;
    PageUrl: any;
    Url: string;
    url: string;
    solutionListSubcategory: string;
    categoryNameList: any;
    ID: number;
    IsHomeEnabled: boolean;
}
