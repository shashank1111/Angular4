/* Class RelatedContet */
export class RelatedContent {
    Title: string;
    Url: string;

    constructor(private _title: string, private _url: string) {
        this.Title = _title;
        this.Url = _url;
    }
}
