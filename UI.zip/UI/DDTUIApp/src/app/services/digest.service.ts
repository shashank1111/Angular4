import { Injectable } from '@angular/core';
import { Http, Response, Headers } from '@angular/http';
import { Observable } from 'rxjs/Observable';

import { CachedDigest } from './cachedDigest';
import { environment } from '../../environments/environment';

/* const cache: CachedDigest = null;*/

@Injectable()
export class DigestService {

    cachedDigest: CachedDigest = null;

    constructor(private http: Http) { }

    getDigest(): Observable<string> {
        if (this.cachedDigest !== null) {
            const now = new Date();
            if (now < this.cachedDigest.expiration) {
                return Observable.of(this.cachedDigest.value);
            }
        }

        const hostname = location.hostname;
        const headers = new Headers();
        this.createHeaders(headers);

        if (environment.production === true) {
            environment.getContextInfoUrl = environment.getContextInfoUrl.replace('HOSTNAME', hostname);
            console.log(environment.getContextInfoUrl);
        }

        return this.http.post(environment.getContextInfoUrl, '', { headers: headers })
            .map((response: Response) => this.toDigest(response.json().d.GetContextWebInformation))
            .catch(this.handleError);

    }

    toDigest(r: any): string {
        const seconds = r.FormDigestTimeoutSeconds;
        const expiration = new Date();
        expiration.setTime(expiration.getTime() + 1000 * seconds);
        const digest = <CachedDigest>({
            expiration: expiration,
            value: r.FormDigestValue
        });

        return digest.value;
    }

    private createHeaders(headers: Headers) {
        headers.append('Accept', 'application/json;odata=verbose');
        headers.append('Content-type', 'application/json;odata=verbose;charset=utf-8');
    }

    private handleError (error: Response | any) {
        let errMsg: string;
        if (error instanceof Response) {
            const body = error.json() || '';
            const err = body.error || JSON.stringify(body);
            errMsg = `${error.status} - ${error.statusText || ''} ${err}`;
        } else {
            errMsg = error.message ? error.message : error.toString();
        }
        console.error(errMsg);
        return Observable.throw(errMsg);
    }
}
