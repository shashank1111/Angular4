﻿import { Injectable } from '@angular/core';
import { Http, Response, Headers } from '@angular/http';
import { Observable } from 'rxjs/Observable';
import 'rxjs/add/Operator/do';
import 'rxjs/add/Operator/catch';
import 'rxjs/add/Operator/map';

import { SubCategory } from './subCategory';
import { environment } from '../../environments/environment';


@Injectable()
export class SubCategoryListService {

    constructor(private _http: Http) {
    }

    getSubCategoryList(): Observable<SubCategory[]> {
        const headers = new Headers();
        this.createServiceHeader(headers);

        const hostname = location.hostname;
        if (environment.production === true) {
            environment.subCategoryServiceUrl = environment.subCategoryServiceUrl.replace('HOSTNAME', hostname);
            console.log(environment.subCategoryServiceUrl);
        }

        return this._http.get(environment.subCategoryServiceUrl, {
            headers: headers
        })
            .map((response: Response) => <SubCategory[]>response.json().d.results)
            .do(data => console.log('getSubCategoryList Response : ' + JSON.stringify(data)))
            .catch(this.handleError);
    }

    getSubCategoryDetails(): Observable<SubCategory> {
        const headers = new Headers();
        this.createServiceHeader(headers);
        const hostname = location.hostname;
        const currentUrl = location.href;

        if (environment.production === true) {
            environment.subcategoryDetailsList = environment.subcategoryDetailsList.replace('HOSTNAME', hostname);
            environment.subcategoryDetailsList = environment.subcategoryDetailsList.replace('SUBCATEGORYURL', currentUrl);
        }

        return this._http.get(environment.subcategoryDetailsList, {
            headers: headers
        })
            .map((response: Response) => <SubCategory>response.json().d.results[0])
            //.do(data => console.log('getSubCategoryDetails Response : ' + JSON.stringify(data)))
            .catch(this.handleError);
    }

    getSubCategoryBySolution(idSolution: number): Observable<SubCategory> {
        const headers = new Headers();
        this.createServiceHeader(headers);
        const hostname = location.hostname;
        const currentUrl = location.href;

        if (environment.production === true) {
            environment.subCategoryBySolutionUrl = environment.subCategoryBySolutionUrl.replace('HOSTNAME', hostname);
            environment.subCategoryBySolutionUrl = environment.subCategoryBySolutionUrl.replace('SOLUTIONID', idSolution.toString());
        }

        return this._http.get(environment.subCategoryBySolutionUrl, {
            headers: headers
        })
            .map((response: Response) => response.json().d.results[0])
            .do(data => {
                if (data.Sub_x0020_Category !== undefined && data.Sub_x0020_Category !== null) {
                    data.Id = data.Sub_x0020_Category.Id;
                    data.Title = data.Sub_x0020_Category.Title;
                    data.PageUrl = data.Sub_x0020_Category.PageUrl;
                    return data;
                }
                return null;
            })
            .catch(this.handleError);
    }

    getSolutionDetailsBySubCategory(subCategoryName: string): Observable<SubCategory> {
        const headers = new Headers();
        this.createServiceHeader(headers);
        const hostname = location.hostname;
        const currentUrl = location.href;

        if (environment.production === true) {
            environment.solutionDetailsBySubCategory = environment.solutionDetailsBySubCategory.replace('HOSTNAME', hostname);
            environment.solutionDetailsBySubCategory = environment.solutionDetailsBySubCategory.replace('SUBCATEGORYNAME', encodeURIComponent(subCategoryName));
        }

        return this._http.get(environment.solutionDetailsBySubCategory, {
            headers: headers
        })
            .map((response: Response) => <SubCategory[]>response.json().d.results[0])
            .do(data => console.log('getSolutionsBySubcategory Response : ' , JSON.stringify(data)))
            .catch(this.handleError);
    }

    private createServiceHeader(headers: Headers) {
        headers.append('Accept', 'application/json;odata=verbose;charset=utf-8');
    }
    private handleError(error: Response) {
        console.error('getSubCategoryList Error : ' + error);
        return Observable.throw(error.json().error || 'server error');
    }
}
