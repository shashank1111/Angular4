export class CachedDigest {
    public expiration: Date;
    public value: string;
}