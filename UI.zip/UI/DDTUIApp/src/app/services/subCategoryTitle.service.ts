import { Injectable } from '@angular/core';
import { Http, Response, Headers } from '@angular/http';
import { Observable } from 'rxjs/Observable';

import { environment } from '../../environments/environment';
import { PageTitle } from './pageTitle';

@Injectable()
export class SubCategoryTitleService {

    originalGetPageTitleByUrl = environment.getPageTitleByUrl;

    constructor(private http: Http) {
    }

    getPageTitleAndType(): Observable<PageTitle> {
        return this.getSubCategoryOrSolutionTitle().map(data => {
            let subcategoryTitle = data[0];
            let solutionTitle = data[1];
            if (subcategoryTitle !== undefined) {
                subcategoryTitle.isSolution = false;
                return subcategoryTitle;
            } else {
                solutionTitle.isSolution = true;
                return solutionTitle;
            }
        });
    }

    getSubCategoryOrSolutionTitle(): Observable<PageTitle[]> {
        return Observable.forkJoin(
            this.getPageTitleByPageUrl('Sub Category'),
            this.getPageTitleByPageUrl('Solution')
        );
    }
    getSubCategoryTitle(): Observable<string> {
        const headers = new Headers();
        const hostname = location.hostname;
        const currentUrl = location.href;
        this.createHeaders(headers);

        if (environment.production === true) {
            environment.subCategoryNameUrl = environment.subCategoryNameUrl.replace('HOSTNAME', hostname);
            environment.subCategoryNameUrl = environment.subCategoryNameUrl.replace('SUBCATEGORYURL', currentUrl);
        }

        return this.http.get(environment.subCategoryNameUrl, {
            headers: headers
        })
            .map((response: Response) => <Object>response.json().d.results[0].Title)
            .catch(this.handleError);

    }

    getPageTitleByPageUrl(listName: string): Observable<PageTitle> {
        const headers = new Headers();
        const hostname = location.hostname;
        const currentUrl = location.href;
        let requestUrl = this.originalGetPageTitleByUrl;
        this.createHeaders(headers);

        if (environment.production === true) {
            requestUrl = requestUrl.replace('HOSTNAME', hostname);
            requestUrl = requestUrl.replace('LISTNAME', listName);
            requestUrl = requestUrl.replace('SUBCATEGORYURL', currentUrl);
        }

        return this.http.get(requestUrl, {
            headers: headers
        })
            .map((response: Response) => <PageTitle>response.json().d.results[0])
            .catch(this.handleError);

    }

    private createHeaders(headers: Headers) {
        headers.append('Accept', 'application/json;odata=verbose;charset=utf-8');
    }

    private handleError(error: Response | any) {
        let errMsg: string;
        if (error instanceof Response) {
            const body = error.json() || '';
            const err = body.error || JSON.stringify(body);
            errMsg = `${error.status} - ${error.statusText || ''} ${err}`;
        } else {
            errMsg = error.message ? error.message : error.toString();
        }
        console.error(errMsg);
        return Observable.throw(errMsg);
    }
}
