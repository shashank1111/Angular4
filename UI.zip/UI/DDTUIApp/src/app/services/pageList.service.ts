import { Injectable } from '@angular/core';
import { Http, Response, Headers } from '@angular/http';
import { Observable } from 'rxjs/Observable';
import 'rxjs/add/Operator/do';
import 'rxjs/add/Operator/catch';
import 'rxjs/add/Operator/map';
import { environment } from '../../environments/environment';
import { Page } from './page';

@Injectable()
export class PageListService {

    constructor(private _http: Http) {
    }

    getPagesByFilter(text: string, requestDigest: string): Observable<Page[]> {
        const headers = new Headers();
        this.createSolutionServiceHeader(headers, requestDigest);
        const hostname = location.hostname;

        const filter = environment.multiLinePageSearchView.replace('SEARCHTEXT', text );
        let estructuredSearch = {};
        if (environment.production === true) {
           environment.pagesServiceUrl = environment.pagesServiceUrl.replace('HOSTNAME', hostname );
           estructuredSearch = this.getQuerySearch(filter);
        }
        return this._http.post(environment.pagesServiceUrl, JSON.stringify(estructuredSearch), { headers: headers })
            .map((response: Response) => <Page[]>response.json().d.results)
            .do(data => {
                if (data !== undefined && data !== null && data.length > 0) {
                    data.forEach((page) => {
                        if (page.FileRef !== undefined && page.FileRef !== null) {
                            page.Url = page.FileRef;
                        }

                        if (page.DDT_x0020_Name !== undefined && page.DDT_x0020_Name !== null){
                            page.Title = this.parseDDTName(page.DDT_x0020_Name);
                        }
                    });
                }
            })
            .catch(this.handleError);
    }

    private getQuerySearch(filter: string) {
        return {
                'query': {
                    '__metadata': { 'type': 'SP.CamlQuery' },
                    'ViewXml': filter
                }
            };
    }
    private createSolutionServiceHeader(headers: Headers, requestDigest: string) {
        headers.append('Accept', 'application/json;odata=verbose;charset=utf-8');
        headers.append('Content-type', 'application/json;odata=verbose;charset=utf-8');
        headers.append('X-RequestDigest', requestDigest);
    }

    private handleError(error: Response) {
        console.error('getPageByTag Error : ' + error);
        return Observable.throw(error.json().error || 'server error');
    }

    private parseDDTName(ddtName: string) {
        let span= document.createElement('span');
        span.innerHTML= ddtName;
        return span.textContent || span.innerText;
    }
}
