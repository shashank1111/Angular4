﻿let _ = require('underscore')._;

export class PagerService {
    getPager(totalItems: number, currentPage: number, pageSize: number, pagesShown: number) {
        // calculate total pages
        const totalPages = Math.ceil(totalItems / pageSize);

        let startPage: number, endPage: number;
        if (totalPages <= pagesShown) {
            // less than 10 total pages so show all
            startPage = 1;
            endPage = totalPages;
        } else {
            // more than 10 total pages so calculate start and end pages
            if (currentPage <= pagesShown) {
                startPage = 1;
                endPage = pagesShown;
            } else if ( currentPage + (pagesShown - 1) >= totalPages) {
                startPage = totalPages - (pagesShown - 1);
                endPage = totalPages;
            } else {
                startPage = currentPage - Math.floor(pagesShown / 2);
                endPage = currentPage + Math.floor(pagesShown / 2);
            }
        }

        // calculate start and end item indexes
        const startIndex = (currentPage - 1) * pageSize;
        const endIndex = Math.min(startIndex + pageSize - 1, totalItems - 1);

        // create an array of pages to ng-repeat in the pager control
        const pages = _.range(startPage, endPage + 1);

        // return object with all pager properties required by the view
        return {
            totalItems: totalItems,
            currentPage: currentPage,
            totalPages: totalPages,
            startPage: startPage,
            endPage: endPage,
            startIndex: startIndex,
            endIndex: endIndex,
            pages: pages
        };
    }
}
