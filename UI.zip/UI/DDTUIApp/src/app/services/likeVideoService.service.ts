import { Injectable } from '@angular/core';
import { Http, Response, Headers } from '@angular/http';
import { Observable } from 'rxjs/Observable';
import 'rxjs/add/Operator/do';
import 'rxjs/add/Operator/catch';
import 'rxjs/add/Operator/map';
import { environment } from '../../environments/environment';
import { UserLikeVideo } from './userLikeVideo';
declare var RatingVideo: any;

@Injectable()
export class LikeVideoService {

    _ratingVideo: any;

    constructor() {
        this._ratingVideo = new RatingVideo();
    }

    like(idVideo: number, callbackSuccess: any, callbackFail: any) {
        this._ratingVideo.likeVideo(idVideo, (userLikeVideo) => {
            this.getUserLikeVideo(userLikeVideo, callbackSuccess);
        }, function(){
            callbackFail();
        });
    }

    unlike(idVideo: number, callbackSuccess: any, callbackFail: any) {
        this._ratingVideo.unLikeVideo(idVideo, (userLikeVideo) => {
            this.getUserLikeVideo(userLikeVideo, callbackSuccess);
        }, function(response) {
            callbackFail();
        });
    }

    getLikes(idVideo: number, callbackSuccess: any, callbackFail: any) {
        this._ratingVideo.getRating(idVideo, (userLikeVideo) => {
            this.getUserLikeVideo(userLikeVideo, callbackSuccess);
        }, function () {
            callbackFail();
        });
    }

    private getUserLikeVideo(response: any, callback: any) {
         const userRatingVideo = <UserLikeVideo>response;
         callback(userRatingVideo);
    }

    private isNumeric(n) {
        return !isNaN(parseFloat(n)) && isFinite(n);
    }
}
