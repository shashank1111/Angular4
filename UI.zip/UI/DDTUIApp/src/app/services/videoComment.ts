export class VideoComment {
    CommentedBy: any;
    Description: string;
    Modified: string;
}
