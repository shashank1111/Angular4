﻿import { Injectable } from '@angular/core';
import { Http, Response, Headers } from '@angular/http';
import { Observable } from 'rxjs/Observable';
import 'rxjs/add/Observable/of';
import 'rxjs/add/Operator/do';
import 'rxjs/add/Operator/catch';
import 'rxjs/add/Operator/map';
import { environment } from '../../environments/environment';

export class SearchResult {
    ImageUrl: string;
    BusinessFunction: string;
    value: string;
    count: number;
    Category: string;
    URL: string;
    Name: string;
    Description: string;
    Content: string;
    Keywords: string;
}

@Injectable()
export class AdvanceSearchService {

    constructor(private _http: Http) {
    }

    callAzureSearchService(keyword, filterQuery): Observable<SearchResult[]> {

        // Addying api-key as additional header
        let headers = new Headers();
        this.createServiceHeader(headers);
        console.log("filterQuery", filterQuery);
        if (filterQuery == undefined) {
            filterQuery = '';
        }
        let searchText = keyword + filterQuery;
        // Update the search query with local variable
        const advanceSearchUrl = environment.advanceSearchAPIUrl.replace('SEARCHQUERY', searchText);
        //console.log(advanceSearchUrl);

        return this._http.get(advanceSearchUrl, {
            headers: headers
        })
            .map((response: Response) => <SearchResult[]>response.json())
            .do(data => console.log('AdvanceSearch Response for \'' + searchText + '\' : ', data))
            .catch(this.handleError);
    }

    private createServiceHeader(headers: Headers) {
        headers.append('Accept', 'application/json;odata=verbose;charset=utf-8');
        headers.append('api-key', 'EFEBD00EB22527C907BB91F1D7B7CAAC');
    }

    private handleError(error: Response) {
        console.error('AzureSearchService Error : ' + error);
        return Observable.of<any[]>([]);
    }

}
