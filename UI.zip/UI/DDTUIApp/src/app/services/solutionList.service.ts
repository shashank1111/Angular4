import { Injectable } from '@angular/core';
import { Http, Response, Headers } from '@angular/http';
import { Observable } from 'rxjs/Observable';
import 'rxjs/add/Operator/do';
import 'rxjs/add/Operator/catch';
import 'rxjs/add/Operator/map';

import { Solution } from './solution';
import { environment } from '../../environments/environment';


@Injectable()
export class SolutionListService {

    constructor(private _http: Http) {
    }

    getSolutionList(): Observable<Solution[]> {
        const headers = new Headers();
        this.createSolutionServiceHeader(headers);

        const hostname = location.hostname;
        if (environment.production === true) {
           environment.solutionServiceUrl =  environment.solutionServiceUrl.replace('HOSTNAME', hostname );
        }

        return this._http.get(environment.solutionServiceUrl, {
            headers: headers
        })
            .map((response: Response) => <Solution[]>response.json().d.results)
            .do(data => ('getSolutionList Response : ' + JSON.stringify(data)))
            .catch(this.handleError);
    }

    getSolution(): Observable<Solution> {
        const headers = new Headers();
        this.createSolutionServiceHeader(headers);

        const hostname = location.hostname;
        const currentUrl = location.href;

        if (environment.production === true) {
           environment.getSolutionDetailsUrl =  environment.getSolutionDetailsUrl.replace('HOSTNAME', hostname );
           environment.getSolutionDetailsUrl = environment.getSolutionDetailsUrl.replace('SOLUTIONURL', currentUrl);
        }

        return this._http.get(environment.getSolutionDetailsUrl, {
            headers: headers
        })
            .map((response: Response) => <Solution>response.json().d.results[0])
            .do(data => console.log('getSolution Response : ' + JSON.stringify(data)))
            .catch(this.handleError);
    }

    getSolutionsBySubcategory(idSubCategory: number): Observable<Solution[]> {
        const headers = new Headers();
        this.createSolutionServiceHeader(headers);

        const hostname = location.hostname;
        if (environment.production === true) {
           environment.solutionsBySubCategoryUrl =
           environment.solutionsBySubCategoryUrl.replace('HOSTNAME', hostname );
           environment.solutionsBySubCategoryUrl = 
           environment.solutionsBySubCategoryUrl.replace('SUBCATEGORYID', idSubCategory.toString() );
        }

        return this._http.get(environment.solutionsBySubCategoryUrl, {
            headers: headers
        })
            .map((response: Response) => response.json().d.results)
            .do(data => {
                if (data !== undefined && data !== null) {
                    (<any[]>data).forEach((solution) => {
                        solution.Url = solution.PageUrl;
                    });
                }
            })
            .catch(this.handleError);
    }

    private createSolutionServiceHeader(headers: Headers) {
        headers.append('Accept', 'application/json;odata=verbose;charset=utf-8');
    }
    private handleError(error: Response) {
        console.error('getSolutionList Error : ' + error);
        return Observable.throw(error.json().error || 'server error');
    }
}
