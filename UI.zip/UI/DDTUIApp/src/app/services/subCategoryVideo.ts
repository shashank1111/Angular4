import { Url } from './url';

export class SubCategoryVideo {
    Title: string;
    Description: string;
    ThumbnailUrl: Url;
    DMPUrl: Url;
    SubCategory: any;
    Solution: any;
    Id?: number;
}
