﻿/* Defines the subcategory entity */
export class SubCategory {
   Id: number;
   Category: any;
   Business_x0020_Function: any;
   Title: any;
   PageUrl: any;
   Url: any;
   url: string;
   IsHomeEnabled: boolean;
   Name: string;
}
