export class PageTitle {
    Title?: string;
    isSolution?: boolean;
}
