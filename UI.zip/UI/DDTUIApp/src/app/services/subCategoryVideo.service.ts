import { Injectable } from '@angular/core';
import { Http, Response, Headers } from '@angular/http';
import { Observable } from 'rxjs/Observable';

import { SubCategoryVideo } from './subCategoryVideo';
import { SubCategoryTitleService } from './subCategoryTitle.service';
import { environment } from '../../environments/environment';

@Injectable()
export class SubCategoryVideoService {

    constructor(private http: Http) { }


    getSubCategoryVideos(title: string): Observable<SubCategoryVideo[]> {
        const headers = new Headers();
        this.createHeaders(headers);

        const hostname = location.hostname;
        if (environment.production === true) {
            environment.subCategoryVideoListUrl = environment.subCategoryVideoListUrl.replace('HOSTNAME', hostname);
            environment.subCategoryVideoListUrl =
                environment.subCategoryVideoListUrl.replace('SUBCATEGORYTITLE', encodeURIComponent(title));
        }
        return this.http.get(environment.subCategoryVideoListUrl, {
            headers: headers
        })
            .map((response: Response) => <SubCategoryVideo[]>response.json().d.results)
            .catch(this.handleError);
    }

    getPageVideos(title: string, isSolution: boolean): Observable<SubCategoryVideo[]> {
        const headers = new Headers();
        this.createHeaders(headers);

        const hostname = location.hostname;
        if (environment.production === true) {
            environment.getPageVideosByPageTitleUrl = environment.getPageVideosByPageTitleUrl.replace('HOSTNAME', hostname);
            if (isSolution) {
                environment.getPageVideosByPageTitleUrl = environment.getPageVideosByPageTitleUrl.replace('SUBCATEGORYTITLE', '');
                environment.getPageVideosByPageTitleUrl =
                    environment.getPageVideosByPageTitleUrl.replace('SOLUTIONTITLE', encodeURIComponent(title));
            } else {
                environment.getPageVideosByPageTitleUrl =
                    environment.getPageVideosByPageTitleUrl.replace('SUBCATEGORYTITLE', encodeURIComponent(title));
                environment.getPageVideosByPageTitleUrl = environment.getPageVideosByPageTitleUrl.replace('SOLUTIONTITLE', '');
            }

        }
        return this.http.get(environment.getPageVideosByPageTitleUrl, {
            headers: headers
        })
            .map((response: Response) => <SubCategoryVideo[]>response.json().d.results)
            .catch(this.handleError);
    }

    getVideoPageVideos(video: SubCategoryVideo, title: string): Observable<SubCategoryVideo[]> {
        if (typeof video.Solution.Title !== 'undefined') {
            const solutionTitle = video.Solution.Title;
            return this.getVideosBySolution(solutionTitle);
        } else if (typeof video.SubCategory.Title !== 'undefined') {
            const subCategoryTitle = video.SubCategory.Title;
            return this.getVideosBySubCategory(subCategoryTitle);
        }
    }

    getVideosBySolution(SolutionTitle): Observable<SubCategoryVideo[]> {
        const hostname = location.hostname;
        const headers = new Headers();
        this.createHeaders(headers);

        if (environment.production === true) {
            environment.getVideosBySolutionUrl = environment.getVideosBySolutionUrl.replace('HOSTNAME', hostname);
            environment.getVideosBySolutionUrl =
                environment.getVideosBySolutionUrl.replace('SOLUTION', encodeURIComponent(SolutionTitle));
        }
        return this.http.get(environment.getVideosBySolutionUrl, {
            headers: headers
        })
            .map((response: Response) => <SubCategoryVideo[]>response.json().d.results)
            .catch(this.handleError);
    }

    getVideosBySubCategory(subCategoryTitle: string) {
        const hostname = location.hostname;
        const headers = new Headers();
        this.createHeaders(headers);

        if (environment.production === true) {
            environment.getVideosBySubCategoryUrl = environment.getVideosBySubCategoryUrl.replace('HOSTNAME', hostname);
            environment.getVideosBySubCategoryUrl =
                environment.getVideosBySubCategoryUrl.replace('SUBCATEGORYTITLE', encodeURIComponent(subCategoryTitle));
        }
        return this.http.get(environment.getVideosBySubCategoryUrl, {
            headers: headers
        })
            .map((response: Response) => <SubCategoryVideo[]>response.json().d.results)
            .catch(this.handleError);
    }

    getVideoById(videoId: number): Observable<SubCategoryVideo> {
        const hostname = location.hostname;
        const headers = new Headers();
        this.createHeaders(headers);

        if (environment.production === true) {
            environment.getVideoByIdUrl = environment.getVideoByIdUrl.replace('HOSTNAME', hostname);
            environment.getVideoByIdUrl = environment.getVideoByIdUrl.replace('VIDEOID', videoId.toString());
        }

        return this.http.get(environment.getVideoByIdUrl, {
            headers: headers
        })
            .map((response: Response) => <SubCategoryVideo>response.json().d.results[0])
            .catch(this.handleError);
    }

    private createHeaders(headers: Headers) {
        headers.append('Accept', 'application/json;odata=verbose;charset=utf-8');
    }

    private handleError(error: Response | any) {
        let errMsg: string;
        if (error instanceof Response) {
            const body = error.json() || '';
            const err = body.error || JSON.stringify(body);
            errMsg = `${error.status} - ${error.statusText || ''} ${err}`;
        } else {
            errMsg = error.message ? error.message : error.toString();
        }
        console.error(errMsg);
        return Observable.throw(errMsg);
    }
}
