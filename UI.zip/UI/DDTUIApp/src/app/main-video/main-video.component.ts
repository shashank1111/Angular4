﻿import { Component, OnInit } from '@angular/core';

import { VideoListService } from '../services/videoList.service';
import { environment } from '../../environments/environment';

@Component({
  selector: 'app-main-video',
  templateUrl: './main-video.component.html',
  styleUrls: ['./main-video.component.less']
})

export class MainVideoComponent implements OnInit {

  mainFeaturedVideo: any;
  mainVideoTitle: string;
  mainVideoDescription: string;
  mainVideoThumbnail: string;
  mainVideoId: string;

  videoPlayerPageUrl = environment.videoPlayerPageUrl;

  constructor(public _VideoService: VideoListService) {
  }

  ngOnInit() {
    this.getMainVideoInGallery();
  }

  public getMainVideoInGallery() {

    this._VideoService.getMainVideo()
      .subscribe((mainVideoInGallery) => {
        // TODO: Can be refactored
        this.mainFeaturedVideo = mainVideoInGallery;

        this.mainVideoTitle = this.mainFeaturedVideo.Title;
        this.mainVideoDescription = this.mainFeaturedVideo.Description;
        this.mainVideoThumbnail = this.mainFeaturedVideo.ThumbnailUrl.Url;
        this.mainVideoId = this.mainFeaturedVideo.ID;
      },
    );

  }
}
