﻿import { Component, OnInit } from '@angular/core';
import { Http } from '@angular/http';
import {_} from 'underscore';

import { SolutionListService } from '../services/solutionList.service';
import { BuyingPatternsService } from '../services/buying-patterns.service';
import { VideoListService } from '../services/videoList.service';
import { SubCategoryTitleService } from '../services/subCategoryTitle.service';
import { buyingPatternData, buyingPatternRelatedData } from './buying-patterns.model';

@Component({
    selector: 'app-buying-patterns',
    templateUrl: './buying-patterns.component.html',
    styleUrls: ['./buying-patterns.component.min.css']
})

export class BuyingPatternsComponent implements OnInit {

    buyingPatternData: buyingPatternData;
    buyingPatternRelatedData: any;

    constructor(private _titleService: SubCategoryTitleService, private _buyingPatternService: BuyingPatternsService, private _videoListService: VideoListService) { }

    ngOnInit() {
        const listName: string = 'Sub Category';

        //service call to get active Sub Category Title
        this._titleService.getPageTitleByPageUrl(listName)
            //Merge and map response & buying patterns list name from global object DDTConfigItems
            .mergeMap((subcategory) => this._buyingPatternService.getBuyingPatterns(subcategory.Title))
            // assign buying pattern service response to buyingPatternData variable
            .do((response) => this.buyingPatternData = response)
            //Merge and map buying pattern service response
            .mergeMap((buyingPatternResponse) => this._videoListService.getMultipleSubcategoryMainVideo(buyingPatternResponse))
            .subscribe((relatedCategoreisResponse) => this.buyingPatternRelatedData = _.uniq(relatedCategoreisResponse, (x) => x.SubCategory.Title));
    }
}