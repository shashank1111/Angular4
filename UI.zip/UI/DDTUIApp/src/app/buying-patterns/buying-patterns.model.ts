﻿export interface buyingPatternData {
    Title: string;
    SubCategory ?: string;
    BuyingPatternUrl?: string;
    IsSubcategoryFeatured: boolean;
}

export interface buyingPatternRelatedData {
    Title: string;
    SubCategory: subCategroy;
    ThumbnailUrl: thumbnailUrl;
}

export interface subCategroy {
    Title ?: string;
    PageUrl?: string; 
}

export interface thumbnailUrl {
    Description ?: string;
    url ?: string;
}