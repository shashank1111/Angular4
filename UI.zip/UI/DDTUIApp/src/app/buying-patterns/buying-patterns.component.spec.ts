import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { BuyingPatternsComponent } from './buying-patterns.component';

describe('BuyingPatternsComponent', () => {
  let component: BuyingPatternsComponent;
  let fixture: ComponentFixture<BuyingPatternsComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ BuyingPatternsComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(BuyingPatternsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
