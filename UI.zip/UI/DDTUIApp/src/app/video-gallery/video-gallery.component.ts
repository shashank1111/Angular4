import { Component, OnInit } from '@angular/core';

import { MainVideoComponent } from '../main-video/main-video.component';
import { RecommendedVideoComponent } from '../recommended-video/recommended-video.component';
import { PopularVideoComponent } from '../popular-video/popular-video.component';
import { FilterVideoComponent } from '../filter-video/filter-video.component';
import { BreadcrumbComponent } from '../breadcrumb/breadcrumb.component';

@Component({
  selector: 'app-video-gallery',
  templateUrl: './video-gallery.component.html',
  styleUrls: ['./video-gallery.component.less'],
})
export class VideoGalleryComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }
}
