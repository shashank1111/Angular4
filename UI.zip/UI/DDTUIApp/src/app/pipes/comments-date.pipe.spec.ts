/* tslint:disable:no-unused-variable */

import { TestBed, async } from '@angular/core/testing';
import { CommentsDatePipe } from './comments-date.pipe';

describe('CommentsDatePipe', () => {
  it('create an instance', () => {
    const pipe = new CommentsDatePipe();
    expect(pipe).toBeTruthy();
  });
});
