import { Pipe, PipeTransform } from '@angular/core';

@Pipe({
  name: 'commentsDate'
})
export class CommentsDatePipe implements PipeTransform {

  transform(dateString: string): string {
    const date = new Date(dateString);
    const year = date.getFullYear();
    const monthString = this.getMonthName(date);
    const day = ('0' + date.getDate()).slice(-2);
    const hourString = this.formatAMPM(date);

    const formattedDate = monthString + ' ' + day + ', ' + year + ' at ' + hourString;
    return formattedDate;
  }

  private formatAMPM(date: Date): string {
    let hours = date.getHours();
    let minutes = date.getMinutes().toString();
    let ampm = hours >= 12 ? 'PM' : 'AM';
    hours = hours % 12;
    hours = hours ? hours : 12; // the hour '0' should be '12'
    minutes = ('0' + minutes).slice(-2);
    const strTime = hours + ':' + minutes + ' ' + ampm;
    return strTime;
  }

  private getMonthName(date: Date): string {
    const monthNames = ["January", "February", "March", "April", "May", "June",
      "July", "August", "September", "October", "November", "December"
    ];
    return monthNames[date.getMonth()]
  }

}
