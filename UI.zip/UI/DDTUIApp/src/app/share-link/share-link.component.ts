import { Component, OnInit } from '@angular/core';
import { SubCategoryTitleService } from '../services/subCategoryTitle.service';

@Component({
  selector: 'app-share-link',
  templateUrl: './share-link.component.html',
  styleUrls: ['./share-link.component.less']
})
export class ShareLinkComponent implements OnInit {

  titleSubcategoryOrSolution: string;
  titleSubcategoryOrSolutionAnalytics: string;
  currentUrl: string;
  isSolution: boolean;

  constructor(private _titleService: SubCategoryTitleService) { }

  ngOnInit() {
    this.getSubCategoryTitle();
  }

  getSubCategoryTitle() {
    this.currentUrl = location.href;
    this._titleService.getPageTitleAndType()
    .subscribe(pageTitle => {
      this.isSolution = pageTitle.isSolution;
      console.log('Is solution: ' + this.isSolution);
      this.titleSubcategoryOrSolution = encodeURIComponent(pageTitle.Title);
      this.titleSubcategoryOrSolutionAnalytics = pageTitle.Title;
    });
  }

}
