/* tslint:disable:member-ordering */
import { Directive, ElementRef, HostListener, Input, } from '@angular/core';

import { AnalyticsService } from '../services/analytics.service';

@Directive({
  selector: '[appAnalytics]'
})

export class AnalyticsDirective {

  constructor(private _el: ElementRef, private _analyticsService: AnalyticsService) { }

  @HostListener('click') onclick() {

    const tags = {};
    let action: string;
    let event: string;

    // get analytics related attributes into tags
    for (const attribute of this._el.nativeElement.attributes) {

      if (attribute.name.indexOf('analytics-') !== -1) {

        if (attribute.name.indexOf('analytics-prop') !== -1) {
          const propid = attribute.name.substring(attribute.name.indexOf('analytics-prop') + 14);
          // Omniture expects to update both prop, evar varaibles
          tags['prop' + propid] = attribute.value;
          tags['eVar' + propid] = attribute.value;
        }

        if (attribute.name.indexOf('analytics-action') !== -1) {
          action = attribute.value;
        }

        if (attribute.name.indexOf('analytics-events') !== -1) {
          event = attribute.value;
        }

      }
    }

    this._analyticsService.trackAction(tags, action, event);
  }

}
