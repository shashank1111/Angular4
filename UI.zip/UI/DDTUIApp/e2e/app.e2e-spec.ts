import { DDTPhase.2.4.10Page } from './app.po';

describe('ddtphase.2.4.10 App', () => {
  let page: DDTPhase.2.4.10Page;

  beforeEach(() => {
    page = new DDTPhase.2.4.10Page();
  });

  it('should display message saying app works', () => {
    page.navigateTo();
    expect(page.getParagraphText()).toEqual('app works!');
  });
});
