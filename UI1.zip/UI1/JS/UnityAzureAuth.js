﻿var authContext = new AuthenticationContext({
    clientId: 'efd480f6-fef4-4f61-bdf4-eaea0480b917',
    postLogoutRedirectUri: window.location,
    instance: 'https://login.microsoftonline.com/',
    tenant: 'deloitte.onmicrosoft.com',
    cacheLocation: 'localStorage', // enable this for IE, as sessionStorage does not work for localhost.
});
var isCallback = authContext.isCallback(window.location.hash);
authContext.handleWindowCallback();
if (isCallback && !authContext.getLoginError()) {
    window.location = authContext._getItem(authContext.CONSTANTS.STORAGE.LOGIN_REQUEST);
}
UnityAzureAuth();
function UnityAzureAuth() {

    function setCookie(cname, cvalue) {
        document.cookie = cname + "=" + cvalue + ";";
    }

    function getCookie(cname) {
        var name = cname + "=";
        var ca = document.cookie.split(';');
        for (var i = 0; i < ca.length; i++) {
            var c = ca[i];
            while (c.charAt(0) == ' ') {
                c = c.substring(1);
            }
            if (c.indexOf(name) == 0) {
                return c.substring(name.length, c.length);
            }
        }
        return "";
    }

    function checkDDTAuthCookie() {

        var DDTAuth = getCookie("DDTAuth");
       
        if (DDTAuth == "") {
            setCookie("DDTAuth", "TRUE");
                        
            authContext.login();
        }
    }

    
    checkDDTAuthCookie();

};

UnityAzureAuth.prototype.GetToken = function () {
    var user = authContext.getCachedUser();
    //if (authContext._renewStates.length == 0) {
    //    if (user) {
    //            authContext.acquireToken('https://deloitteunitypocuserapi.azurewebsites.net/', function (error, token) {});
    //    }
    //    else {
    //        console.log('Not signed in.')
    //    }
    //}
    var atoken;
   authContext.acquireToken('https://deloitteunitypocuserapi.azurewebsites.net/', function (error, token) {
    atoken = token;
    });
   return atoken;
}

var UnityAzureAuthPrototype = new UnityAzureAuth()
{
}
