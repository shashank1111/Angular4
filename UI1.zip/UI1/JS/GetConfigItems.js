var DDTConfigItems = {};

var getConfigItems = function () {
    return $.ajax({
        "async": false,
        "crossDomain": true,
        "url": "../_api/web/lists/GetByTitle('ConfigList')/items?$Select=Title,Value",
        "method": "GET",
        "headers": {
            "accept": "application/json; odata=verbose",
            "X-RequestDigest": $("#__REQUESTDIGEST").val(),
            "cache-control": "no-cache"
        }
    }).then(function (result) {
        $.each(result.d.results, function (i, key) {
            DDTConfigItems[key.Title] = key.Value;
        });
        return DDTConfigItems;
    })
}
getConfigItems();
