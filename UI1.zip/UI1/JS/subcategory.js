$(document).ready(function () {    
    $(".panel-collapse.collapse").each(function() {
        if($(this).hasClass('in')){
            $(this).parent().find(".subtitle-icon ").addClass("open");
        } else {
            $(this).parent().find(".subtitle-icon ").removeClass("open");
        }     
    });                 
    
    $('.collapse').on('shown.bs.collapse', function () {
        $(this).parent().find(".subtitle-icon ").addClass("open");
    }).on('hidden.bs.collapse', function () {
        $(this).parent().find(".subtitle-icon").removeClass("open");
    });
    
    $('.collapsed').on("click", function() {
        setTimeout(function(){
            if($('.panel-collapse.collapse.in').length == $('.panel-collapse').length){
                $('.expand-all').hide();
                $('.collapse-all').show();
            } else {
                $('.expand-all').show();
                $('.collapse-all').hide();
            }
        },500);
    });

    $('.openall').click(function () {
        $('.panel-collapse')
            .collapse('show');
        $('.expand-all').hide();
        $('.collapse-all').show();
    });

    $('.closeall').click(function () {
        $('.panel-collapse.in')
            .collapse('hide');
        $('.expand-all').show();
        $('.collapse-all').hide();
    });

    $("#videoCarousel").swiperight(function () {
        $(this).carousel('prev');
    });

    $("#videoCarousel").swipeleft(function () {
        $(this).carousel('next');
    });
});