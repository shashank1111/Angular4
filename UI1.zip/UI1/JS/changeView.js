$(function(){
    var changeView = function (){
        var width = $(window).outerWidth();
        if(width<768){
            $('.responsive').removeClass('mobile portrait landscape');
            $('.responsive').addClass('mobile');
        }else if (width < 1024){
            $('.responsive').removeClass('mobile portrait landscape');
            $('.responsive').addClass('portrait'); 
        }else if (width < 1200){
            $('.responsive').removeClass('mobile portrait landscape');
            $('.responsive').addClass('landscape'); 
        }else {
            $('.responsive').removeClass('mobile portrait landscape');
        }
    }

    changeView();
    
    $(window).resize(function(){
        changeView();
    });
});