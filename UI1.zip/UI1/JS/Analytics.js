﻿
// JSON for DDNET2013 External Links - ToDo
//var ExternalLinks = {
//    "s_account": "DeloitteUS-deloitte-does-that-Dev"
//};

var loggedInUser;
var User = [];
var s_account = ExternalLinks.s_account;

$(document).ready(function () {

    // For Ominature Loading
    $.getScript(_spPageContextInfo.webAbsoluteUrl + "/Style Library/DDT App/JS/s_code.js")
    .done(function () {
        loggedInUser = _spPageContextInfo.systemUserKey.split('|')[2];
    }).
     fail(function (jqxhr, settings, exception) {
         console.log('error loading s_code.js');
     });

});
$(window).load(function () {

    loggedInUser = _spPageContextInfo.systemUserKey.split('|')[2];

    //Capturing Omniature Analytics for the First featured Area Click
    $("#FeaturedArea1").click(function () {
        var featuredAreaText = $("#FeaturedArea1 .video-description .title").text();
        captureFeaturedAreasAnalytics(featuredAreaText);
    });

    //Capturing Omniature Analytics for the  Second featured Area Click
    $("#FeaturedArea2").click(function () {
        var featuredAreaText = $("#FeaturedArea2 .video-description .title").text();
        captureFeaturedAreasAnalytics(featuredAreaText);
    });

    //Capturing Omniature Analytics for the Third featured Area Click
    $("#FeaturedArea3").click(function () {
        var featuredAreaText = $("#FeaturedArea3 .video-description .title").text();
        captureFeaturedAreasAnalytics(featuredAreaText);
    });

    //Capturing Omniature Analytics for Buying Patterns image Click in Home Page
    $("#BuyingPatternsImage").click(function () {
        var pageName = "Home Page - Buying Patterns";
        captureBuyingPatternsAnalytics(pageName);
    });

    //Capturing Omniature Analytics for Buying Patterns Title Link Click in Home Page
    $("#BuyingPatternsTitle").click(function () {
        var pageName = "Home Page - Buying Patterns";
        captureBuyingPatternsAnalytics(pageName);
    });

    //Capturing Omniature Analytics for Buying Patterns image Click in Sub-Category Page
    $("#BuyingPatterns_SubCategoryImage").click(function () {
        var pageName = $(document).attr('title') + " - Buying Patterns";
        captureBuyingPatternsAnalytics(pageName);
    });

    //Capturing Omniature Analytics for Buying Patterns Title Link Click in Sub-Category Page
    $("#BuyingPatterns_SubCategoryTitle").click(function () {
        var pageName = $(document).attr('title') + " - Buying Patterns";
        captureBuyingPatternsAnalytics(pageName);
    });

    //Capturing Omniature Analytics for the First Video Click
    $("#Video1").click(function () {
        var videoName = $("#Video1 .title").text();
        captureVideoCarouselAnalytics(videoName);
    });

    //Capturing Omniature Analytics for the  Second Video Click
    $("#Video2").click(function () {
        var videoName = $("#Video2 .title").text();
        captureVideoCarouselAnalytics(videoName);
    });

    //Capturing Omniature Analytics for the Third Video Click
    $("#Video3").click(function () {
        var videoName = $("#Video3 .title").text();
        captureVideoCarouselAnalytics(videoName);
    });

    //Capturing Omniature Analytics for the First Primary Video Image Click
    $("#Video1a .video-container").click(function () {
        var videoName = $("#Video1a .video-description a").text();
        captureVideoCarouselAnalytics(videoName);
    });

    //Capturing Omniature Analytics for the  Second Primary Video Image Click
    $("#Video2a .video-container").click(function () {
        var videoName = $("#Video2a .video-description a").text();
        captureVideoCarouselAnalytics(videoName);
    });

    //Capturing Omniature Analytics for the Third Primary Video Image Click
    $("#Video3a .video-container").click(function () {
        var videoName = $("#Video3a .video-description a").text();
        captureVideoCarouselAnalytics(videoName);
    });

    //Capturing Omniature Analytics for the First Primary Video Title Link Click
    $("#Video1a .video-description a").click(function () {
        var videoName = $("#Video1a .video-description a").text();
        captureVideoCarouselAnalytics(videoName);
    });

    //Capturing Omniature Analytics for the  Second Primary Video Title Link Click
    $("#Video2a .video-description a").click(function () {
        var videoName = $("#Video2a .video-description a").text();
        captureVideoCarouselAnalytics(videoName);
    });

    //Capturing Omniature Analytics for the Third Primary Video Title Link Click
    $("#Video3a .video-description a").click(function () {
        var videoName = $("#Video3a .video-description a").text();
        captureVideoCarouselAnalytics(videoName);
    });

    //Capturing Omniature Analytics for the Top Relevant Issues Links Click--Sub-Category Page
    $("#TopRelevantIssues .related-item .active").on("click", function (event) {
        event.stopPropagation();
        var topRelevantIssueName = $(this).text();
        var pageName = "Top Relevant Issue links - " + $(document).attr('title') + " - " + topRelevantIssueName;
        captureBuyingPatternsAnalytics(pageName);
    });

    //Capturing Omniature Analytics for the Top Relevant Issues Links Click--Solutions page
    $("#TopRelevantIssues_Solution .related-item .active").on("click", function (event) {
        event.stopPropagation();
        var topRelevantIssueName = $(this).text();
        var pageName = "Top Relevant Issue links - " + $(document).attr('title') + " - " + topRelevantIssueName;
        captureBuyingPatternsAnalytics(pageName);
        });

    //Capturing Omniature Analytics for the Additional Resources Links Click-- Sub-Category Page
    $("#AdditionalResources .related-item .active").on("click", function (event) {
        event.stopPropagation();
        var additionalResourceName = $(this).text();
        var pageName = "Additional Resources links - " + $(document).attr('title') + " - " + additionalResourceName;
        captureBuyingPatternsAnalytics(pageName);
    });

    //Capturing Omniature Analytics for the Additional Resources Links Click-- Solutions Page
    $("#AdditionalResources_Solution .related-item .active").on("click", function (event) {
        event.stopPropagation();
        var additionalResourceName = $(this).text();
        var pageName = "Additional Resources links - " + $(document).attr('title') + " - " + additionalResourceName;
        captureBuyingPatternsAnalytics(pageName);
    });

    //Capturing Omniature Analytics for Want to Learn More Image Link Click in Sub-Category Page
    $("#SubCategory_WantToLearnMoreImage").click(function () {
        var pageName = $(document).attr('title') + " - Want to Learn More";
        captureBuyingPatternsAnalytics(pageName);
    });

    //Capturing Omniature Analytics for Want to Learn More Title Link Click in Sub-Category Page
    $("#SubCategory_WantToLearnMoreTitle").click(function () {
        var pageName = $(document).attr('title') + " - Want to Learn More";
        captureBuyingPatternsAnalytics(pageName);
    });

    //Capturing Omniature Analytics for Want to Learn More Image Link Click in Solution Page
    $("#Solution_WantToLearnMoreImage").click(function () {
        var pageName = $(document).attr('title') + " - Want to Learn More";
        captureBuyingPatternsAnalytics(pageName);
    });

    //Capturing Omniature Analytics for Want to Learn More Title Link Click in Solution Page
    $("#Solution_WantToLearnMoreTitle").click(function () {
        var pageName = $(document).attr('title') + " - Want to Learn More";;
        captureBuyingPatternsAnalytics(pageName);
    });

});

// function to Capture Home Page Video Carousel Click Omniature Analytics
function captureVideoCarouselAnalytics(videoName) {

    var options = {};
    options.prop65 = "Home Page - " + videoName;
    options.eVar65 = "Home Page - " + videoName;
    trackAction(options, 'Video Carousel - Home', 'event44');
}

// function to Capture Home Page/Sub-Category Page Buying Patterns Click Omniature Analytics
function captureBuyingPatternsAnalytics(pageName) {

    var options = {};
    options.prop63 = pageName;
    options.eVar63 = pageName;
    trackAction(options, 'Miscellaneous', 'event36');
}

// function to Capture Home Page Featured Area Click Omniature Analytics
function captureFeaturedAreasAnalytics(featuredAreaText) {

    var options = {};
    options.prop60 = "Featured Area - " + featuredAreaText;
    options.eVar60 = "Featured Area - " + featuredAreaText;
    trackAction(options, 'Featured Area', 'event42');
}

//Common function to capture Omniature Analytics Track Action
function trackAction(options, actionName, eventName) {

    var s = s_gi(s_account);
    var origLinkTrackVars = s.linkTrackVars;
    var origLinkTrackEvents = s.linkTrackEvents;

    //setting common variables/properties
    options.prop14 = loggedInUser;
    options.eVar14 = loggedInUser;
    options.prop75 = window.location.href;
    options.eVar75 = window.location.href;

    //setting value for  the variable 'linkTrackVars'
    var index, keys = Object.keys(options), vars = 'events,channel,';
    for (index = 0; index < keys.length; index++) {
        if (index > 0) {
            vars += ',';
        }
        vars += keys[index];
    }

    //Setting Link Variables for Analytics.
    s.linkTrackVars = vars; //'events,channel,prop60,eVar60'; //taken from options keys
    s.linkTrackEvents = eventName; //event name parameter
    s.events = eventName;// event name parameter
    s.pageName = $(document).attr('title');// setting Page Name

    //Filling  Analytics -'s' properties
    for (index = 0; index < keys.length; index++) {
        s[keys[index]] = options[keys[index]];
    }

    //Setting action name for analytics
    s.tl(this, 'o', actionName);
    s.linkTrackVars = origLinkTrackVars;
    s.linkTrackEvents = origLinkTrackEvents;

    //Resetting the Omniature Analytics Variables
    clearOptions(s, options);
}

//Function to reset the Omniature Analytics Variables
function clearOptions(s, options) {

    var index, keys = Object.keys(options);
    s.events = '';
    for (index = 0; index < keys.length; index++) {
        s[keys[index]] = '';
        options[keys[index]] = '';
    }
}

