	#To Run & "C:\DDT\DeloitteDoesThat\Main\UI\CreatingConfigList.ps1" "http://uscldsponnada03:2704/sites/PlayBook/" 
	
	#Creating ConfigList List
	
	Add-PSSnapin Microsoft.SharePoint.PowerShell -EA SilentlyContinue
	# Get the SiteURL
	$spSite = get-spsite($args[0])
	$spListName = "ConfigList"
	# Get the root web
	$spWeb = $spSite.RootWeb	
	$SPList = $spWeb.Lists.TryGetList($spListName)
	$spTemplate = $spWeb.ListTemplates["Custom List"]
	
	#Check if List with specific name exists
	if($SPList -eq $null)
	{
		# Creating Process Flows List
		$spWeb.Lists.Add($spListName, $spListName, $spTemplate)
		Write-Host "Created Successfully the List $spListName"

		#Get Process Steps List
		$ConfigList = $spWeb.Lists.TryGetList($spListName)

		#Add 'Value' - Text Field
		$FieldName1="Value"
		$spFieldType = [Microsoft.SharePoint.SPFieldType]::Text 
		$IsRequired = $False
		$ConfigList.Fields.Add($FieldName1, $spFieldType, $IsRequired)
		$ConfigList.Fields[$FieldName1].update()

		
		$spView = $ConfigList.DefaultView
				
		$spFeild1 = $ConfigList.Fields[$FieldName1]
		$spView.ViewFields.add($spFeild1)
		
		$spView.Update()
		Write-Host "Added Coulmns $FieldName1 Successfully to the Configuration List Default View"
	}
	else
	{
		Write-Host "The $spListName List Already exist"
	}
	 
	$spWeb.dispose()	
	
