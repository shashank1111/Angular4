//Loading Sharepoint JS Files
$(document).ready(function () {
    SP.SOD.registerSod('reputation.js', '/_layouts/15/reputation.js');
    SP.SOD.executeFunc('sp.js', 'SP.ClientContext', readyFunction);
});

function readyFunction() {
}

function RatingVideo() {
    this.listId = "";
    this.title = "Video";
}

// Video Like Functionality Input: VideoID
RatingVideo.prototype.likeVideo = function likeVideo(videoId, callbackSuccess, callbackFail) {
    var liked = true;
    this.registerActionLikeVideo(videoId, liked, callbackSuccess, callbackFail);
}

//Video Unlike Functionality Input: VideoID
RatingVideo.prototype.unLikeVideo = function unLikeVideo(videoId, callbackSuccess, callbackFail) {
    var liked = false;
    this.registerActionLikeVideo(videoId, liked, callbackSuccess, callbackFail);
}

RatingVideo.prototype.registerActionLikeVideo = function registerActionLikeVideo(videoId, liked, callbackSuccess, callbackFail) {
    var aContextObject = new SP.ClientContext();
    var self = this;
    var list = aContextObject.get_web().get_lists().getByTitle(this.title);
    aContextObject.load(list, 'Id');
    aContextObject.executeQueryAsync(Function.createDelegate(this, function success() {
        var listId = list.get_id().toString();
        EnsureScriptFunc('reputation.js', 'Microsoft.Office.Server.ReputationModel.Reputation', function () {
            Microsoft.Office.Server.ReputationModel.
            Reputation.setLike(aContextObject,
                listId,
                videoId, liked);
            aContextObject.executeQueryAsync(
        		function () {
        		    self.getRating(videoId, callbackSuccess, callbackFail);
        		}, function (sender, args) {
        		    console.error('Error: registerActionLikeVideo');
        		    callbackFail();
        		}
        	);
        });
    }, function (sender, args) {
        console.error('Error: getIdList');
        callbackFail();
    }));
}

//Get Ratings Count Input: VideoID
RatingVideo.prototype.getRating = function getRating(videoId, callbackSuccess, callbackFail) {
    var context = new SP.ClientContext(_spPageContextInfo.webServerRelativeUrl);
    var list = context.get_web().get_lists().getByTitle(this.title);
    var item = list.getItemById(videoId);

    context.load(item, "LikedBy", "ID", "LikesCount");
    context.executeQueryAsync(Function.createDelegate(this, function (success) {
        var isUserLiked = false;
        var $v_0 = item.get_item('LikedBy');
        var likesCount = item.get_item('LikesCount');

        if (!SP.ScriptHelpers.isNullOrUndefined($v_0)) {
            for (var $v_1 = 0; $v_1 < $v_0.length; $v_1++) {
                var $v_3 = $v_0[$v_1];
                if ($v_3.$1E_1 === _spPageContextInfo.userId) {
                    isUserLiked = true;
                }
            }
        }
        //Json Output 
        var output = {
            VideoId: videoId,
            NumOfLikes: likesCount,
            IsUserLiked: isUserLiked
        };
        callbackSuccess(output);

    }), Function.createDelegate(this, function (sender, args) {
        console.log("Error in GetRating functionality ");
        callbackFail();
    }));
}