var HostUrl = window.location.host;
if (HostUrl.split(".", 1) == 'ddnet2013') {
    var ExternalLinks = {
        "RatethisappURL": "https://dratethisapp.deloitte.com/rateThisAppService/api/ratethisapp",
        "AccesstokenURL": "https://ddnet2013.hosting.deloitte.com/_vti_bin/Deloitte.InstantFind/AccessTokenService.svc/Accesstoken",
        "InstantFindURL": "https://dapi.instantfind.deloittenet.deloitte.com/v1/_search?q=#Keywords#&group=true&limit=12",
        "DPNURL": "https://people.deloitteresources.com/profile/#Keywords#",
        "s_account": "DeloitteUS-deloitte-does-that-Dev",
    };

} else if (HostUrl.split(".", 1) == 'qdnet2013') {
    var ExternalLinks = {
        "RatethisappURL": "https://qratethisapp.deloitte.com/rateThisAppService/api/ratethisapp",
        "AccesstokenURL": "https://qdnet2013.hosting.deloitte.com/_vti_bin/Deloitte.InstantFind/AccessTokenService.svc/Accesstoken",
        "InstantFindURL": "https://qapi.instantfind.deloittenet.deloitte.com/v1/_search?q=#Keywords#&group=true&limit=12",
        "DPNURL": "https://people.deloitteresources.com/profile/#Keywords#",
        "s_account": "DeloitteUS-deloitte-does-that-Dev",
    };
} else if (HostUrl.split(".", 1) == 'sdnet2013') {
    var ExternalLinks = {
        "RatethisappURL": "https://sratethisapp.deloitte.com/rateThisAppService/api/ratethisapp",
        "AccesstokenURL": "https://sdnet2013.hosting.deloitte.com/_vti_bin/Deloitte.InstantFind/AccessTokenService.svc/Accesstoken",
        "InstantFindURL": "https://sapi.instantfind.deloittenet.deloitte.com/v1/_search?q=#Keywords#&group=true&limit=12",
        "DPNURL": "https://people.deloitteresources.com/profile/#Keywords#",
        "s_account": "DeloitteUS-deloitte-does-that-Dev",
    };

} else if (HostUrl.split(".", 1) == 'sdnet2') {
    var ExternalLinks = {
        "RatethisappURL": "https://sratethisapp.deloitte.com/rateThisAppService/api/ratethisapp",
        "AccesstokenURL": "https://sdnet2.hosting.deloitte.com/_vti_bin/Deloitte.InstantFind/AccessTokenService.svc/Accesstoken",
        "InstantFindURL": "https://sapi.instantfind.deloittenet.deloitte.com/v1/_search?q=#Keywords#&group=true&limit=12",
        "DPNURL": "https://people.deloitteresources.com/profile/#Keywords#",
        "s_account": "DeloitteUS-deloitte-does-that-Dev",
    };

} else if (HostUrl.split(".", 1) == 'deloittenet') {
    var ExternalLinks = {
        "RatethisappURL": "https://ratethisapp.deloitte.com/rateThisAppService/api/ratethisapp",
        "AccesstokenURL": "https://deloittenet.deloitte.com/_vti_bin/Deloitte.InstantFind/AccessTokenService.svc/Accesstoken",
        "InstantFindURL": "https://api.instantfind.deloittenet.deloitte.com/v1/_search?q=#Keywords#&group=true&limit=12",
        "DPNURL": "https://people.deloitteresources.com/profile/#Keywords#",
        "s_account": "DeloitteUS-deloitte-does-that",
    };
} else if (HostUrl.split(".", 1) == 'ldnet2') {
    var ExternalLinks = {
        "RatethisappURL": "https://lratethisapp.deloitte.com/rateThisAppService/api/ratethisapp",
        "AccesstokenURL": "https://ldnet2.hosting.deloitte.com/_vti_bin/Deloitte.InstantFind/AccessTokenService.svc/Accesstoken",
        "InstantFindURL": "https://lapi.instantfind.deloittenet.deloitte.com/v1/_search?q=#Keywords#&group=true&limit=12",
        "DPNURL": "https://people.deloitteresources.com/profile/#Keywords#",
        "s_account": "DeloitteUS-deloitte-does-that-Dev",
    };
}
var loggedInUser;
var User = [];
var UserImage;
var s_account = ExternalLinks.s_account;

$(document).ready(function () {
    var isEditMode = sessionStorage.getItem("EditMode");
    if (window.location.href.substr(window.location.href.lastIndexOf("=") + 1).split(".")[0] == "Design" || isEditMode == "true") {
        sessionStorage.setItem("EditMode", "true");
        $("#ms-designer-ribbon").css('display', 'block');
        $(".landing-header").css('display', 'none');
        $(".search").css('margin-top', '0px !important');
    }
    //For Removing Space
    jQuery('#s4-bodyContainer').html(jQuery('#s4-bodyContainer').html().replace(/\u200B/g, ''));
    // For Ominature Loading
    $.getScript(_spPageContextInfo.webAbsoluteUrl + "/Style Library/DDT App/JS/s_code.js")
    .done(function () {
        loggedInUser = _spPageContextInfo.systemUserKey.split('|')[2];  //currentUser.get_loginName().split('|')[2];
        TrackSiteClicks(loggedInUser);
    }).
     fail(function (jqxhr, settings, exception) {
         console.log('error loading s_code.js');
     });

});
$(window).load(function () {
    loggedInUser = _spPageContextInfo.systemUserKey.split('|')[2];
    HandleUserMenu();
    // To Do - 
    if ((window.location.hostname.split('.', 1)) == 'ddnet2013') {
        $(".dra-main-container").css("display", "none");
        $("#deloitteRateThisApp").css("display", "none");

    }
    // Sharepoint Page Scroll 
    $("#s4-workspace").scroll(function () {
        $(".ui-autocomplete").hide();
    })
    $(".menu-mobile").click(function () {
        $(".search").css("margin-top", "0px !important");
        $(".mobile-menulist").slideToggle();
        $(this).toggleClass("active");
        if($(".menu-mobile").hasClass("active") || $(".search-mobile").hasClass("active")){
          $("app-video-gallery").addClass("mobileHeader");
          $("app-breadcrumb").addClass("mobileHeader");
        }
        else if($(".menu-mobile").hasClass("active") && !$(".search-mobile").hasClass("active")){
          $("app-video-gallery").addClass("mobileHeader");
            $("app-breadcrumb").addClass("mobileHeader");
        }
         else if($(".menu-mobile").hasClass("active") && $(".search-mobile").hasClass("active")){
            $("app-video-gallery").addClass("mobileHeader");
            $("app-breadcrumb").addClass("mobileHeader");
        }
         else if(!$(".menu-mobile").hasClass("active") && !$(".search-mobile").hasClass("active")){
            $("app-video-gallery").removeClass("mobileHeader"); 
            $("app-breadcrumb").removeClass("mobileHeader");
        }
    });
    $(".search-mobile").click(function () {
        $(".mobile-search").slideToggle();
        $(this).toggleClass("active");
         if(!$(".menu-mobile").hasClass("active") && $(".search-mobile").hasClass("active")){
          $("app-video-gallery").addClass("mobileHeader");
            $("app-breadcrumb").addClass("mobileHeader");
        }
        else if($(".menu-mobile").hasClass("active") && !$(".search-mobile").hasClass("active")){
          $("app-video-gallery").addClass("mobileHeader");
            $("app-breadcrumb").addClass("mobileHeader");
        }
         else if($(".menu-mobile").hasClass("active") && $(".search-mobile").hasClass("active")){
            $("app-video-gallery").addClass("mobileHeader");
            $("app-breadcrumb").adddClass("mobileHeader");
        }
         else if(!$(".menu-mobile").hasClass("active") && !$(".search-mobile").hasClass("active")){
            $("app-video-gallery").removeClass("mobileHeader"); 
            $("app-breadcrumb").removeClass("mobileHeader");
        }
    });
    $("#searchm").click(function () {
        $(".searchmobile").slideToggle()
        $(this).toggleClass("active");
    });

    $('input[type="text"]').keyup(function () {
        var length = $(this).val().length
        if (length >= 1) {
            $(".cancel-icon").show();
        } else {
            $(".cancel-icon").hide();
        }
    })
    $(".cancel-icon").click(function () {
        $('input[type="text"]').val("")
        $(this).hide();
    })

    $('input[type="text"]').focus(function () {
        $(this).addClass("active");
        $(".search").addClass("active");
            $("app-main-search ul,app-head-search ul").show();
    });   
    $('input[type="text"]').keyup(function () {
        var length = $(this).val().length
        if (length >= 1) {
            $(".input-close").show();
        } else {
            $(".input-close").hide();
        }
    })
    $(".input-close").click(function () {
        $('input[type="text"]').val("")
        $(this).hide();
    })
    $('input[type="text"]').blur(function () {
        $(this).removeClass("active");
        $(".search").removeClass("active");
        setTimeout(function () {
            $("app-main-search ul,app-head-search ul").hide();
        }, 300);      
    });

});

$(document).ready(function () {

    if ($(window).width() < 767) {
        
        // For making input box cursor bliking inactive on iphones
        $('#s4-workspace').on('scroll', function () {
            var topMargin = ($(".search .search-title").offset().top);

            if ( topMargin < 8) {
                $(".search input").css("font-size", "0px");
            }
            else if ( topMargin > 8) {
                $(".search input").css("font-size", "16px");
            }
        });

        // For making page autoscroll to top on click of search button / hamburger on mobile header
        $('.menu-mobile,.search-mobile').on('click', function () {
            $('#s4-workspace').animate({ scrollTop: 0 }, 900);
            // On document load making font-size 16px
            $(".search input").css("font-size", "16px");
        });
    }
    
});

function HandleUserMenu() {
    if (window.sessionStorage) {
        User = JSON.parse(sessionStorage.getItem("User"));
        if (User == null) {
            GetLoggedInUserDetails();

        }
        else {
            UserImage = ("image" in User);
            UpdateUserMenuDetails();
        }
    }
    else {
        console.log("No Session Storage");
    }

    // Sharepoint Designer Menu
    SP.SOD.executeFunc('sp.js', 'SP.ClientContext', AddSharePointDesignerMenus);
    //Rate This App
    UpdateRateThisAppMenuDetails();
}
function GetLoggedInUserDetails() {
    // Authorization for Instant Find - Need to Verify 
    var accessToken;
    var accessTokenExpiration;

    jQuery.get(ExternalLinks.AccesstokenURL, function (response) {
        accessToken = response.token;
        accessTokenExpiration = response.expires;
        jQuery.ajax({
            url: ExternalLinks.InstantFindURL.replace('#Keywords#', loggedInUser),
            type: 'GET',
            beforeSend: function (xhr) {
                xhr.setRequestHeader("Authorization", "Bearer " + accessToken);
            },
            success: function (response) {
                User = response.categories[0].results[0].content;
                sessionStorage.setItem("User", JSON.stringify(User));
                UserImage = ("image" in response.categories[0].results[0].content);
                UpdateUserMenuDetails();
            },
            error: function (error) {
                console.log(error)
            }
        });
    });
}

function UpdateUserMenuDetails() {
    var destURL = ExternalLinks.DPNURL.replace('#Keywords#', loggedInUser);
    User.image = 'data:image/png;base64,' + User.image;
    $("#imgProfIco").html('<span class="no_imgicon">' + User.preferredName.substring(0, 1) + User.lastName.substring(0, 1) + '</span><img src="' + User.image + '"/>');
    $("#imgProfile").html('<a href="' + destURL + '"target="_blank"><span class="no_imgicon">' + User.preferredName.substring(0, 1) + User.lastName.substring(0, 1) + '</span><img src="' + User.image + '"/></a>');
    $("#divName").html('<a href="' + destURL + '" target="_blank">' + User.preferredName + '</a><a href="' + destURL + '" target="_blank">' + User.lastName + '</a>');
    $("#position").html('<a href="' + destURL + '" target="_blank">' + User.position + '</a>');
    $("#miconprofile").html('<a href="' + destURL + '" target="_blank"><span class="no_imgicon">' + User.preferredName.substring(0, 1) + User.lastName.substring(0, 1) + '</span><img src="' + User.image + '"/>' + User.lastName + '&nbsp' + User.preferredName + '</a>');

    if (UserImage === true) {
        $("#imgProfile").find("span").css("display", "none");
        $("#imgProfIco").find("span").css("display", "none");
        $("#miconprofile").find("span").css("display", "none");
    }
    else {
        $("#imgProfile").find("img").css("display", "none");
        $("#imgProfIco").find("img").css("display", "none");
        $("#miconprofile").find("img").css("display", "none");
    }
}

function AddSharePointDesignerMenus() {
    if ($(window).width() > 1024) {

        var context = new SP.ClientContext.get_current();
        var web = context.get_web();
        var ob = new SP.BasePermissions();
        ob.set(SP.PermissionKind.addAndCustomizePages)

        var isUserHasEditPermissions = web.doesUserHavePermissions(ob)

        context.executeQueryAsync(
        function () {
            if (isUserHasEditPermissions.get_value() == true) {
                $(".userMenu").css('display', 'block');
            } else {
                $('.dropdown-menu .first').css('display', 'none');
            }
        },
        function (a, b) {
            console.log("Error in Retrieving User Permissions from SharePoint");
        });
    }
}

function UpdateRateThisAppMenuDetails() {
    serviceUrl = ExternalLinks.RatethisappURL;
    $("#ratethisApp").rateThisApp({
        applicationKey: "deloittedoesthat",
        userAlias: loggedInUser,
        serviceUri: serviceUrl
    });
    $("#ratethisAppm").rateThisApp({
        applicationKey: "deloittedoesthat",
        userAlias: loggedInUser,
        serviceUri: serviceUrl
    });
}

function TrackSiteClicks(userID) {

    // Uncomment the line below after setting s.pageName to a descriptive page name. Also, delete this comment line before deploying 
    s.pageName = $(document).attr('title');

    // Uncomment the line below after setting s.channel to top level sub-section. Also, delete this comment line before deploying 
    s.channel;

    // Uncomment the line below after setting eVar14/prop14 to correct user ID. Also, delete this comment line before deploying 
    s.eVar14 = s.prop14 = userID;

    /************* DO NOT ALTER ANYTHING BELOW THIS LINE ! **************/
    var s_code = s.t(); if (s_code) document.write(s_code)//--></script>
    if (navigator.appVersion.indexOf('MSIE') >= 0) document.write(unescape('%3C') + '\!-' + '-')
    //--></script><noscript><img src="https://deloitteus.d2.sc.omtrdc.net/b/ss/DeloitteUS-deloitte-does-that-Dev/1/H.25--NS/0"height="1" width="1" border="0" alt="" /></noscript><!--/DO NOT REMOVE/--><!-- End SiteCatalyst code version: H.25. -->

}

// JSON for DDNET2013 External Links - ToDo
//var ExternalLinks = {
//    "s_account": "DeloitteUS-deloitte-does-that-Dev"
//};

var loggedInUser;
var User = [];
var s_account = ExternalLinks.s_account;

$(document).ready(function () {

    // For Ominature Loading
    $.getScript(_spPageContextInfo.webAbsoluteUrl + "/Style Library/DDT App/JS/s_code.js")
    .done(function () {
        loggedInUser = _spPageContextInfo.systemUserKey.split('|')[2];
    }).
     fail(function (jqxhr, settings, exception) {
         console.log('error loading s_code.js');
     });

});
$(window).load(function () {

    loggedInUser = _spPageContextInfo.systemUserKey.split('|')[2];

    //Capturing Omniature Analytics for the First featured Area Click
    $("#FeaturedArea1").click(function () {
        var featuredAreaText = $("#FeaturedArea1 .video-description .title").text();
        captureFeaturedAreasAnalytics(featuredAreaText);
    });

    //Capturing Omniature Analytics for the  Second featured Area Click
    $("#FeaturedArea2").click(function () {
        var featuredAreaText = $("#FeaturedArea2 .video-description .title").text();
        captureFeaturedAreasAnalytics(featuredAreaText);
    });

    //Capturing Omniature Analytics for the Third featured Area Click
    $("#FeaturedArea3").click(function () {
        var featuredAreaText = $("#FeaturedArea3 .video-description .title").text();
        captureFeaturedAreasAnalytics(featuredAreaText);
    });

    //Capturing Omniature Analytics for Buying Patterns image Click in Home Page
    $("#BuyingPatternsImage").click(function () {
        var pageName = "Home Page - Buying Patterns";
        captureBuyingPatternsAnalytics(pageName);
    });

    //Capturing Omniature Analytics for Buying Patterns Title Link Click in Home Page
    $("#BuyingPatternsTitle").click(function () {
        var pageName = "Home Page - Buying Patterns";
        captureBuyingPatternsAnalytics(pageName);
    });

    //Capturing Omniature Analytics for Buying Patterns image Click in Sub-Category Page
    $("#BuyingPatterns_SubCategoryImage").click(function () {
        var pageName = $(document).attr('title') + " - Buying Patterns";
        captureBuyingPatternsAnalytics(pageName);
    });

    //Capturing Omniature Analytics for Buying Patterns Title Link Click in Sub-Category Page
    $("#BuyingPatterns_SubCategoryTitle").click(function () {
        var pageName = $(document).attr('title') + " - Buying Patterns";
        captureBuyingPatternsAnalytics(pageName);
    });

    //Capturing Omniature Analytics for the First Video Click
    $("#Video1").click(function () {
        var videoName = $("#Video1 .title").text();
        captureVideoCarouselAnalytics(videoName);
    });

    //Capturing Omniature Analytics for the  Second Video Click
    $("#Video2").click(function () {
        var videoName = $("#Video2 .title").text();
        captureVideoCarouselAnalytics(videoName);
    });

    //Capturing Omniature Analytics for the Third Video Click
    $("#Video3").click(function () {
        var videoName = $("#Video3 .title").text();
        captureVideoCarouselAnalytics(videoName);
    });

    //Capturing Omniature Analytics for the First Primary Video Image Click
    $("#Video1a .video-container").click(function () {
        var videoName = $("#Video1a .video-description a").text();
        captureVideoCarouselAnalytics(videoName);
    });

    //Capturing Omniature Analytics for the  Second Primary Video Image Click
    $("#Video2a .video-container").click(function () {
        var videoName = $("#Video2a .video-description a").text();
        captureVideoCarouselAnalytics(videoName);
    });

    //Capturing Omniature Analytics for the Third Primary Video Image Click
    $("#Video3a .video-container").click(function () {
        var videoName = $("#Video3a .video-description a").text();
        captureVideoCarouselAnalytics(videoName);
    });

    //Capturing Omniature Analytics for the First Primary Video Title Link Click
    $("#Video1a .video-description a").click(function () {
        var videoName = $("#Video1a .video-description a").text();
        captureVideoCarouselAnalytics(videoName);
    });

    //Capturing Omniature Analytics for the  Second Primary Video Title Link Click
    $("#Video2a .video-description a").click(function () {
        var videoName = $("#Video2a .video-description a").text();
        captureVideoCarouselAnalytics(videoName);
    });

    //Capturing Omniature Analytics for the Third Primary Video Title Link Click
    $("#Video3a .video-description a").click(function () {
        var videoName = $("#Video3a .video-description a").text();
        captureVideoCarouselAnalytics(videoName);
    });

    //Capturing Omniature Analytics for the Top Relevant Issues Links Click--Sub-Category Page
    $("#TopRelevantIssues .related-item .active").on("click", function (event) {
        event.stopPropagation();
        var topRelevantIssueName = $(this).text();
        var pageName = "Top Relevant Issue links - " + $(document).attr('title') + " - " + topRelevantIssueName;
        captureBuyingPatternsAnalytics(pageName);
    });

    //Capturing Omniature Analytics for the Top Relevant Issues Links Click--Solutions page
    $("#TopRelevantIssues_Solution .related-item .active").on("click", function (event) {
        event.stopPropagation();
        var topRelevantIssueName = $(this).text();
        var pageName = "Top Relevant Issue links - " + $(document).attr('title') + " - " + topRelevantIssueName;
        captureBuyingPatternsAnalytics(pageName);
        });

    //Capturing Omniature Analytics for the Additional Resources Links Click-- Sub-Category Page
    $("#AdditionalResources .related-item .active").on("click", function (event) {
        event.stopPropagation();
        var additionalResourceName = $(this).text();
        var pageName = "Additional Resources links - " + $(document).attr('title') + " - " + additionalResourceName;
        captureBuyingPatternsAnalytics(pageName);
    });

    //Capturing Omniature Analytics for the Additional Resources Links Click-- Solutions Page
    $("#AdditionalResources_Solution .related-item .active").on("click", function (event) {
        event.stopPropagation();
        var additionalResourceName = $(this).text();
        var pageName = "Additional Resources links - " + $(document).attr('title') + " - " + additionalResourceName;
        captureBuyingPatternsAnalytics(pageName);
    });

    //Capturing Omniature Analytics for Want to Learn More Image Link Click in Sub-Category Page
    $("#SubCategory_WantToLearnMoreImage").click(function () {
        var pageName = $(document).attr('title') + " - Want to Learn More";
        captureBuyingPatternsAnalytics(pageName);
    });

    //Capturing Omniature Analytics for Want to Learn More Title Link Click in Sub-Category Page
    $("#SubCategory_WantToLearnMoreTitle").click(function () {
        var pageName = $(document).attr('title') + " - Want to Learn More";
        captureBuyingPatternsAnalytics(pageName);
    });

    //Capturing Omniature Analytics for Want to Learn More Image Link Click in Solution Page
    $("#Solution_WantToLearnMoreImage").click(function () {
        var pageName = $(document).attr('title') + " - Want to Learn More";
        captureBuyingPatternsAnalytics(pageName);
    });

    //Capturing Omniature Analytics for Want to Learn More Title Link Click in Solution Page
    $("#Solution_WantToLearnMoreTitle").click(function () {
        var pageName = $(document).attr('title') + " - Want to Learn More";;
        captureBuyingPatternsAnalytics(pageName);
    });

});

// function to Capture Home Page Video Carousel Click Omniature Analytics
function captureVideoCarouselAnalytics(videoName) {

    var options = {};
    options.prop65 = "Home Page - " + videoName;
    options.eVar65 = "Home Page - " + videoName;
    trackAction(options, 'Video Carousel - Home', 'event44');
}

// function to Capture Home Page/Sub-Category Page Buying Patterns Click Omniature Analytics
function captureBuyingPatternsAnalytics(pageName) {

    var options = {};
    options.prop63 = pageName;
    options.eVar63 = pageName;
    trackAction(options, 'Miscellaneous', 'event36');
}

// function to Capture Home Page Featured Area Click Omniature Analytics
function captureFeaturedAreasAnalytics(featuredAreaText) {

    var options = {};
    options.prop60 = "Featured Area - " + featuredAreaText;
    options.eVar60 = "Featured Area - " + featuredAreaText;
    trackAction(options, 'Featured Area', 'event42');
}

//Common function to capture Omniature Analytics Track Action
function trackAction(options, actionName, eventName) {

    var s = s_gi(s_account);
    var origLinkTrackVars = s.linkTrackVars;
    var origLinkTrackEvents = s.linkTrackEvents;

    //setting common variables/properties
    options.prop14 = loggedInUser;
    options.eVar14 = loggedInUser;
    options.prop75 = window.location.href;
    options.eVar75 = window.location.href;

    //setting value for  the variable 'linkTrackVars'
    var index, keys = Object.keys(options), vars = 'events,channel,';
    for (index = 0; index < keys.length; index++) {
        if (index > 0) {
            vars += ',';
        }
        vars += keys[index];
    }

    //Setting Link Variables for Analytics.
    s.linkTrackVars = vars; //'events,channel,prop60,eVar60'; //taken from options keys
    s.linkTrackEvents = eventName; //event name parameter
    s.events = eventName;// event name parameter
    s.pageName = $(document).attr('title');// setting Page Name

    //Filling  Analytics -'s' properties
    for (index = 0; index < keys.length; index++) {
        s[keys[index]] = options[keys[index]];
    }

    //Setting action name for analytics
    s.tl(this, 'o', actionName);
    s.linkTrackVars = origLinkTrackVars;
    s.linkTrackEvents = origLinkTrackEvents;

    //Resetting the Omniature Analytics Variables
    clearOptions(s, options);
}

//Function to reset the Omniature Analytics Variables
function clearOptions(s, options) {

    var index, keys = Object.keys(options);
    s.events = '';
    for (index = 0; index < keys.length; index++) {
        s[keys[index]] = '';
        options[keys[index]] = '';
    }
}


$(document).ready(function () {
    $('#Video1').mouseover(function () {
        $('#Video1a').css('display', 'block');
        $('#Video2a').css('display', 'none');
        $('#Video3a').css('display', 'none');
        $('#Video1active').addClass("active");
        $('#Video2active').removeClass("active");
        $('#Video3active').removeClass("active");
    });
    $('#Video2').mouseover(function () {
        $('#Video1a').css('display', 'none');
        $('#Video2a').css('display', 'block');
        $('#Video3a').css('display', 'none');
        $('#Video2active').addClass("active");
        $('#Video1active').removeClass("active");
        $('#Video3active').removeClass("active");

    });
    $('#Video2').mouseout(function () {
        $('#Video1active').removeClass("active");
        $('#Video2active').addClass("active");
        $('#Video3active').removeClass("active");
        $('#Video1a').css('display', 'none');
        $('#Video2a').css('display', 'block');
        $('#Video3a').css('display', 'none');
    });
    $('#Video3').mouseover(function () {
        $('#Video1a').css('display', 'none');
        $('#Video2a').css('display', 'none');
        $('#Video3a').css('display', 'block');
        $('#Video3active').addClass("active");
        $('#Video1active').removeClass("active");
        $('#Video2active').removeClass("active");
    });
    $('#Video3').mouseout(function () {
        $('#Video1active').removeClass("active");
        $('#Video3active').addClass("active");
        $('#Video2active').removeClass("active");
        $('#Video1a').css('display', 'none');
        $('#Video2a').css('display', 'none');
        $('#Video3a').css('display', 'block');
    });

    
    $("#videoCarousel").swiperight(function() {  
        $(this).carousel('prev');  
    });  

    $("#videoCarousel").swipeleft(function() {  
        $(this).carousel('next');  
    });   
});
$(document).ready(function () {    
    $(".panel-collapse.collapse").each(function() {
        if($(this).hasClass('in')){
            $(this).parent().find(".subtitle-icon ").addClass("open");
        } else {
            $(this).parent().find(".subtitle-icon ").removeClass("open");
        }     
    });                 
    
    $('.collapse').on('shown.bs.collapse', function () {
        $(this).parent().find(".subtitle-icon ").addClass("open");
    }).on('hidden.bs.collapse', function () {
        $(this).parent().find(".subtitle-icon").removeClass("open");
    });
    
    $('.collapsed').on("click", function() {
        setTimeout(function(){
            if($('.panel-collapse.collapse.in').length == $('.panel-collapse').length){
                $('.expand-all').hide();
                $('.collapse-all').show();
            } else {
                $('.expand-all').show();
                $('.collapse-all').hide();
            }
        },500);
    });

    $('.openall').click(function () {
        $('.panel-collapse')
            .collapse('show');
        $('.expand-all').hide();
        $('.collapse-all').show();
    });

    $('.closeall').click(function () {
        $('.panel-collapse.in')
            .collapse('hide');
        $('.expand-all').show();
        $('.collapse-all').hide();
    });

    $("#videoCarousel").swiperight(function () {
        $(this).carousel('prev');
    });

    $("#videoCarousel").swipeleft(function () {
        $(this).carousel('next');
    });
});
//Loading Sharepoint JS Files
$(document).ready(function () {
    SP.SOD.registerSod('reputation.js', '/_layouts/15/reputation.js');
});

var VideoPopularity = function () { };

VideoPopularity.addView = (function (videoId) {
    //function addView(videoId, callbackfunction) {
    $.ajax({
        url: "/sites/deloittedoesthat/_api/web/lists/getbytitle('VideoPopularity')/items?$filter=VideoID eq '" + videoId + "'",
        method: "GET",
        headers: { "Accept": "application/json; odata=verbose" },
        success: function (data) {
            if (data.d.results.length > 0) // Old Video
            {
                VideoLike(data.d.results[0].ID);
            }
            else   // New Video
            {
                var data = {
                    __metadata: { 'type': getListItemType("VideoPopularity") },
                    VideoID: videoId
                };
                $.ajax({
                    url: "/sites/deloittedoesthat/_api/web/lists/getbytitle('VideoPopularity')/items",
                    type: "POST",
                    contentType: "application/json;odata=verbose",
                    data: JSON.stringify(data),
                    headers: {
                        "Accept": "application/json;odata=verbose",
                        "X-RequestDigest": $("#__REQUESTDIGEST").val()
                    },
                    success: function (data) {
                        VideoLike(data.d.ID);
                    },
                    error: function (data) {
                        console.log(data)
                    }
                });
            }
        },
        error: function (data) {
            // failure(data);
        }
    });

    function getListItemType(name) {
        return "SP.Data." + name[0].toUpperCase() + name.substring(1) + "ListItem";
    }
    function VideoLike(ItemID) {
        var aContextObject = new SP.ClientContext();
        var list = aContextObject.get_web().get_lists().getByTitle("VideoPopularity");
        aContextObject.load(list, 'Id');
        aContextObject.executeQueryAsync(Function.createDelegate(this, function success() {
            var listId = list.get_id().toString();
            var like = true;
            EnsureScriptFunc('reputation.js', 'Microsoft.Office.Server.ReputationModel.Reputation', function () {
                Microsoft.Office.Server.ReputationModel.Reputation.setLike(aContextObject, listId, ItemID, like);
                aContextObject.executeQueryAsync(
                             function () {
                                 console.log('liked It');
                             }, function (sender, args) {
                                 console.log('Error: Looks Like already Liked');
                             });
            });
        }, function (sender, args) {
            console.error('Error: Update Like');
        }));
    }

});
VideoPopularity.getTopViews = (function () {
    //function getTopViews() {
    var query = "<View><Query><OrderBy><FieldRef Name=\"LikesCount\" Ascending=\"FALSE\" /></OrderBy></Query><RowLimit>5</RowLimit></View>";

    var queryload = {
        'query': {
            '__metadata': { 'type': 'SP.CamlQuery' },
            'ViewXml': query
        }
    };
    return $.ajax({
        url: "/sites/deloittedoesthat/_api/web/lists/getbytitle('VideoPopularity')/getitems?$select=VideoID,LikesCount",
        type: "POST",
        contentType: "application/json;odata=verbose",
        data: JSON.stringify(queryload),
        headers: {
            "Accept": "application/json;odata=verbose",
            "X-RequestDigest": $("#__REQUESTDIGEST").val()
        }
    });
});
