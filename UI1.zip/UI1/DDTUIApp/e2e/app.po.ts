import { browser, element, by } from 'protractor';

export class DDTPhase.2.4.10Page {
  navigateTo() {
    return browser.get('/');
  }

  getParagraphText() {
    return element(by.css('app-root h1')).getText();
  }
}
