/* tslint:disable:no-unused-variable */
import { async, ComponentFixture, TestBed, TestComponentRenderer } from '@angular/core/testing';
import { By } from '@angular/platform-browser';
import { DebugElement } from '@angular/core';

import { SolutionMatrixComponent } from '../solutionsMatrix/solutions-matrix.component';

describe('SolutionsMatrix Component: ', () => {
  beforeEach(() => {
    // this.app = new SolutionMatrixComponent() ;
  });
  it('should be truthy', () => {
    expect(this.app.pageTitle).toBe('Deloitte Digital Phase 2');
  });

});
