﻿import { Component, OnInit } from '@angular/core';
import { Observable } from 'rxjs/Observable';
import 'rxjs/add/Operator/switchMap';

import { Solution } from '../services/solution';
import { SubCategory } from '../services/subCategory';
import { SubCategoryListService } from '../services/subCategoryList.service';
import { SolutionListService } from '../services/solutionList.service';
import { AnalyticsService } from '../services/analytics.service';

@Component({
    selector: 'app-solutions-matrix',
    templateUrl: './solutions-matrix.component.html',
    styleUrls: ['./solutions-matrix.component.less'],
    providers: []
})

export class SolutionMatrixComponent implements OnInit {

    retrievedSolutionList: Solution[];
    retrievedSubcategoryList: SubCategory[];

    solutionList = [];
    categoryList = [];
    subCategoryList = [];
    respectiveSolutionsList = [];
    categoryNameList;

    selectedBusiness = 'Cross-Business';

    constructor(private _SubCategoryService: SubCategoryListService,
        private _SolutionService: SolutionListService,
        private _analyticsService: AnalyticsService) { }

    ngOnInit(): void {

        // Synchronize both the service responses
        Observable.forkJoin([this._SubCategoryService.getSubCategoryList(),
        this._SolutionService.getSolutionList()])
            .subscribe(results => {
                this.retrievedSubcategoryList = results[0];
                this.retrievedSolutionList = results[1];

                // Set the default business selection
                this.selectedBusiness = 'Cross-Business';
                this.BuildList(this.selectedBusiness);
            }, error => console.log(error));
    }

    handleBusinessClick(event) {
        if (event.target.id === null || event.target.id === '') {
        // Mobile scenario
            this.selectedBusiness = event.target.value;
        } else {
        // Desktop scenario
            this.selectedBusiness = event.target.id;
        }
        // To match with the actual business name for the Advisory
        if (this.selectedBusiness === 'Risk and Financial Advisory') {
            this.selectedBusiness = 'Advisory';
        }

        this.BuildList(this.selectedBusiness);

        // Analytics capturing
        // Calling AnalyticsService instead of using Directive for simplicity
        const tags = {
            eVar60: 'Navigation Tab-' + this.selectedBusiness,
            prop60: 'Navigation Tab-' + this.selectedBusiness,
        };
        this._analyticsService.trackAction(tags, 'Navigation Tabs', 'event30');

    }

    private BuildList(business) {
        const categoryNameList = [];

        // Form a category list for selected business function
        for (let i = 0; i < this.retrievedSubcategoryList.length; i++) {
            if ((this.selectedBusiness) === this.retrievedSubcategoryList[i].Business_x0020_Function.Title.trim()) {
                if (categoryNameList.indexOf(this.retrievedSubcategoryList[i].Category.Title) === -1) {
                    categoryNameList.push(this.retrievedSubcategoryList[i].Category.Title);
                }
            }
        }

        this.BuildSubCategoryList(categoryNameList);
    }

    private BuildSubCategoryList(categoryNameList) {

        this.categoryList = [];
        const respectiveSolutionsList = [];
        let subCategoryUrl: string;
        let solutionUrl: string;
        for (const categoryName in categoryNameList) {
            const retrievedSubcategoryList = [];
            for (const subCategory in this.retrievedSubcategoryList) {
                this.respectiveSolutionsList = [];
                // Build Solution List
                for (let i = 0; i < this.retrievedSolutionList.length; i++) {
                    if (this.retrievedSolutionList[i].Sub_x0020_Category.Title === this.retrievedSubcategoryList[subCategory].Title) {
                        if (this.retrievedSolutionList[i].PageUrl !== null ||
                            this.retrievedSolutionList[i].PageUrl !== '') {
                            solutionUrl = this.retrievedSolutionList[i].PageUrl;
                        }
                        this.respectiveSolutionsList.push({
                            Name: this.retrievedSolutionList[i].Title,
                            url: solutionUrl,
                            IsHomeEnabled: this.retrievedSolutionList[i].IsHomeEnabled,
                        });
                    }
                }
                if (this.retrievedSubcategoryList[subCategory].Category.Title === categoryNameList[categoryName]) {
                    if (this.retrievedSubcategoryList[subCategory].PageUrl !== null ||
                        this.retrievedSubcategoryList[subCategory].PageUrl !== '') {
                        subCategoryUrl = this.retrievedSubcategoryList[subCategory].PageUrl;
                    }
                    retrievedSubcategoryList.push({
                        Name: this.retrievedSubcategoryList[subCategory].Title,
                        url: subCategoryUrl,
                        IsHomeEnabled: this.retrievedSubcategoryList[subCategory].IsHomeEnabled,
                        SolutionList: this.respectiveSolutionsList,
                        // Used for Expansion solution list
                        isOpen: false,
                    });
                }
            }

            this.categoryList.push({
                Name: categoryNameList[categoryName],
                subcategories: retrievedSubcategoryList,
            });
        }
        console.log(this.categoryList);
    }
}
