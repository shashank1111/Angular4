﻿import { Component, OnChanges, SimpleChange, Input } from '@angular/core';
import { Observable } from 'rxjs/Observable';
import { VideoListService, SolutionSubCategoryVideo } from '../services/videoList.service';
import { environment } from '../../environments/environment';
import { SolutionListService } from '../services/solutionList.service';
import { SubCategoryListService } from '../services/subCategoryList.service';
import { PageListService } from '../services/pageList.service';
import { RelatedContent } from '../services/relatedContent';
import { Page } from '../services/page';
import { DigestService } from '../services/digest.service';

@Component({
  selector: 'app-related-content',
  templateUrl: './related-content.component.html',
  styleUrls: ['./related-content.component.less']
})

export class RelatedContentComponent implements OnChanges {

    relatedContent: RelatedContent[]= [];
    tagPages: RelatedContent[]= [];
    limitContent = 5;
    @Input() videoId: number;

   constructor(private _SolutionService: SolutionListService, private _SubCategoryService: SubCategoryListService,
        private _PageService: PageListService, private _VideoService: VideoListService, private _DigestService: DigestService) {
    }

    ngOnChanges(changes: {[propKey: string]: SimpleChange}) {
        for (const propName in changes) {
            if (propName === 'videoId') {
                if (this.videoId !== undefined && this.videoId != null) {
                    this.relatedContent = [];
                    this.updateUI();
                }
            }
        }
    }

    updateUI() {
        this._VideoService.getSolutionSubCategoryVideo(this.videoId)
        .subscribe((solutionSubVideo) => {
            if (solutionSubVideo.Solution !== undefined && solutionSubVideo.Solution !== null
                && solutionSubVideo.Solution.Id !== undefined && solutionSubVideo.Solution.Id !== null) {
                    this.storeRelatedContent(solutionSubVideo.Solution.Title, solutionSubVideo.Solution.PageUrl);
                    this.getRelatedConntetBySolution(solutionSubVideo.Solution.Id, solutionSubVideo.TextKeyword);
                } else {
                    if (solutionSubVideo.SubCategory !== undefined && solutionSubVideo.SubCategory !== null
                    && solutionSubVideo.SubCategory.Id !== undefined && solutionSubVideo.SubCategory.Id !== null) {
                        this.storeRelatedContent(solutionSubVideo.SubCategory.Title, solutionSubVideo.SubCategory.PageUrl);
                        this.getRelatedContentBySubcategory(solutionSubVideo.TextKeyword, solutionSubVideo.SubCategory.Id);
                    }
                    else {
                        return this.getPagesByVideoKeywords(solutionSubVideo.TextKeyword);
                    }
                }
        });
    }

    private getRelatedConntetBySolution(solutionId: number, Keywords: string) {
        return this._SubCategoryService.getSubCategoryBySolution(solutionId).
            subscribe((subcategory) => {
                this.storeRelatedContent(subcategory.Title, subcategory.PageUrl);
                return this.getRelatedContentBySubcategory(Keywords, subcategory.Id);
            });
    }

    private getRelatedContentBySubcategory(Keywords: string, subcategoryId: number) {
        this._SolutionService.getSolutionsBySubcategory(subcategoryId)
        .subscribe((solutions) => {
            if (solutions !== undefined && solutions !== null && solutions.length > 0) {
                solutions.forEach((solution) => {
                    this.storeRelatedContent(solution.Title, solution.Url);
                });
            }
            if (this.isAchievedLimitRelatedContent()) {
                return;
            }
            return this.getPagesByVideoKeywords(Keywords);
        });
    }

    private fillPagesByKeyword(Keyword: string) {
        this._DigestService.getDigest()
            .subscribe(
            digest => {
                return this._PageService.getPagesByFilter(Keyword, digest)
                .subscribe((pages) => {
                    pages.forEach( (page) => {
                        if (this.isAchievedLimitRelatedContent()) {
                            return;
                        }
                    this.storeRelatedContent(page.Title, page.Url);
                    });
                });
            });
    }

    private getPagesByVideoKeywords(Keywords: string) {
        const Keywordds = Keywords.split(',');
        Keywordds.forEach((Keyword) => {
            if (this.isAchievedLimitRelatedContent()) {
                return;
            }
            return this.fillPagesByKeyword(Keyword);
        });
    }

    private storeRelatedContent(title: string, url: string) {
         if (this.isAchievedLimitRelatedContent()) {
             return;
         }
         if (title !== undefined && title !== null
            && url !== undefined && url !== null) {
                if (!this.relatedContent.some(x => x.Title === title)) {
                    this.relatedContent.push(new RelatedContent(title, url));
                }
            }
    }

    private isAchievedLimitRelatedContent(): boolean {
        return this.relatedContent.length > (this.limitContent - 1);
    }
}
