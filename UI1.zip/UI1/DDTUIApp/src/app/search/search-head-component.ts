import { Component, OnInit } from '@angular/core';
import { Subject } from 'rxjs/Subject';
import { Observable } from 'rxjs/Observable';

import 'rxjs/add/Observable/forkJoin';
import 'rxjs/add/Operator/switchMap';
import 'rxjs/add/Operator/debounceTime';
import 'rxjs/add/Operator/distinctUntilChanged';

import { InstantFindService, SearchResult } from '../services/instantfind.service';
import { VideoListService, Video } from '../services/videoList.service';
import { environment } from '../../environments/environment';
import { AnalyticsDirective } from '../analytics/analytics.directive';
import { AnalyticsService } from '../services/analytics.service';

@Component({
    selector: 'app-head-search',
    templateUrl: './search-head-component.html',
    styleUrls: ['./search-component.less'],
})

export class SearchHeadComponent implements OnInit {
  term$ = new Subject<string>();
  term = '';
  instantFindResults: SearchResult[];
  videoSearchResults: Video[];
  maxInstantFindResultsToShow = 5;
  maxVideosToShow = 4;
  totalResultsToShow = this.maxVideosToShow + this.maxInstantFindResultsToShow;

  currentActive = 0;

  videoPageUrl = 'https://HOSTNAME/sites/DeloitteDoesThat/Pages/Video_Player.aspx?videoId=';

  constructor(private _instantFindService: InstantFindService,
    private _videoListService: VideoListService,
    private _analyticsService: AnalyticsService) { }

  ngOnInit() {

    this.videoPageUrl = this.videoPageUrl.replace('HOSTNAME', location.hostname);

    // Waits for 0.2 secs for user to complete typing
    this.term$
      .debounceTime(200)
      .distinctUntilChanged()
      .switchMap(term => {
        const instantFind = this._instantFindService.Search(term);
        const video = this._videoListService.getSearchedVideos(term);

        // Wait for both services to return results by forkJoin
        return Observable.forkJoin(instantFind, video);

      }).subscribe(results => this.assignResults(results));

  }

  private assignResults(results) {

    // check the current term, user might have cleared the text while results coming up
    if (this.term === '') {
      return;
    };

    // if total results less than the expected total, assign both with no slicing
    if (results[0].length + results[1].length <= this.totalResultsToShow) {
      this.instantFindResults = results[0];
      this.videoSearchResults = results[1];
    } else if (results[0].length < this.maxInstantFindResultsToShow &&
      results[1].length > this.maxVideosToShow) {
      // instant finds less, videos more, extra can be given to videos
      const extraItems = this.maxInstantFindResultsToShow - results[0].length;
      this.instantFindResults = results[0];
      this.videoSearchResults = results[1].slice(0, this.maxVideosToShow + extraItems);
    } else if (results[0].length > this.maxInstantFindResultsToShow &&
      results[1].length < this.maxVideosToShow) {
      // instant finds more, videos less, extra can be given to instant find items
      const extraItems = this.maxVideosToShow - results[1].length;
      this.instantFindResults = results[0].slice(0, this.maxInstantFindResultsToShow + extraItems);
      this.videoSearchResults = results[1];
    } else {
      // both more, both be sliced to their maximum
      this.instantFindResults = results[0].slice(0, this.maxInstantFindResultsToShow);
      this.videoSearchResults = results[1].slice(0, this.maxVideosToShow);
    }

  }

  public handleKeyUp(event) {
    // Key codes for catching keyboard input
    let keyCodes = {
      enter: 13,
      arrowUp: 38,
      arrowDown: 40
    };

    if (event.keyCode !== keyCodes.arrowUp && event.keyCode !== keyCodes.arrowDown) {
      this.currentActive = 0;
    }

    if (this.term === '') {
      this.instantFindResults = null;
      this.videoSearchResults = null;
    }

    switch (event.keyCode) {
      case keyCodes.arrowDown:
        this.selectNextResult();
        break;
      case keyCodes.enter:
        this.handleSearchClick();
        break;
      case keyCodes.arrowUp:
        this.selectPreviousResult();
        break;
    }


    this.term$.next(encodeURIComponent(this.term));

  }

  public handleSearchCancel() {
    this.term = '';
    this.instantFindResults = null;
    this.videoSearchResults = null;
  }

  public handleSearchClick() {
    let videoID;
    let instantResultUrl;
    this.instantFindResults.forEach((element, index) => {
      if (element.active === true) {
        instantResultUrl = element.content.url;
      }
    });
    this.videoSearchResults.forEach((element, index) => {
      if (element.active === true) {
        videoID = element.ID;
      }
    });

    //redirect on click search list item
    if (instantResultUrl !== undefined) {
      window.location.href = instantResultUrl;
    }
    else if (videoID !== undefined) {
      window.location.href = this.videoPageUrl + videoID;
    }
    // To handle the Enter scenario, using the Analytics service directly
    else {
      if (this.term.trim() !== '') {
        // instead of using the Directive
        const tags = {
          eVar26: this.term.trim(),
          prop26: this.term.trim(),
        };
        this._analyticsService.trackAction(tags, 'Search Terms', 'event4');

        const digsSearchUrl = environment.digsSearchUrl.replace('SEARCHTERM', encodeURIComponent(this.term.trim()));
        window.open(digsSearchUrl);
      }
    }
  }

  public selectPreviousResult() {

    if (this.instantFindResults.length != 0) {
      //if currrent active value is input value
      if (this.currentActive === 0) {
        this.instantFindResults[0].active = undefined;
      }
      //check current active element is first element
      else if (this.currentActive > 0) {
        //check current active element not an instant find result
        if (this.currentActive > this.instantFindResults.length) {
          this.videoSearchResults[this.currentActive - (this.instantFindResults.length)].active = false;
          this.videoSearchResults[this.currentActive - (this.instantFindResults.length + 1)].active = true;
          this.currentActive--;
        }
        else if (this.currentActive === this.instantFindResults.length) {
          this.videoSearchResults[this.currentActive - (this.instantFindResults.length)].active = false;
          this.instantFindResults[this.currentActive - 1].active = true;
          this.currentActive--;
        }
        //check current active element is an instant find result
        else if (this.currentActive < this.instantFindResults.length) {
          this.instantFindResults[this.currentActive].active = false;
          this.instantFindResults[this.currentActive - 1].active = true;
          this.currentActive--;
        }
      }
    }

    else if (this.instantFindResults.length === 0) {
      this.videoSearchResults.forEach((element, index) => {
        if (element.active === true) {
          this.currentActive = index;
        }
      })

      if (this.currentActive == 0 && this.videoSearchResults[0].active == true) {
        this.videoSearchResults[0].active = undefined;
      }
      else {
        this.videoSearchResults[this.currentActive].active = false;
        this.videoSearchResults[this.currentActive - 1].active = true;
      }
    }
  }

  public selectNextResult() {

    //check current active element is last element
    if (this.instantFindResults.length !== 0 && this.currentActive < (this.instantFindResults.length + this.videoSearchResults.length) - 1) {
      //set active element as first element
      if (this.instantFindResults[0].active === undefined) {
        this.instantFindResults[0].active = true;
      }
      //check current active element is an instant find result
      else if (this.currentActive < this.instantFindResults.length - 1) {
        this.instantFindResults[this.currentActive].active = false;
        this.instantFindResults[this.currentActive + 1].active = true;
        this.currentActive++;
      }
      else if (this.currentActive === this.instantFindResults.length - 1) {
        this.instantFindResults[this.currentActive].active = false;
        this.videoSearchResults[this.currentActive - (this.instantFindResults.length - 1)].active = true;
        this.currentActive++;
      }
      //check current active element is not an instant find result
      else if (this.currentActive > this.instantFindResults.length - 1) {
        this.videoSearchResults[this.currentActive - this.instantFindResults.length].active = false;
        this.videoSearchResults[(this.currentActive - this.instantFindResults.length) + 1].active = true;
        this.currentActive++;
      }
    }

    else if (this.instantFindResults.length === 0) {
      let currentActive1;
      if (this.currentActive < this.videoSearchResults.length) {
        this.videoSearchResults.forEach((element, index) => {
          if (element.active === true) {
            currentActive1 = index;
          }
        })

        if (this.currentActive === 0) {
          this.videoSearchResults[0].active = true;
        }

        if (currentActive1 !== undefined) {
          this.videoSearchResults[currentActive1].active = false;
          this.videoSearchResults[currentActive1 + 1].active = true;
          this.currentActive = currentActive1 + 2;
        }
      }
    }

  }

  public selectedInstantFindResults(index) {
    this.instantFindResults.forEach((element, index) => {
      if (element.active === true) {
        this.instantFindResults[index].active = false;
      }
    });
    this.videoSearchResults.forEach((element, index) => {
      if (element.active === true) {
        this.videoSearchResults[index].active = false;
      }
    });
    this.instantFindResults[index].active = true;
    window.location.href = this.instantFindResults[index].content.url;
  }

  selectedVideoSearchResults(index) {
    this.instantFindResults.forEach((element, index) => {
      if (element.active === true) {
        this.instantFindResults[index].active = false;
      }
    });
    this.videoSearchResults.forEach((element, index) => {
      if (element.active === true) {
        this.videoSearchResults[index].active = false;
      }
    });
    this.videoSearchResults[index].active = true;
    window.location.href = this.videoPageUrl + this.videoSearchResults[index].ID;
  }
}
