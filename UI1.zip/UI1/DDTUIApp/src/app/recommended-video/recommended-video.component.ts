﻿import { Component, OnInit } from '@angular/core';

import { VideoListService, MainVideo, Video } from '../services/videoList.service';
import { environment } from '../../environments/environment';

@Component({
  selector: 'app-recommended-video',
  templateUrl: './recommended-video.component.html',
  styleUrls: ['./recommended-video.component.less']
})

export class RecommendedVideoComponent implements OnInit {

  recommendedVideoList: any = [];
  videoPlayerPageUrl = environment.videoPlayerPageUrl;
  mainVideo: MainVideo;
  maxRecommendedVideos: number = 5;

  constructor(private _VideoService: VideoListService) { }

  ngOnInit() {

    this._VideoService.getMainVideo()
      .subscribe((mainVideo) => {
        this.mainVideo = mainVideo;

        // main video as SubCategory
        if (typeof mainVideo.SubCategory.Title !== 'undefined' && mainVideo.SubCategory.Title !== '') {
          this._VideoService.getRecommendedVideosBySubCategory(mainVideo).subscribe(
            (videosBySubCategory) => {
              this.recommendedVideoList = videosBySubCategory;
            });
          if (this.recommendedVideoList.length < this.maxRecommendedVideos) {
              // code for Keywords
              this.recommendedKeywordsVideos();
          }
        }

        // main video as solution
        else if (typeof mainVideo.Solution.Title !== 'undefined' && mainVideo.Solution.Title !== '') {
          this._VideoService.getRecommendedVideosBySolution(mainVideo).subscribe(
            (videosBySolution) => {
              // checking videos by SubCategory
              this.recommendedVideoList = videosBySolution;
            });
          // Add videos from matching Keywords if Number is < 5
          if (this.recommendedVideoList.length < this.maxRecommendedVideos) {
              // code for Keywords
              this.recommendedKeywordsVideos();
          }
        }
      });
  }

  recommendedKeywordsVideos() {
    this._VideoService.getRecommendedVideosByKeywords(this.mainVideo).subscribe(
      (videosByKeywords) => {
        let recommendedKeywordsVideos = videosByKeywords;
        this.recommendedVideoList
          .forEach(element => {
            recommendedKeywordsVideos = recommendedKeywordsVideos.filter((video) => video.ID !== element.ID);
          });
        recommendedKeywordsVideos.splice((this.maxRecommendedVideos - this.recommendedVideoList.length),
             (recommendedKeywordsVideos.length));
        this.recommendedVideoList = recommendedKeywordsVideos.concat(this.recommendedVideoList);
      });
  }
}
