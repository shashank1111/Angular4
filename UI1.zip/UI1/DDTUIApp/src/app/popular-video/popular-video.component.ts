﻿import { Component, OnInit } from '@angular/core';

import { VideoListService } from '../services/videoList.service';
import { environment } from '../../environments/environment';

@Component({
    selector: 'app-popular-video',
    templateUrl: './popular-video.component.html',
    styleUrls: ['./popular-video.component.less']
})
export class PopularVideoComponent implements OnInit {

    videoPlayerPageUrl = environment.videoPlayerPageUrl;
    videoLikesList: any[];
    videoDetailsList: any[];

    constructor(public _VideoService: VideoListService) { }

    ngOnInit() {
        this.getPopularVideoData();
    }

    public getPopularVideoData() {

        this._VideoService.getMostViewedVideoIDs()
            .subscribe((videoIdListResponse) => {

                this.videoLikesList = videoIdListResponse;

                this._VideoService.getVideosByIds(this.videoLikesList)
                    .subscribe((mostViewedVideos) => {
                        this.videoDetailsList = mostViewedVideos;

                        this.videoLikesList.forEach(video => {
                            let videoDetails = this.videoDetailsList.find(videoDetails => videoDetails.ID === video.VideoID);
                            video.ThumbnailUrl = videoDetails.ThumbnailUrl.Url;
                            video.Title = videoDetails.Title;
                        });
                    });

            });

    }
}
