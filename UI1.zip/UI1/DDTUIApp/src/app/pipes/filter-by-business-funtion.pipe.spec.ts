import { FilterByBusinessFuntionPipe } from './filter-by-business-funtion.pipe';

describe('FilterByBusinessFuntionPipe', () => {
  it('create an instance', () => {
    const pipe = new FilterByBusinessFuntionPipe();
    expect(pipe).toBeTruthy();
  });
});
