import { Pipe, PipeTransform } from '@angular/core';

@Pipe({
  name: 'filterByBusinessFuntion'
})
export class FilterByBusinessFuntionPipe implements PipeTransform {
    transform(items: any, value: any): any[] {
        if (!items) return [];   
        return items[value];
  
    }
}

