import { Component, OnInit, NgZone, ElementRef, AfterViewInit } from '@angular/core';
import { DomSanitizer, SafeResourceUrl, SafeUrl } from '@angular/platform-browser';

import { SubCategoryVideo } from '../services/subCategoryVideo';
import { SubCategoryVideoService } from '../services/subCategoryVideo.service';
import { SubCategoryTitleService } from '../services/subCategoryTitle.service';

@Component({
  selector: 'app-subcategory-video',
  templateUrl: './subcategory-video.component.html',
  styleUrls: ['./subcategory-video.component.less']
})
export class SubcategoryVideoComponent implements OnInit, AfterViewInit {

  videos: SubCategoryVideo[];
  activeVideo: SubCategoryVideo;
  hoverVideo: SubCategoryVideo;
  safeActiveVideoUrl: SafeResourceUrl;
  activeCarouselVideo: SubCategoryVideo;
  safeCarouselVideoUrl: SafeResourceUrl;
  isSolution: boolean;
  analyticsString: string;
  videoContainerStyles= ['col-sm-8','col-lg-8','col-xs-12'];
  videoCenteredStyles= {};
  screenWidth: number;

  constructor(private subCategoryVideoService: SubCategoryVideoService,
    private sanitizer: DomSanitizer,
    private titleService: SubCategoryTitleService, ngZone: NgZone,
    private elementRef: ElementRef) { 
      window.onresize = (e) => {
        ngZone.run(() => {
          this.screenWidth = window.innerWidth;
        });
      };
    }

  ngOnInit() {
    this.screenWidth = window.innerWidth;
    this.getVideos();
  }

  ngAfterViewInit() {
    var s = document.createElement("script");
    s.type = "text/javascript";
    s.src = "https://dmp.deloittenet.deloitte.com/viewerportal/deloittenet/latestskin/js/qumu-embed-fs.js";
    this.elementRef.nativeElement.appendChild(s);
  }

  getVideos() {
    this.titleService.getPageTitleAndType().subscribe(pageTitle => {
      this.isSolution = pageTitle.isSolution;
      this.setAnalyticsString();
      this.subCategoryVideoService.getPageVideos(pageTitle.Title, this.isSolution).subscribe(videos => this.mapVideos(videos));
    });
  }

  setAnalyticsString(){
    if(this.isSolution){
      this.analyticsString = 'Solution';
    }else{
      this.analyticsString = 'Sub Category';
    }
  }

  mapVideos(videos: SubCategoryVideo[]) {
    this.videos = videos;
    this.setActiveVideo(videos[0]);
    if (videos.length <= 1) {
      this.removeVideoMenu();
    }
  }

  removeVideoMenu() {
    this.videoContainerStyles = [];
    this.videoContainerStyles = ['col-sm-12'];
    this.videoCenteredStyles = { 'margin': '0 auto', 'width': '67.1%' };
  }

  setActiveVideo(video: SubCategoryVideo) {
    if (video !== this.activeVideo) {
      const dangerousUrl = video.DMPUrl.Url;
      this.safeActiveVideoUrl = this.sanitizeUrl(dangerousUrl);
      this.activeVideo = video;
    }
  }

  onVideoMenuClick(newActiveVideo: SubCategoryVideo) {
    this.setActiveVideo(newActiveVideo);
  }

  setActviceCarouselVideo(newVideo: SubCategoryVideo) {
    if (newVideo !== this.activeCarouselVideo) {
      const dangerousUrl = newVideo.DMPUrl.Url;
      this.safeCarouselVideoUrl = this.sanitizeUrl(dangerousUrl);
      this.activeCarouselVideo = newVideo;
    }
  }

  onHover(video: SubCategoryVideo) {
    this.hoverVideo = video;
  }

  resetHover() {
    this.hoverVideo = this.activeVideo;
  }

  isActive(video: SubCategoryVideo) {
    if (video === this.activeVideo || video === this.hoverVideo) {
      return true;
    }
  }

  sanitizeUrl(url: string): SafeResourceUrl {
    return this.sanitizer.bypassSecurityTrustResourceUrl(url);
  }
}
