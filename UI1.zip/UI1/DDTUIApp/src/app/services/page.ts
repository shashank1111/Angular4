/* Page */
export class Page {
    Id: number;
    Title: string;
    QueryWords: string;
    FileRef: string;
    Url: string;
    DDT_x0020_Name?: string;
}
