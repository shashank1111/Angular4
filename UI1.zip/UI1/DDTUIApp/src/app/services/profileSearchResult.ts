export class ProfileSearchResult {
    firstName: string;
    lastName: string;
    preferredName: string;
    position: string;
    image: string;
    displayName: string;
    function: string;
    service: string;
    officeCity: string;
    officeCountry: string;
    email: string;
    alias: string;
    deskPhone: string;
    cellPhone: string;
}
