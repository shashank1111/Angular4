import { TestBed, inject } from '@angular/core/testing';

import { BuyingPatternsService } from './buying-patterns.service';

describe('BuyingPatternsService', () => {
  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [BuyingPatternsService]
    });
  });

  it('should ...', inject([BuyingPatternsService], (service: BuyingPatternsService) => {
    expect(service).toBeTruthy();
  }));
});
