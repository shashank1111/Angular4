import { Injectable } from '@angular/core';

import { environment } from '../../environments/environment';

// Uses analytics.js which is common for both SharePoint and Angular components
declare var trackAction: any;

@Injectable()
export class AnalyticsService {

    trackAction(tags: any, action: string, event: string) {
        console.log('AnalyticsService.TrackAction', tags, action, event);
        try {
            trackAction(tags, action, event);
        } catch (error){
            console.log('AnalyticsService Error: ' + error);
         }

    }
}
