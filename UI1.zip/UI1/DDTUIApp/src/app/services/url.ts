export class Url {
    Description: string;
    Url: string;
}
