﻿import { Injectable } from '@angular/core';
import { Http, Response, Headers, URLSearchParams } from '@angular/http';
import { Observable } from 'rxjs/Observable';
import 'rxjs/add/Operator/do';
import 'rxjs/add/Operator/catch';
import 'rxjs/add/Operator/map';
import 'rxjs/add/Operator/distinct';

import { environment } from '../../environments/environment';

export class MainVideo {
    SubCategory: any;
    Solution: any;
    Title: string;
    ID: string;
    TextKeyword: any = [];
}

export class Video {
    ID: string;
    Title: string;
    active: boolean;
}

export class SolutionSubCategoryVideo {
    Id: number;
    TextKeyword: string;
    SubCategory: any;
    Solution: any;
}

declare const VideoPopularity: any;

// This service provides all the data related to Video
@Injectable()
export class VideoListService {

    originalvideoSolutionSubCategoryUrl = environment.videoSolutionSubCategoryUrl;

    constructor(private _http: Http) {
    }

    getMainVideo(): Observable<MainVideo> {

        const headers = new Headers();
        this.createServiceHeader(headers);

        const hostname = location.hostname;
        if (environment.production === true) {
            environment.mainVideoServiceUrl = environment.mainVideoServiceUrl.replace('HOSTNAME', hostname);
        }

        return this._http.get(environment.mainVideoServiceUrl, {
            headers: headers
        })
            .map((response: Response) => <MainVideo>response.json().d.results[0])
            .do(data => {
                'getMainVideo Response : ' + JSON.stringify(data);
            })
            .catch(this.handleError);
    }

    getSolutionSubCategoryVideo(videoId: number): Observable<SolutionSubCategoryVideo> {

        const headers = new Headers();
        this.createServiceHeader(headers);

        const hostname = location.hostname;
        let requestUrl = this.originalvideoSolutionSubCategoryUrl;
        if (environment.production === true) {
            requestUrl = requestUrl.replace('HOSTNAME', hostname);
            requestUrl = requestUrl.replace('VIDEOID', videoId.toString());
        }

        return this._http.get(requestUrl, {
            headers: headers
        })
            .map((response: Response) => <SolutionSubCategoryVideo>response.json().d.results[0])
            .do(data => 'getSolutionSubCategoryVideo Response : ' + JSON.stringify(data))
            .catch(this.handleError);
    }

    getMostViewedVideoIDs(): Observable<any[]> {

        const VideoData = new Observable(observer => {

            try {
                const topviewVideosPromise = VideoPopularity.getTopViews();
                topviewVideosPromise.success(function (data) {

                    const videoIDsSubText = '';
                    const VideosByLikesCount: any = data.d.results;
                    observer.next(data.d.results);
                    observer.complete();


                });
            } catch (error) {
                console.log('getMostViewedVideoIDs Error');
            }
        });

        return VideoData;
    }

    getVideosByIds(VideoIdList: any[]): Observable<Video[]> {

        const headers = new Headers();
        this.createServiceHeader(headers);

        let videoIDsSubText = '';
        // TODO: Change to foreach
        for (let i = 0; i < VideoIdList.length; i++) {
            videoIDsSubText += '(ID\ eq ' + VideoIdList[i].VideoID + '\)';

            // Add 'or' for all items except last
            if (i !== (VideoIdList.length - 1)) {
                videoIDsSubText += ' or ';
            }
        }

        const hostname = location.hostname;
        let getVideosByIdsServiceUrl = environment.getVideosByIdsServiceUrl;
        if (environment.production === true) {
            getVideosByIdsServiceUrl = getVideosByIdsServiceUrl.replace('HOSTNAME', hostname);
            getVideosByIdsServiceUrl = getVideosByIdsServiceUrl.replace('VIDEOSBYID', (videoIDsSubText));
        }

        return this._http.get(getVideosByIdsServiceUrl, {
            headers: headers
        })
            .map((response: Response) => <Video[]>response.json().d.results)
            .do(data => console.log('GetVideosByIds Response : ' + JSON.stringify(data)))
            .catch(this.handleError);
    }

    getRecommendedVideosByKeywords(mainVideo: MainVideo): Observable<Video[]> {

        const headers = new Headers();
        this.createServiceHeader(headers);

        let recommendedVideoKeywordsServiceUrl = environment.recommendedVideoKeywordsServiceUrl;
        let index;
        let recommendedVideoKeywordsUrlSubText = '';

        const keywordsList = mainVideo.TextKeyword.split(',');
        for (index = 0; index < keywordsList.length; index++) {
            recommendedVideoKeywordsUrlSubText += 'substringof(\'' + keywordsList[index] + '\',TextKeyword)';
            // Add 'or' for all items except last
            if (index !== (keywordsList.length - 1)) {
                recommendedVideoKeywordsUrlSubText += ' or ';
            }
        }

        const hostname = location.hostname;
        if (environment.production === true) {
            recommendedVideoKeywordsServiceUrl = recommendedVideoKeywordsServiceUrl.replace('HOSTNAME', hostname);
        }

        recommendedVideoKeywordsServiceUrl = recommendedVideoKeywordsServiceUrl.replace(/RECOMMENDEDVIDEOKEYWORDSURLSUBTEXT/g,
            encodeURIComponent(recommendedVideoKeywordsUrlSubText));

        return this._http.get(recommendedVideoKeywordsServiceUrl, {
            headers: headers
        })
            .map((response: Response) =>
                // Filter out the mainvideo from the recommended video list
                <Video[]>response.json().d.results.filter(video => video.ID !== mainVideo.ID))
            .do(data => ('getRecommendedVideosByKeywords Response for MainVideo \'' + mainVideo.Title + '\' : ' + JSON.stringify(data)))
            .catch(this.handleError);
    }

    getRecommendedVideosBySolution(mainVideo: MainVideo): Observable<Video[]> {
        const headers = new Headers();
        this.createServiceHeader(headers);

        let recommendedVideoBySolutionUrl = environment.recommendedVideoBySolutionUrl;
        const hostname = location.hostname;
        if (environment.production === true) {
            recommendedVideoBySolutionUrl = recommendedVideoBySolutionUrl.replace('HOSTNAME', hostname);
        }

        recommendedVideoBySolutionUrl = recommendedVideoBySolutionUrl.replace('SOLUTION',
            encodeURIComponent(mainVideo.Solution.Title));

        return this._http.get(recommendedVideoBySolutionUrl, {
            headers: headers
        })
            .map((response: Response) =>
                // Filter out the mainvideo from the recommended video list
                <Video[]>response.json().d.results.filter(video => video.ID !== mainVideo.ID))
            .do(data => ('getRecommendedVideosBySolution Response for MainVideo \'' + mainVideo.Title + '\' : ' + JSON.stringify(data)))
            .catch(this.handleError);
    }

    getRecommendedVideosBySubCategory(mainVideo: MainVideo): Observable<Video[]> {
        const headers = new Headers();
        this.createServiceHeader(headers);

        let recommendedVideoSubCatServiceUrl = environment.recommendedVideoSubCatServiceUrl;
        const hostname = location.hostname;
        if (environment.production === true) {
            recommendedVideoSubCatServiceUrl = recommendedVideoSubCatServiceUrl.replace('HOSTNAME', hostname);
        }

        recommendedVideoSubCatServiceUrl = recommendedVideoSubCatServiceUrl.replace('SUBCATEGORY',
            encodeURIComponent(mainVideo.SubCategory.Title));

        return this._http.get(recommendedVideoSubCatServiceUrl, {
            headers: headers
        })
            .map((response: Response) =>
                // Filter out the mainvideo from the recommended video list
                <Video[]>response.json().d.results.filter(video => video.ID !== mainVideo.ID)
            )

            .do(data => ('getRecommendedVideosBySubCategory Response for MainVideo \'' + mainVideo.Title + '\' : ' + JSON.stringify(data)))
            .catch(this.handleError);
    }

    getAllVideos(): Observable<Video[]> {

        const headers = new Headers();
        this.createServiceHeader(headers);

        const hostname = location.hostname;
        if (environment.production === true) {
            environment.getAllVideosUrl = environment.getAllVideosUrl.replace('HOSTNAME', hostname);
        }

        return this._http.get(environment.getAllVideosUrl, {
            headers: headers
        })
            .map((response: Response) => <Video[]>response.json().d.results)
            .do(data => {
                'getAllVideos Response : ' + JSON.stringify(data);
            })
            .catch(this.handleError);
    }

    getSearchedVideos(searchTerm): Observable<Video[]> {

        const headers = new Headers();
        this.createServiceHeader(headers);
        let getSearchedVideosUrl = environment.getSearchedVideosUrl;
        const hostname = location.hostname;
        if (environment.production === true) {
            getSearchedVideosUrl = getSearchedVideosUrl.replace('HOSTNAME', hostname);
            getSearchedVideosUrl = getSearchedVideosUrl.replace(/\SEARCHTERM/g, searchTerm);
        }

        return this._http.get(getSearchedVideosUrl, {
            headers: headers
        })
            .map((response: Response) => <Video[]>response.json().d.results)
            .do(data => {
                ('getSearchedVideosUrl Response for \'' + searchTerm + '\'' + JSON.stringify(data));
            })
            .catch(this.handleError);
    }

    getVideosByBusiness(selectedBusinesses: string[]): Observable<Video[]> {

        const headers = new Headers();
        this.createServiceHeader(headers);
        const hostname = location.hostname;

        let getVideosByBusinessUrl = environment.getVideosByBusinessUrl;

        let index;
        let videoFilterBusinessSubText = '';
        for (index = 0; index < selectedBusinesses.length; index++) {
            videoFilterBusinessSubText += 'substringof(\'' + selectedBusinesses[index] + '\',BusinessFunction/Title)';
            // Add 'or' for all items except last
            if (index !== (selectedBusinesses.length - 1)) {
                videoFilterBusinessSubText += ' or ';
            }
        }
        if (environment.production === true) {
            getVideosByBusinessUrl = getVideosByBusinessUrl.replace('HOSTNAME', hostname);
            getVideosByBusinessUrl = getVideosByBusinessUrl.replace(/BUSINESSFILTERTEXT/g, encodeURIComponent(videoFilterBusinessSubText));
        }

        console.log('getVideosByBusiness Request :' + getVideosByBusinessUrl);
        console.log('videoFilterBusinessSubText :' + videoFilterBusinessSubText);

        return this._http.get(getVideosByBusinessUrl, {
            headers: headers
        })
            .map((response: Response) => <Video[]>response.json().d.results)
            .do(data => {
                console.log('getVideosByBusiness Response for \'' + selectedBusinesses + '\'' + JSON.stringify(data));
            })
            .catch(this.handleError);
    }

    getMultipleSubcategoryMainVideo(subcategories) {
        var SubCategories = subcategories.SubCategories || "";
        const subCategoriesOptions = SubCategories.split(';');
        let queryString: string;

        subCategoriesOptions.map((subCategory, index, arr) => {
            if (index < 1) {
                queryString = "$filter=((";
            }
            if (arr.length - 1 === index) {
                queryString += "(SubCategory/Title eq %27" + encodeURIComponent(subCategory) + "%27))%20and%20(IsSubcategoryFeatured%20eq%201))";
            } else {
                queryString += "(SubCategory/Title eq %27" + encodeURIComponent(subCategory) + "%27) or ";
            }
        });

        const headers = new Headers();
        this.createServiceHeader(headers);

        const hostname = location.hostname;
        if (environment.production === true) {
            environment.getMutipleSubcategoryMainVideoUrl = environment.getMutipleSubcategoryMainVideoUrl.concat(queryString).replace('HOSTNAME', hostname);
        }

        return this._http.get(environment.getMutipleSubcategoryMainVideoUrl, {
            headers: headers
        })
            .map((response: Response) => (response.json()).d.results)
            .catch(this.handleError);

    }


    private createServiceHeader(headers: Headers) {
        headers.append('Accept', 'application/json;odata=verbose;charset=utf-8');
    }

    private handleError(error: Response) {
        console.error('VideoListService Error : ' + error);
        return Observable.of<any>();
    }
}
