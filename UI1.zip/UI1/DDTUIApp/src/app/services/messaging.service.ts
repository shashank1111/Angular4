import { Injectable } from '@angular/core';
import { Subject } from 'rxjs/Subject';
import { SubCategoryVideo } from './subCategoryVideo';

@Injectable()
export class MessagingService {

    // Observable sources
    private mainVideoLoaded = new Subject<SubCategoryVideo>();

    // Observable streams
    mainVideoLoaded$ = this.mainVideoLoaded.asObservable();

    // Service message commands
    messageMainVideoLoaded(video: SubCategoryVideo) {
        this.mainVideoLoaded.next(video);
    }

}