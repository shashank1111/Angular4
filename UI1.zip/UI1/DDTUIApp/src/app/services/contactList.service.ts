import { Injectable } from '@angular/core';
import { Http, Response, Headers } from '@angular/http';
import { Observable } from 'rxjs/Observable';
import { Contact } from './contact';
import { ProfileSearchResult } from './profileSearchResult';
import { InstantFindService } from './instantfind.service';
import 'rxjs/add/Operator/do';
import 'rxjs/add/Operator/catch';
import 'rxjs/add/Operator/map';

import { environment } from '../../environments/environment';

@Injectable()
export class ContactListService {

    constructor(private _http: Http, private _InstantFindService: InstantFindService) {
    }

    getContactSearch(contact: Contact): Observable<ProfileSearchResult> {        
        if (contact.Email !== undefined && contact.Email != '') {            
        return this._InstantFindService.SearchDnpProfile(contact.Email)
            .map((response: Response) => response)
            .map((profileResponse: Response) => {
                const profile = profileResponse[0];
                if (profile !== undefined && profile.content !== undefined) {
                    return <ProfileSearchResult>profile.content;
                }
                return null;
            })
            .catch(this.handleError);
        }
        return null;
    }

 getContactList(title: string, isSolution: boolean): Observable<Contact[]> {
          const headers = new Headers();
        const hostname = location.hostname;
        this.createContactServiceHeader(headers);

        if (environment.production === true) {
            environment.contactServiceUrl = environment.contactServiceUrl.replace('HOSTNAME', hostname);
            if (isSolution) {
                environment.contactServiceUrl = environment.contactServiceUrl.replace('SUBCATEGORYTITLE', '');
                environment.contactServiceUrl =
                    environment.contactServiceUrl.replace('SOLUTIONTITLE', encodeURIComponent(title));
            } else {
                environment.contactServiceUrl =
                    environment.contactServiceUrl.replace('SUBCATEGORYTITLE', encodeURIComponent(title));
                environment.contactServiceUrl = environment.contactServiceUrl.replace('SOLUTIONTITLE', '');
            }

        }
        return this._http.get(environment.contactServiceUrl, {
            headers: headers
        })
            .map((response: Response) => response)
            .map((contacts: Response) => {
                const con = contacts.json();
                if (con !== undefined && con.d !== undefined && con.d.results !== undefined) {
                    return <Contact[]>con.d.results;
                }
                return <Contact[]>[];
            })
            .catch(this.handleError);
    }

    private createContactServiceHeader(headers: Headers) {
        headers.append('Accept', 'application/json;odata=verbose;charset=utf-8');
    }

    private handleError(error: Response) {
        console.error('getContactList Error : ' + error);
        return Observable.throw(error.json().error || 'server error');
    }
}
