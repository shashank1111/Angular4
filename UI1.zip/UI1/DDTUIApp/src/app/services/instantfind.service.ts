import { Injectable } from '@angular/core';
import { Http, Response, Headers } from '@angular/http';
import { Observable } from 'rxjs/Observable';
import { ProfileSearchResult } from './profileSearchResult';
import 'rxjs/add/Observable/of';
import 'rxjs/add/Operator/do';
import 'rxjs/add/Operator/catch';
import 'rxjs/add/Operator/map';
import 'rxjs/add/Operator/mergeMap';

import { environment } from '../../environments/environment';

export class SearchResult {
    content: SearchResultDDTContent;
    score: string;
    active:boolean;
}

export class SearchResultDDTContent {
    displayName: string;
    subText: string;
    url: string;
    isSubCategory: string;
}

@Injectable()
export class InstantFindService {
    accessToken = '';
    accessTokenExpiration = '';
    instantFindAccessTokenUrl = '';

    constructor(private _http: Http) {
    }

    Search(searchText): Observable<SearchResult[]> {
        let headers = new Headers();

        this.createServiceHeader(headers);

        // Get required URLs from the environment
        this.instantFindAccessTokenUrl = environment.instantFindAccessTokenUrl;
        if (environment.production === true) {
            const hostname = location.hostname;
            this.instantFindAccessTokenUrl = this.instantFindAccessTokenUrl.replace('HOSTNAME', hostname);
        }

        // Get required URLs from the environment
        let instantFindSearchUrl =
            this.getApiHostNameBasedOnEnvironment(environment.instantFindSearchUrl);

        // If Access Token available in the session, use it
        if (this.getAccessTokenFromCache() != null) {
            return this.callInstantFindService(headers, this.getAccessTokenFromCache(), 
                   searchText, instantFindSearchUrl);
        } else {
            // Call to get the Access Token first & call the instant find service with it
            return this.callAccessTokenService(headers).mergeMap(
                accessToken => this.callInstantFindService(headers, accessToken.token, 
                searchText, instantFindSearchUrl));
        }
    }

    SearchDnpProfile(emailId): Observable<any> {
        const headers = new Headers();
        this.createServiceHeader(headers);

        this.instantFindAccessTokenUrl = environment.instantFindAccessTokenUrl;
        if (environment.production === true) {
            const hostname = location.hostname;
            this.instantFindAccessTokenUrl = this.instantFindAccessTokenUrl.replace('HOSTNAME', hostname);
        }

        // Get required URLs from the environment
        let instantFindProfileUrl =
            this.getApiHostNameBasedOnEnvironment(environment.instantFindProfileUrl);

        // If Access Token available in the session, use it
        if (this.getAccessTokenFromCache() != null) {
            return this.callInstantFindService(headers, this.getAccessTokenFromCache(),
                emailId, instantFindProfileUrl);
        } else {
            // Call to get the Access Token first & call the instant find service with it
            return this.callAccessTokenService(headers).mergeMap(
                accessToken => this.callInstantFindService(headers, accessToken.token, emailId
                    , instantFindProfileUrl));
        }

    }

    private callAccessTokenService(headers): Observable<any> {

        return this._http.get(this.instantFindAccessTokenUrl, {
            headers: headers
        })
            .map((response: Response) => <any>response.json())
            .do(accessToken => {
                console.log('InstantFindService - Access Token Response', accessToken);
                // Store the Access token as it valid for 15 mins
                this.storeAccessTokenInCache(accessToken.token, accessToken.expires);
            })
            .catch(this.handleError);
    }

    private callInstantFindService(headers, accessToken, searchText, instantFindSearchUrl): Observable<any> {

        // Append the Access token as a header
        const AuthHeader = 'Bearer ' + accessToken;
        headers.append('Authorization', AuthHeader);

        // Update the search text with local variable
        const instantFindUrl = instantFindSearchUrl.replace('SEARCHTEXT', searchText);

        return this._http.get(instantFindUrl, {
            headers: headers
        })
            .map((response: Response) => <any>response.json().results)
            .do(data => console.log('InstantFindService Search Response for \'' + searchText + '\' : ', data))
            .catch(this.handleError);
    }

    private createServiceHeader(headers: Headers) {
        headers.append('Accept', 'application/json;odata=verbose;charset=utf-8');
    }

    private handleError(error: Response) {
        console.error('InstantFindService Search Error : ' + error);
        return Observable.of<any[]>([]);
    }

    private getAccessTokenFromCache() {
        let accessToken = sessionStorage.getItem('accessToken');
        let accessTokenExpiration = sessionStorage.getItem('accessTokenExpiration');

        if (!accessToken) {
            accessToken = this.accessToken;
            accessTokenExpiration = this.accessTokenExpiration;
        }

        if (accessToken && accessTokenExpiration) {
            const date = new Date();
            if (parseInt(accessTokenExpiration, 10) >= Math.ceil(date.getTime() / 1000)) {
                return accessToken;
            }
        }

        return null;
    }

    private storeAccessTokenInCache(token, expiration) {
        if (token && expiration) {
            try {
                sessionStorage.setItem('accessToken', token);
                sessionStorage.setItem('accessTokenExpiration', expiration);
            } catch (e) {
                // Session storage not be avalible for some of the browser mode
                // example safari inprivate session storage willl not work.
                this.accessToken = token;
                this.accessTokenExpiration = expiration;
            }
        }
    }

    // TODO: better logic to avoid hardcoding
    private getApiHostNameBasedOnEnvironment(instantFindUrl: string) {
        const hostname = location.hostname;
        let instantFindSpecificUrl = '';

        if (hostname === 'deloittenet.deloitte.com') {
            instantFindSpecificUrl = instantFindUrl.replace('HOSTNAME', 'api.instantfind.deloittenet.deloitte.com');
        } else if (hostname === 'sdnet2013.hosting.deloitte.com' || hostname === 'sdnet2.hosting.deloitte.com') {
            instantFindSpecificUrl = instantFindUrl.replace('HOSTNAME', 'sapi.instantfind.deloittenet.deloitte.com');
        } else if (hostname === 'ldnet2013.hosting.deloitte.com' || hostname === 'ldnet2.hosting.deloitte.com') {
            instantFindSpecificUrl = instantFindUrl.replace('HOSTNAME', 'lapi.instantfind.deloittenet.deloitte.com');
        } else if (hostname === 'qdnet2013.hosting.deloitte.com' || hostname === 'qdnet2.hosting.deloitte.com') {
            instantFindSpecificUrl = instantFindUrl.replace('HOSTNAME', 'qapi.instantfind.deloittenet.deloitte.com');
        } else {
            instantFindSpecificUrl = instantFindUrl.replace('HOSTNAME', 'dapi.instantfind.deloittenet.deloitte.com');
        }

        return instantFindSpecificUrl;
    }
}
