import { Injectable } from '@angular/core';
import { Http, Response, Headers } from '@angular/http';
import { Observable } from 'rxjs/Observable';

import { VideoComment } from './videoComment';
import { CachedDigest } from './cachedDigest';
import { environment } from '../../environments/environment';

/* const cache: CachedDigest = null;*/

@Injectable()
export class VideoCommentService {

    cachedDigest: CachedDigest = null;

    constructor(private http: Http) { }

    getCommentsByVideoId(videoId: number, originalUrl: string): Observable<VideoComment[]> {
        const hostname = location.hostname;
        const headers = new Headers();
        this.createHeaders(headers);

        if (environment.production === true) {
            originalUrl = originalUrl.replace('HOSTNAME', hostname);
            originalUrl = originalUrl.replace('VIDEOID', videoId.toString());
        }

        return this.http.get(originalUrl, {
            headers: headers
        })
            .map((response: Response) => <VideoComment[]>response.json().d.results)
            .catch(this.handleError);
    }

    getCurrentUserId(): Observable<number> {
        const hostname = location.hostname;
        const headers = new Headers();
        this.createHeaders(headers);
        if (environment.production === true) {
            environment.getCurrentUserUrl = environment.getCurrentUserUrl.replace('HOSTNAME', hostname);
        }

        return this.http.get(environment.getCurrentUserUrl, {
            headers: headers
        })
            .map((response: Response) => <number>response.json().d.Id)
            .catch(this.handleError);
    }

    postComment(commentProperties: Object, requestDigest: string): any {
        const hostname = location.hostname;
        const headers = new Headers({
            "Accept": "application/json;odata=verbose",
            "Content-type": "application/json;odata=verbose;charset=utf-8",
            "X-RequestDigest": requestDigest
        });
        let itemType = this.getItemTypeForListName('Comments');
        commentProperties["__metadata"] = { "type": itemType };

        if (environment.production === true) {
            environment.postCommentUrl = environment.postCommentUrl.replace('HOSTNAME', hostname);
        }

        console.log(environment.postCommentUrl);

        return this.http.post(environment.postCommentUrl, JSON.stringify(commentProperties), { headers: headers })
            .map((response: Response) => response.json())
            .catch(this.handleError);
    }

    private getItemTypeForListName(name) {
        return "SP.Data." + name.charAt(0).toUpperCase() + name.split(" ").join("").slice(1) + "ListItem";
    }

    private createHeaders(headers: Headers) {
        headers.append('Accept', 'application/json;odata=verbose;charset=utf-8');
    }

    private handleError (error: Response | any) {
        let errMsg: string;
        if (error instanceof Response) {
            const body = error.json() || '';
            const err = body.error || JSON.stringify(body);
            errMsg = `${error.status} - ${error.statusText || ''} ${err}`;
        } else {
            errMsg = error.message ? error.message : error.toString();
        }
        console.error(errMsg);
        return Observable.throw(errMsg);
    }

}
