/* Class Contact */
export class Contact {
    Name: string;
    PreferedFirstName: string;
    LastName: string;
    Description: string;
    Email: string;
    EmailId: string;
    UserAlias: string;
    Image: string;
    Profile: string;
}
