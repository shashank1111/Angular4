﻿import { Component, OnInit, NgZone, ElementRef, AfterViewInit } from '@angular/core';
import { DomSanitizer, SafeResourceUrl, SafeUrl } from '@angular/platform-browser';

import { SubCategoryVideo } from '../services/subCategoryVideo';
import { SubCategoryVideoService } from '../services/subCategoryVideo.service';
import { UtilsService } from '../services/utils.service';
import { MessagingService } from '../services/messaging.service';

declare let VideoPopularity: any;

@Component({
    selector: 'app-video-page-player',
    templateUrl: './video-page-player.component.html',
    styleUrls: ['./video-page-player.component.less']
})
export class VideoPagePlayerComponent implements OnInit, AfterViewInit {

    videos: SubCategoryVideo[];
    activeVideo: SubCategoryVideo;
    hoverVideo: SubCategoryVideo;
    safeActiveVideoUrl: SafeResourceUrl;
    activeCarouselVideo: SubCategoryVideo;
    safeCarouselVideoUrl: SafeResourceUrl;
    videoId: number;
    videoContainerStyles = ['col-sm-8', 'col-lg-8', 'col-xs-12'];
    videoCenteredStyles = {};
    screenWidth: number;

    constructor(private subCategoryVideoService: SubCategoryVideoService,
        private sanitizer: DomSanitizer, ngZone: NgZone, private utilsService: UtilsService,
        private _messagingService: MessagingService,
        private elementRef: ElementRef) {
        window.onresize = (e) => {
            ngZone.run(() => {
                this.screenWidth = window.innerWidth;
            });
        };
    }

    ngOnInit() {
        this.screenWidth = window.innerWidth;
        this.videoId = this.utilsService.getUrlParamaterCaseInsensitive('videoId');
        this.getVideos();
    }

    ngAfterViewInit() {
        var s = document.createElement("script");
        s.type = "text/javascript";
        s.src = "https://dmp.deloittenet.deloitte.com/viewerportal/deloittenet/latestskin/js/qumu-embed-fs.js";
        this.elementRef.nativeElement.appendChild(s);
    }

    getVideos() {
        this.subCategoryVideoService.getVideoById(this.videoId)
            .flatMap(
            video =>
                this.subCategoryVideoService.getVideoPageVideos(video, video.Title))
            .subscribe(
            videos =>
                this.mapVideos(videos));
    }

    mapVideos(videos: SubCategoryVideo[]) {
        const mainVideoId = this.videoId;
        this.promoteVideo(mainVideoId, videos);
        this.videos = videos;
        this.setActiveVideo(videos[0]);
        if (videos.length <= 1) {
            this.removeVideoMenu();
        }
    }

    removeVideoMenu() {
        this.videoContainerStyles = [];
        this.videoContainerStyles = ['col-sm-12'];
        this.videoCenteredStyles = { 'margin': '0 auto', 'width': '67.1%' };
    }

    promoteVideo(mainVideoId: number, videos: SubCategoryVideo[]) {
        for (let i = 0; i < videos.length; i++) {
            if (videos[i].Id == mainVideoId) {
                const a = videos.splice(i, 1);
                videos.unshift(a[0]);
                break;
            }
        }
    }

    setActiveVideo(video: SubCategoryVideo) {
        // Send messsage, so that other component in the page can use the details 

        this._messagingService.messageMainVideoLoaded(video);

        if (video !== this.activeVideo) {
            let dangerousUrl = video.DMPUrl.Url;
            dangerousUrl = dangerousUrl + '&autoplay=true';
            this.safeActiveVideoUrl = this.sanitizeUrl(dangerousUrl);
            this.activeVideo = video;
            if (this.videoId != this.activeVideo.Id) {
                this.videoId = this.activeVideo.Id;
                let stateObj = { foo: "bar" };
                window.history.pushState(stateObj, "", "?videoId=" + this.videoId);
            }
        }
        try {
            VideoPopularity.addView(this.activeVideo.Id);
        }
        catch (error) {
            console.log("Video popular add failed" + error);
        }

    }

    onVideoMenuClick(newActiveVideo: SubCategoryVideo) {
        this.setActiveVideo(newActiveVideo);
    }

    onHover(video: SubCategoryVideo) {
        this.hoverVideo = video;
    }

    resetHover() {
        this.hoverVideo = this.activeVideo;
    }

    isActive(video: SubCategoryVideo) {
        if (video === this.activeVideo || video === this.hoverVideo) {
            return true;
        }
    }

    sanitizeUrl(url: string): SafeResourceUrl {
        return this.sanitizer.bypassSecurityTrustResourceUrl(url);
    }

}


