import { Component, OnInit } from '@angular/core';
import { Observable } from 'rxjs/Observable';

import { ContactListService } from '../services/contactList.service';
import { Contact } from '../services/Contact';
import { SubCategoryTitleService } from '../services/subCategoryTitle.service';
import { UtilsService } from '../services/utils.service';
import { environment } from '../../environments/environment';

@Component({
  selector: 'app-contacts',
  templateUrl: './contact.component.html',
  styleUrls: ['./contact.component.less']
})
export class ContactComponent implements OnInit {

  retrievedContactList: Contact[];
  currentSubcategoryOrSolution: string;
  isSolution: boolean;
  browserVersion: any;

  constructor(private _contactListService: ContactListService, private _titleService: SubCategoryTitleService,
    private _utilsService: UtilsService) { }

  ngOnInit() {
    this.browserVersion = this._utilsService.detectIE();
    this.getContacts();
  }

  getContacts() {
    this._titleService.getPageTitleAndType()
      .flatMap(pageTitle => {
        this.isSolution = pageTitle.isSolution;
        this.trackAnalytics(pageTitle.Title);
        return this._contactListService.getContactList(pageTitle.Title, pageTitle.isSolution);
      })
      .subscribe(contactList => {
        this.retrievedContactList = contactList;
        this.retrievedContactList.forEach((contact) => {
          this._contactListService.getContactSearch(contact)
            .subscribe((contactProfile) => {
              contact.Profile = environment.dnpProfileUrl.replace('USERALIAS', encodeURIComponent(contact.UserAlias.trim()));
              contact.Image = environment.imageDefaultContact;
              if (contactProfile !== null) {
                if (contactProfile.image !== undefined && contactProfile.image !== null && contactProfile.image !== '') {
                  contact.Image = 'data:image/jpg;base64,' + contactProfile.image;
                }
              }              
              contact.Name = contact.PreferedFirstName + ' ' + contact.LastName;
              if(this.browserVersion){
                contact.Description = this.snipRole(contact.Description);
              }
            });
        });
      });
  }

  private snipRole(role: string){
    if (role.length > 48){
      role = role.substring(0, 48);
      return role += '...';
    }else{
      return role;
    }
  }

  private trackAnalytics(title: string) {
    this.currentSubcategoryOrSolution = title;
  }
}
