import { Component, OnChanges, Input, SimpleChange, OnInit } from '@angular/core';

import { VideoComment } from '../services/videoComment';
import { VideoCommentService } from '../services/videoComment.service';
import { DigestService } from '../services/digest.service'
import { environment } from '../../environments/environment';

@Component({
  selector: 'app-video-comment',
  templateUrl: './video-comment.component.html',
  styleUrls: ['./video-comment.component.less']
})
export class VideoCommentComponent implements OnChanges, OnInit {

  comments: VideoComment[];
  commentText = '';
  currentUserId: number;
  isLoading = false;
  originalUrl: string = environment.videoCommentsUrl;
  digest: string;
  @Input() videoId: number;

  constructor(private videoCommentService: VideoCommentService, private digestService: DigestService) { }

  ngOnInit() {
    this.videoCommentService.getCurrentUserId().subscribe(userId => this.currentUserId = userId);
  }

  ngOnChanges(changes: { [propKey: string]: SimpleChange }) {
    for (const propName in changes) {
      if (propName === 'videoId') {
        if (this.videoId !== undefined && this.videoId != null) {
          this.updateUI();
        }
      }
    }
  }

  updateUI() {
    this.videoCommentService.getCommentsByVideoId(this.videoId, this.originalUrl).subscribe(comments => this.comments = comments);
    this.commentText = '';
  }

  postComment() {
    this.isLoading = true;
    let itemProperties = {
      'Description': this.commentText,
      'CommentedById': this.currentUserId,
      'VideoIdId': this.videoId
    };
    this.digestService.getDigest()
      .subscribe(
      digest =>
        this.videoCommentService.postComment(itemProperties, digest)
          .subscribe(
          res => this.afterPost(res)
          ));
  }

  afterPost(res: any) {
    this.updateUI();
    this.isLoading = false;
  }

}
