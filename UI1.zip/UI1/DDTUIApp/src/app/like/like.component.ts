import { Component, OnInit, Input, SimpleChange, OnChanges } from '@angular/core';
import { environment } from '../../environments/environment';
import { LikeVideoService } from '../services/likeVideoService.service';

@Component({
  selector: 'app-like',
  templateUrl: './like.component.html',
  styleUrls: ['./like.component.less']
})

export class LikeComponent implements OnChanges {

  unlikeStyle = 'icon1-unlike';
  likeStyle = 'icon1-like';
  isUserLiked: boolean;
  numLikes: number;
  descriptionLike: string;
  styleLiked: string;
  @Input() videoId: number;

  constructor(public _LikeVideoService: LikeVideoService) {
  }

  ngOnChanges(changes: {[propKey: string]: SimpleChange}) {
    for (const propName in changes) {
      if (propName === 'videoId') {
        if (this.videoId !== undefined && this.videoId != null) {
          this.updateUI();
        }
      }
    }
  }

  updateUI() {
    this.updateLikeVideo();
  }

  likeVideo() {
    this._LikeVideoService.like(this.videoId, (userRatingVid) => {
      this.handleUserLiked(userRatingVid);
    }, () => {
      console.error('Fail like');
    });
  }

  unLikeVideo() {
    this._LikeVideoService.unlike(this.videoId, (userRatingVid) => {
      this.handleUserLiked(userRatingVid);
    }, () => {
      console.error('Fail unlike');
    });
  }

  likeUnlikeVideo() {
    if (this.isUserLiked === true) {
        this.unLikeVideo();
    } else {
      this.likeVideo();
    }
  }

  handleUserLiked(userRatingVid) {
    this.styleLiked = this.unlikeStyle;
    this.descriptionLike = '';
    this.numLikes = 0;
    if (userRatingVid !== undefined && userRatingVid !== null) {
      if (userRatingVid.NumOfLikes !== undefined && userRatingVid.NumOfLikes !== null ) {
          this.numLikes = userRatingVid.NumOfLikes;
      }
      if (userRatingVid.IsUserLiked !== undefined && userRatingVid.IsUserLiked !== null ) {
        this.isUserLiked = userRatingVid.IsUserLiked;
      }
    }
    this.updateDescriptionLike();
  }

updateLikeVideo() {
    this._LikeVideoService.getLikes(this.videoId, (userRatingVid) => {
       this.handleUserLiked(userRatingVid);
    }, () => {} );
  }

  updateDescriptionLike() {
    if (this.numLikes > 0) {
      if (this.isUserLiked === true) {
        this.styleLiked = this.likeStyle;
        this.descriptionLike = this.descriptionUserLike(this.numLikes);
      } else {
        this.descriptionLike = this.descriptionUserUnLike(this.numLikes);
      }
    }
  }

  private descriptionUserLike(numLikes: number): string {
    if (numLikes > 2) {
      return 'You and ' + (numLikes - 1) + ' people liked this video';
    } else if (numLikes > 1) {
      return 'You and another person liked this video';
    }
    return 'You liked this video';
  }

  private descriptionUserUnLike(numLikes: number): string {
    if (numLikes > 1) {
      return numLikes + ' people liked this video';
    }
    return this.descriptionLike = '1 person liked this video';
  }
}
