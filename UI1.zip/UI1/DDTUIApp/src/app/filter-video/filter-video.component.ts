﻿import { Component, OnInit, ElementRef, NgZone } from '@angular/core';

import { VideoListService } from '../services/videoList.service';
import { environment } from '../../environments/environment';

import { PagerService } from '../services/pagingService';
const _ = require('underscore')._;


@Component({
    selector: 'app-filter-video',
    templateUrl: './filter-video.component.html',
    styleUrls: ['./filter-video.component.less'],
    host: {
        '(document:click)': 'onClick($event)',
    },
})

export class FilterVideoComponent implements OnInit {

    searchTerm = '';
    selectedBusinessList: string[] = [];

    advisoryChecked = false;
    crossBusinessChecked = false;
    auditChecked = false;
    consultingChecked = false;
    taxChecked = false;
    toggle: boolean;

    // array of all items to be paged
    videoListDetails: any;

    // paged items
    filteredList: any[];

    // pager object
    pager: any = {};

    pageSize = 12;

    // Number of pages displayed on pagination please select any odd number;
    pageshown = 5;

    videoPlayerPageUrl = environment.videoPlayerPageUrl;

    constructor(private _VideoService: VideoListService, private pagerService: PagerService) { }

    ngOnInit() {
        this.selectAllBusiness();
    }

    setPage(page: number) {
        if (page < 1 || page > this.pager.totalPages) {
            return;

        }

        // get pager object from service
        this.pager = this.pagerService.getPager(this.videoListDetails.length, page, this.pageSize, this.pageshown);

        // get current page of items
        this.filteredList = this.videoListDetails.slice(this.pager.startIndex, this.pager.endIndex + 1);
    }

    public getVideoListForSearch() {
        this.advisoryChecked = true;
        this.crossBusinessChecked = true;
        this.auditChecked = true;
        this.consultingChecked = true;
        this.taxChecked = true;
        this.selectedBusinessList = ['Cross-Business', 'Advisory', 'Audit', 'Consulting', 'Tax'];

        this.searchTerm = this.searchTerm.trim();
        if (this.searchTerm === '' || this.searchTerm === null) {
            return;
        }
        this._VideoService.getSearchedVideos(this.searchTerm)
            .subscribe((searchVideos) => {

                if (searchVideos.length > 0) {
                    // set items to json response
                    this.videoListDetails = searchVideos;
                    // initialize to page 1
                    this.setPage(1);
                }
                else {
                    this.filteredList = [];
                }

            });
    }

    selectAllBusiness() {
        this.advisoryChecked = true;
        this.crossBusinessChecked = true;
        this.auditChecked = true;
        this.consultingChecked = true;
        this.taxChecked = true;
        this.selectedBusinessList = [];
        this.selectedBusinessList = ['Cross-Business', 'Advisory', 'Audit', 'Consulting', 'Tax'];

        this._VideoService.getVideosByBusiness(this.selectedBusinessList)
            .subscribe((allBusinessVideos) => {

                // set items to json response
                this.videoListDetails = allBusinessVideos;
                // initialize to page 1
                this.setPage(1);
            });
    }

    deSelectAllBusiness() {

        this.advisoryChecked = false;
        this.crossBusinessChecked = false;
        this.auditChecked = false;
        this.consultingChecked = false;
        this.taxChecked = false;
        this.selectedBusinessList = [];
        this.filteredList = [];

    }

    public filterResults(event) {
        this.toggle = true;

        if (event.target.checked === true) {
            this.selectedBusinessList.push(<string>event.target.value);
        } else {
            this.selectedBusinessList = this.selectedBusinessList.filter(value => value !== event.target.value);
        }

        if (this.selectedBusinessList.length !== 0) {
            this._VideoService.getVideosByBusiness(this.selectedBusinessList)
                .subscribe((businessVideos) => {

                    this.videoListDetails = businessVideos;
                    // initialize to page 1
                    this.setPage(1);
                });
        }
        else if (this.selectedBusinessList.length === 0) {
            this.filteredList = [];
        }
    }

    backSlashClear(event) {
        if (event.key === "Backspace") {
            if(this.searchTerm === ''){
                this.clearResults();
            }
        }
    }

    clearResults() {

        this.searchTerm = '';

        this.selectAllBusiness();
    }

    firstEllipses() {
        if (this.pager.startPage < this.pager.pages.length) {
            this.setPage(this.pager.startPage - 1);
        }
        else {
            const getPreviousSet = this.pager.pages[0] - Math.ceil(((this.pager.endPage + 1) - this.pager.startPage) / 2);
            this.setPage(getPreviousSet);
        }
    }

    lastEllipses() {
        if (this.pager.endPage + this.pager.pages.length - 1 > this.pager.totalPages) {
            this.setPage(this.pager.endPage + 1);
        }
        else {
            const getNextSet = this.pager.pages[this.pager.pages.length - 1] + Math.ceil(((this.pager.endPage + 1) - this.pager.startPage) / 2);
            this.setPage(getNextSet);
        }
    }

    // Code for collapsing dropdown
    onClick(event) {
        if (event.target.classList.contains('selectOptionblock') || event.target.classList.contains('option') ||
            event.target.classList.contains('BlueBorder') || event.target.classList.contains('rotate') ||
            event.target.classList.contains('groupOption') || event.target.classList.contains('customDropDown')) {
            this.toggle = true;
        }
        else {
            this.toggle = false;
        }
    }

}
