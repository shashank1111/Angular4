﻿import { ElementRef, Component, OnInit } from '@angular/core';

import { SubCategoryListService } from '../services/subCategoryList.service';
import { SolutionListService } from '../services/solutionList.service';
import { SubCategoryVideo } from '../services/subCategoryVideo';
import { SubCategoryVideoService } from '../services/subCategoryVideo.service';
import { MessagingService } from '../services/messaging.service';
import { UtilsService } from '../services/utils.service';
import { environment } from '../../environments/environment';

@Component({
  selector: 'app-breadcrumb',
  templateUrl: './breadcrumb.component.html',
  styleUrls: ['./breadcrumb.component.less']
})

export class BreadcrumbComponent implements OnInit {

  firstItem: string;
  secondItem: string;
  thirdItem: string;
  forthItem: string;
  videoId: number;

  // Only first & thrid may have the hyper links
  firstItemUrl: string;
  thirdItemUrl: string;
  firstItemstate: string;
  thirdItemState: string;

  constructor(private _subcategoryDetailsService: SubCategoryListService,
    private _solutionService: SolutionListService,
    private _subCategoryVideoService: SubCategoryVideoService,
    private _utilsService: UtilsService,
    private _messagingService: MessagingService) { }

  ngOnInit() {
    this.videoId = this._utilsService.getUrlParamaterCaseInsensitive('videoId');
    this.getCurrentPage();

    this._messagingService.mainVideoLoaded$.subscribe(video => { this.secondItem = video.Title;
      });
  }

  getCurrentPage() {

    const currentUrl = location.href.toLowerCase();

    if (currentUrl.includes('video_gallery')) {
      this.firstItem = 'Video Gallery';
      return;
    }

    if (currentUrl.includes('video_player')) {
      this.firstItem = 'Video Gallery';
      this.firstItemstate = 'activeState';
      this.firstItemUrl = environment.videoGalleryPageUrl;
      return;
    }

    this._subcategoryDetailsService.getSubCategoryDetails()
      .subscribe(subcategoryDetails => {
        if (subcategoryDetails !== undefined) {
          this.firstItem = subcategoryDetails.Business_x0020_Function.Title;
          // TODO: Refactor using the 'undefined' itself rather than
          // 'null'
          if (subcategoryDetails.Category.Title !== undefined) {
            this.secondItem = subcategoryDetails.Category.Title;
          } else {
            this.secondItem = null;
          }
          this.firstItemUrl = '#';
          this.thirdItemUrl = '#';
          this.thirdItem = subcategoryDetails.Title;
          return;
        }
        else {
          this._solutionService.getSolution()
            .subscribe(solution => {
              if (solution !== undefined) {
                this.forthItem = solution.Title;
                this.thirdItem = solution.Sub_x0020_Category.Title;
                this._subcategoryDetailsService.getSolutionDetailsBySubCategory(solution.Sub_x0020_Category.Title)
                  .subscribe(subcategoryDetails => {
                    this.secondItem = subcategoryDetails.Category.Title;
                    if (subcategoryDetails.Business_x0020_Function.Title !== undefined) {
                      this.firstItem = subcategoryDetails.Business_x0020_Function.Title;
                    } else {
                      this.firstItem = null;
                    }
                    if (subcategoryDetails.PageUrl !== undefined) {
                      this.firstItemUrl = '#';
                      this.thirdItemUrl = subcategoryDetails.PageUrl;
                      this.thirdItemState = 'activeState';
                    }
                  });
              }
              return;
            });
        }
      });

    console.log('Breadcrumb error: could not identify the location to form the breadcrumb');

  }
}
