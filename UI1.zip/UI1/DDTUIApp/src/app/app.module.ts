﻿import { BrowserModule, DOCUMENT } from '@angular/platform-browser';
import { Inject, NgModule, ApplicationRef } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { HttpModule } from '@angular/http';

import { SolutionMatrixComponent } from './solutionsMatrix/solutions-matrix.component';
import { VideoGalleryComponent } from './video-gallery/video-gallery.component';
import { MainVideoComponent } from './main-video/main-video.component';
import { RecommendedVideoComponent } from './recommended-video/recommended-video.component';
import { PopularVideoComponent } from './popular-video/popular-video.component';
import { FilterVideoComponent } from './filter-video/filter-video.component';
import { BreadcrumbComponent } from './breadcrumb/breadcrumb.component';
import { RelatedContentComponent } from './related-content-video/related-content.component';
import { AdfsRefreshComponent } from './adfs-refresh/adfs-refresh.component';
import { AdvanceSearchComponent } from './advance-search/advance-search.component';

import { SearchComponent } from './search/search-component';
import { SearchHeadComponent } from './search/search-head-component';
import { ContactComponent } from './contacts/contact.component';
import { SubcategoryVideoComponent } from './subcategory-video/subcategory-video.component';
import { ShareLinkComponent } from './share-link/share-link.component';
import { LikeComponent } from './like/like.component';
import { VideoPagePlayerComponent } from './video-page-player/video-page-player.component';
import { VideoCommentComponent } from './video-comment/video-comment.component';
import { BuyingPatternsComponent } from './buying-patterns/buying-patterns.component'
import { AnalyticsDirective} from './analytics/analytics.directive';

import { VideoListService } from './services/videoList.service';
import { SubCategoryListService } from './services/subCategoryList.service';
import { SolutionListService } from './services/solutionList.service';
import { InstantFindService } from './services/instantfind.service';
import { ContactListService } from './services/contactList.service';
import { SubCategoryTitleService } from './services/subCategoryTitle.service';
import { SubCategoryVideoService } from './services/subCategoryVideo.service';
import { LikeVideoService } from './services/likeVideoService.service';
import { PageListService } from './services/pageList.service';
import { VideoCommentService } from './services/videoComment.service';
import { AnalyticsService} from './services/analytics.service';
import { DigestService } from './services/digest.service';
import { UtilsService } from './services/utils.service';
import { CommentsDatePipe } from './pipes/comments-date.pipe';
import { MessagingService } from './services/messaging.service';
import { BuyingPatternsService } from './services/buying-patterns.service';
import { PagerService } from './services/pagingService';
import { AdvanceSearchService } from './services/advanceSearch.service';
import { SafeHtmlPipe } from './pipes/safe-html.pipe';
import { FilterByBusinessFuntionPipe } from './pipes/filter-by-business-funtion.pipe';


@NgModule({
  declarations: [
    SolutionMatrixComponent,
    VideoGalleryComponent,
    MainVideoComponent,
    RecommendedVideoComponent,
    PopularVideoComponent,
    FilterVideoComponent,
    SearchComponent,
    SearchHeadComponent,
    ContactComponent,
    SubcategoryVideoComponent,
    ShareLinkComponent,
    BreadcrumbComponent,
    LikeComponent,
    VideoPagePlayerComponent,
    RelatedContentComponent,
    VideoCommentComponent,
    AnalyticsDirective,
    CommentsDatePipe,
      AdfsRefreshComponent,
      BuyingPatternsComponent,
      AdvanceSearchComponent,
      SafeHtmlPipe,
      FilterByBusinessFuntionPipe
  ],
  imports: [
    BrowserModule,
    FormsModule,
      HttpModule,
  ],
  providers: [AnalyticsService, InstantFindService, SubCategoryListService, SolutionListService, LikeVideoService,
      VideoListService, ContactListService, SubCategoryTitleService, SubCategoryVideoService,
      VideoCommentService, PageListService, DigestService, UtilsService, BuyingPatternsService, MessagingService, PagerService, AdvanceSearchService],
  entryComponents: [SearchComponent, SearchHeadComponent, BuyingPatternsComponent, VideoGalleryComponent, MainVideoComponent,
      RecommendedVideoComponent, PopularVideoComponent, LikeComponent,
      FilterVideoComponent, SolutionMatrixComponent, ContactComponent, SubcategoryVideoComponent,
      ShareLinkComponent, BreadcrumbComponent, VideoPagePlayerComponent, AdfsRefreshComponent, AdvanceSearchComponent]
})
export class AppModule {
  private browser_document;

  // BootStrap the Components only if corresponding declarations present in the DOM
  ngDoBootstrap(appRef: ApplicationRef) {
    if (this.browser_document.getElementsByTagName('app-main-search').length > 0) {
      appRef.bootstrap(SearchComponent);
    }
    if (this.browser_document.getElementsByTagName('app-head-search').length > 0) {
      appRef.bootstrap(SearchHeadComponent);
    }
    if (this.browser_document.getElementsByTagName('app-video-gallery').length > 0) {
      appRef.bootstrap(VideoGalleryComponent);
    }
    if (this.browser_document.getElementsByTagName('app-solutions-matrix').length > 0) {
      appRef.bootstrap(SolutionMatrixComponent);
    }
    if (this.browser_document.getElementsByTagName('app-share-link').length > 0) {
      appRef.bootstrap(ShareLinkComponent);
    }
    if (this.browser_document.getElementsByTagName('app-contacts').length > 0) {
      appRef.bootstrap(ContactComponent);
    }
    if (this.browser_document.getElementsByTagName('app-subcategory-video').length > 0) {
      appRef.bootstrap(SubcategoryVideoComponent);
    }
    if (this.browser_document.getElementsByTagName('app-video-page-player').length > 0) {
      appRef.bootstrap(VideoPagePlayerComponent);
    }
    if (this.browser_document.getElementsByTagName('app-breadcrumb').length > 0) {
      appRef.bootstrap(BreadcrumbComponent);
    }
    if (this.browser_document.getElementsByTagName('app-adfs-refresh').length > 0) {
      appRef.bootstrap(AdfsRefreshComponent);
    }
    if (this.browser_document.getElementsByTagName('app-buying-patterns').length > 0) {
        appRef.bootstrap(BuyingPatternsComponent);
    }
    if (this.browser_document.getElementsByTagName('advance-search').length > 0) {
        appRef.bootstrap(AdvanceSearchComponent);
    }
  }

  constructor( @Inject(DOCUMENT) private document: any) {
    this.browser_document = document;
  }
}
