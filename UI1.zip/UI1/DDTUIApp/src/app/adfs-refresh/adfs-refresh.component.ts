import { Component, OnInit } from '@angular/core';
import { environment } from '../../environments/environment';
import { DomSanitizer, SafeResourceUrl } from '@angular/platform-browser';


@Component({
  selector: 'app-adfs-refresh',
  templateUrl: './adfs-refresh.component.html',
  styleUrls: ['./adfs-refresh.component.css']
})
export class AdfsRefreshComponent implements OnInit {
  adfsRefreshUrl: SafeResourceUrl;
  constSetTimeOutAdfsRefresh = 1200000;

  constructor(private _sanitizer: DomSanitizer) { 
  }

  sanitizeUrl(url: string): SafeResourceUrl {
    return this._sanitizer.bypassSecurityTrustResourceUrl(url);
  }

  ngOnInit() {
    this.adfsRefreshUrl = this.sanitizeUrl(environment.getAdfsRefreshUrl.replace('HOSTNAME', location.hostname));

    // call Adfs Refresh URL for every 20mins to overcome access token expire issue
    setInterval(() => {
      this.adfsRefreshUrl = this.sanitizeUrl(environment.getAdfsRefreshUrl.replace('HOSTNAME', location.hostname));
    }, this.constSetTimeOutAdfsRefresh);

  }

}
