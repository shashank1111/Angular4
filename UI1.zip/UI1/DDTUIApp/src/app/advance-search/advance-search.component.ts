﻿import { Component, OnInit } from '@angular/core';
import { Observable } from 'rxjs/Observable';
import { Subject } from 'rxjs/Subject';
import 'rxjs/add/Operator/debounceTime';
import 'rxjs/add/Operator/distinctUntilChanged';
import { sortBy,Range, groupBy, uniq } from 'underscore';

import { environment } from '../../environments/environment';
import { AdvanceSearchService } from '../services/advanceSearch.service';
import { SubCategoryListService } from '../services/subCategoryList.service'
import { PagerService } from '../services/pagingService';
import { SafeHtmlPipe } from '../pipes/safe-html.pipe';
import { FilterByBusinessFuntionPipe } from '../pipes/filter-by-business-funtion.pipe'

@Component({
    selector: 'advance-search',
    templateUrl: './advance-search.component.html',
    styleUrls: ['./advance-search.component.less']
})
export class AdvanceSearchComponent implements OnInit {
    term$ = new Subject<string>();
    term: string = '';
    subCategories: any = [];
    resultsList: any = [];
    marketOffering: any = [];
    filteredList: any = [];

    //Collection of business function objects
    businessFunctionFacetList = [{ id: "CrossBusiness", value: "Cross-Business" }, { id: "AuditAssurance", value: "Audit & Assurance" }, { id: "Consulting", value: "Consulting" }, { id: "Advisory", value: "Advisory" }, { id: "Tax", value: "Tax" } ];

    //object of different types collection selected
    selectedItemsList = { contentType: [], businessFunctionType: [], marketOfferingType: [] };

    //Forming Filter Query
    query = { contentType: '', businessFunctionType: '', marketOfferingType: '' };

    filterQueryCollection: any = [];
    filterQuery: string = '';
    sortQuery: string = '';
    //For Maintaining state of filters
    //TODO : find approch for maintaining the states
    isChecked = { page: false, video: false };
    //Toggle filter group visibility
    isExpand = { businessType: false, contentType: false }
    showFiltersMobile: boolean = false;

    //object of different market offering collection selected according to  business function
    selectedMarketOfferingList = { CrossBusiness: [], Consulting: [], Advisory: [], Tax: [], AuditAssurance: [] };

    //Toggle visibility for business function
    showMOList = { CrossBusiness: false, Consulting: false, Advisory: false, Tax: false, AuditAssurance: false };

    //pagination object 
    pager: any = {};
    pageSize: number = 10;
    pageshown: number = 3;

    constructor(private _advanceSearchService: AdvanceSearchService, private _subCategoryListService: SubCategoryListService, private _pagerService: PagerService) { }

    ngOnInit() {
        // service call to get all subCategory alias market offering
        this._subCategoryListService.getSubCategoryList()
            .subscribe((results) => this.displayMarketOffering(results));

        //get current term search from href
        const searchterm = location.href.substring(location.href.indexOf('?k=') + 3).trim();
        let filterQuery = '';

        //observable to achieve reactive programming 
        this.term$
            .debounceTime(100)
            .switchMap(term => {
                return this._advanceSearchService.callAzureSearchService(term, filterQuery);

            }).subscribe(
            result => this.getResults(result)
            )

        this.term = decodeURIComponent(searchterm);
        this.term$.next(this.term);

    }

    //logic to display market offerings according to business function
    public displayMarketOffering(subCategories) {

        //underscrore sortBy and groupBy to create required object
        this.marketOffering = groupBy(sortBy(subCategories, (results) => {
            return results.Title
        }), (results) => {
            return results.Business_x0020_Function.Title;
        })
    }

    //assigning service response to class variable and set current page for pagination
    public getResults(result) {
        this.filteredList = [];
        this.resultsList = result;
        this.setPage(1);
    }

    public handleKeyUp(event) {
        //Remove old state of the results shown for last keyword searched
        if (this.term.length === 0) {
            this.filteredList = [];
            this.resultsList = [];
        }

        if (this.term.length > 0) {
            this.term$.next(this.term);
            this.sortQuery = '';
        }
    }

    //refreash search
    public refreshData(event) {
        this.term = '';
        this.isChecked.page = false;
        this.isChecked.video = false;
        this.selectedItemsList.contentType = [];
        this.selectedItemsList.businessFunctionType = [];
        this.selectedItemsList.marketOfferingType = [];
        this.selectedMarketOfferingList.CrossBusiness = [];
        this.selectedMarketOfferingList.Consulting = [];
        this.selectedMarketOfferingList.Advisory = [];
        this.selectedMarketOfferingList.Tax = [];
        this.selectedMarketOfferingList.AuditAssurance = [];
        this.filterQuery = '';

    }

    //set content type query
    public setContentTypeQuery(event) {
        let selectedOption = event.target.value;
        //logic to create selected content type collection
        if (event.target.checked === true) {
            this.selectedItemsList.contentType.push(<string>selectedOption);
        } else {
            this.selectedItemsList.contentType = this.selectedItemsList.contentType.filter(value => value !== selectedOption);
        }
        //set content type query
        this.setSubFilterQuery('contentType');
        //set azure qurey
        this.setAzureFilterQuery();
    }

    //set business function qurey
    public setBusinessFunctionQuery(event) {
        let selectOptionId = event.target.id;
        let selectOptionValue = event.target.value;
        //logic to set and updated selected business function and market offering collection
        if (event.target.checked === true) {

            this.selectedMarketOfferingList[selectOptionId] = [];
            this.marketOffering[selectOptionValue].map((marketOffers) => {
                this.selectedMarketOfferingList[selectOptionId].push(<string>marketOffers.Title);
            });
            if (this.selectedItemsList.businessFunctionType.indexOf(selectOptionValue) === -1) {
                this.selectedItemsList.businessFunctionType.push(<string>selectOptionValue);
            }
        } else {

            this.selectedMarketOfferingList[selectOptionId] = [];
            this.selectedItemsList.businessFunctionType = this.selectedItemsList.businessFunctionType.filter(value => value !== selectOptionId);
        }
        //set business function query
        this.setSubFilterQuery('businessFunctionType');
        //set market offering query
        this.setSubFilterQuery('marketOfferingType');
        this.setAzureFilterQuery();
    }

    //set market offering qurey
    public setMarketOfferingQuery(event, businessFunction) {
        let selectedOptionId = event.target.id;
        let seletedOptionValue = event.target.value;
        //logic to set and update market offering collection according to business function
        if (event.target.checked === true) {
            this.selectedMarketOfferingList[businessFunction].push(<string>seletedOptionValue);
        } else {
            this.selectedMarketOfferingList[businessFunction] = this.selectedMarketOfferingList[businessFunction].filter(value => value !== seletedOptionValue);
        }

        this.setSubFilterQuery('marketOfferingType');
        this.setAzureFilterQuery();
    }

    //close all market offeing selected according to business function
    public closeBusinessFuncQuery(businessFunction) {
        if (businessFunction === 'Cross-Business') {
            this.selectedItemsList.businessFunctionType = this.selectedItemsList.businessFunctionType.filter(value => value !== businessFunction);
            this.selectedMarketOfferingList['CrossBusiness'] = [];
        } else {
            //set and update business function and accordingly market offering
            this.selectedItemsList.businessFunctionType = this.selectedItemsList.businessFunctionType.filter(value => value !== businessFunction);
            this.selectedMarketOfferingList[businessFunction] = [];
        }

        this.setSubFilterQuery('businessFunctionType');
        this.setSubFilterQuery('marketOfferingType');
        this.setAzureFilterQuery();
    }

    public clearFilters() {
        this.isChecked.page = false;
        this.isChecked.video = false;
        this.selectedItemsList.contentType = [];
        this.selectedItemsList.businessFunctionType = [];
        this.selectedItemsList.marketOfferingType = [];
        this.selectedMarketOfferingList.CrossBusiness = [];
        this.selectedMarketOfferingList.Consulting = [];
        this.selectedMarketOfferingList.Advisory = [];
        this.selectedMarketOfferingList.Tax = [];
        this.selectedMarketOfferingList.AuditAssurance = [];
        this.filterQuery = '';
        this._advanceSearchService.callAzureSearchService(this.term, this.filterQuery)
            .subscribe(
            // set items to json response
            result => this.getResults(result)
            );
    }

    //set query according to selected type
    private setSubFilterQuery(currentType) {
        let currentTypeSelected = '';
        let currentQuerySelector = '';
        switch (currentType) {
            case 'contentType': currentTypeSelected = currentType;
                currentQuerySelector = 'contentType';
                break;
            case 'businessFunctionType': currentTypeSelected = currentType;
                currentQuerySelector = 'businessFunction';
                break;
            case 'marketOfferingType':
                this.selectedItemsList.marketOfferingType = this.selectedMarketOfferingList.CrossBusiness.concat(this.selectedMarketOfferingList.Consulting, this.selectedMarketOfferingList.Advisory, this.selectedMarketOfferingList.Tax, this.selectedMarketOfferingList.AuditAssurance);
                currentTypeSelected = currentType;
                currentQuerySelector = 'subCategory';
                break;
        }
        //set query logic 
        this.selectedItemsList[currentTypeSelected].map((selectContentType, index, arr) => {
            if (index < 1) {
                this.query[currentTypeSelected] = "(";
            }
            if (arr.length - 1 === index) {
                this.query[currentTypeSelected] += currentQuerySelector + " eq %27" + encodeURIComponent(selectContentType) + "%27)";
            } else {
                this.query[currentTypeSelected] += currentQuerySelector + " eq %27" + encodeURIComponent(selectContentType) + "%27 or ";
            }
        });

        if (this.selectedItemsList[currentTypeSelected].length < 1) {
            this.query[currentTypeSelected] = '';
        }
    }

    private setAzureFilterQuery() {
        let metaQuery: string = '';
        //create single collection for all queries
        if (this.query.contentType !== '')
            this.filterQueryCollection.push(this.query.contentType);

        if (this.query.businessFunctionType !== '')
            this.filterQueryCollection.push(this.query.businessFunctionType);

        if (this.query.marketOfferingType !== '')
            this.filterQueryCollection.push(this.query.marketOfferingType);

       this.filterQueryCollection.map((query, index, queryList) => {
           if (index === 0) {
               metaQuery += '&$filter=';
           }
            if (queryList.length - 1 === index) {
                metaQuery += query;
            } else {
                metaQuery += query + ' and '
            }
        })

        this.filterQueryCollection = [];

        this.search(metaQuery);
    }

    private search(metaQuery) {
        this.filterQuery = metaQuery;

        this._advanceSearchService.callAzureSearchService(this.term, this.filterQuery)
            .subscribe(
            // set items to json response
            result => this.getResults(result)
            );
    }

    public sortResults(event) {
        let selectedOrder = event.target.value;
        this.sortQuery = '';

        if (selectedOrder.length > 0)
            this.sortQuery = '&$orderby=siteLastModifiedOn ' + selectedOrder;

        this.setAzureFilterQuery();

    }

    public applyFiltersMobile() {
        this.setAzureFilterQuery();
        this.showFiltersMobile = false;
    }

    //Pagination
    setPage(page: number) {
        if (page < 1 || page > this.pager.totalPages) {
            return;
        }

        if (this.resultsList.value.length > 0) {
            // get pager object from service
            this.pager = this._pagerService.getPager(this.resultsList['@odata.count'], page, this.pageSize, this.pageshown);

            // get current page of items
            this.filteredList = this.resultsList.value.slice(this.pager.startIndex, this.pager.endIndex + 1);
        }

    }

    firstEllipses() {

        if (this.pager.startPage < this.pager.pages.length) {
            this.setPage(this.pager.startPage - 1);
        }
        else {
            const getPreviousSet = this.pager.pages[0] - Math.ceil(((this.pager.endPage + 1) - this.pager.startPage) / 2);
            this.setPage(getPreviousSet);
        }
    }

    lastEllipses() {
        if (this.pager.endPage + this.pager.pages.length - 1 > this.pager.totalPages) {
            this.setPage(this.pager.endPage + 1);
        }
        else {
            const getNextSet = this.pager.pages[this.pager.pages.length - 1] + Math.ceil(((this.pager.endPage + 1) - this.pager.startPage) / 2);
            this.setPage(getNextSet);
        }
    }
}