	#To Run & "C:\DDT\DeloitteDoesThat\Main\UI\CreatingDDTToolsCardList.ps1" "http://uscldsponnada03:2704/sites/PlayBook/" 
	
	#Creating DDT Tools Card List
	
	Add-PSSnapin Microsoft.SharePoint.PowerShell -EA SilentlyContinue
	# Get the SiteURL
	$spSite = get-spsite($args[0])
	$spListName = "DDT Tools Card"
	
	# Get the root web
	$spWeb = $spSite.RootWeb	
	$spList = $spWeb.Lists.TryGetList($spListName)
	$spTemplate = $spWeb.ListTemplates["Custom List"]
	
	#Check if List with specific name exists
	if($spList -eq $null)
	{
		# Creating DDT Tools Card List
		$spWeb.Lists.Add($spListName, $spListName, $spTemplate)
		Write-Host "Created Successfully the List DDT Tools Card"
		
		#Get Unit Card List
		$UnitCardList = $spWeb.Lists.TryGetList($spListName)
		
		#Add 'IsShown' - Choice Field
		$FieldName1="IsShown"
		$spFieldType = [Microsoft.SharePoint.SPFieldType]::Choice
		$IsRequired = $False
		$UnitCardList.Fields.Add($FieldName1, $spFieldType, $IsRequired)
		$UnitCardList.Fields[$FieldName1].Description = $FieldName1
		$UnitCardList.Fields[$FieldName1].update()
		$ChoiceField = $UnitCardList.Fields.GetField("IsShown") #Get the field
		$ChoiceField.Choices.Add("Yes")
		$ChoiceField.Choices.Add("No")
		$ChoiceField.DefaultValue = "N0"
		$ChoiceField.update()
		
		
		#Add 'Sub Category' - Lookup Field	
		$ParentListName="Sub Category"
		$ParentList = $spWeb.Lists.TryGetList($ParentListName)
		$ParentLookupColumnName="PageUrl"
		$FieldName2="PageUrl"
		$IsRequired = $False
		$ChildLookupColumn = $UnitCardList.Fields.AddLookup($FieldName2,$ParentList.id,$IsRequired)
		$ChildLookupColumn = $UnitCardList.Fields[$FieldName2]
		
		#Setup lookup Field property
		$ChildLookupColumn.LookupField = $ParentList.Fields[$ParentLookupColumnName]
		$ChildLookupColumn.Description = $FieldName2
		$ChildLookupColumn.update()
		$UnitCardList.Update()
		Write-Host "Added Coulmns IsShown and PageUrl Successfully to the List DDT Tools Card"
		
		#Adding IsShown and PageUrl to DDT Tools Card List Default View
		$spView = $UnitCardList.DefaultView
		$spFeild1 = $UnitCardList.Fields[$FieldName1]
		$spView.ViewFields.add($spFeild1)
		
		$spFeild3 = $UnitCardList.Fields[$FieldName2]
		$spView.ViewFields.add($spFeild3)
		$spView.Update()
		Write-Host "Added Coulmns $FieldName1 and $FieldName2 Successfully to the DDT Tools Card List Default View"

	}
	else
	{
		Write-Host "The $spListName List Already exist"
	}
	
	$spWeb.dispose()	
	
	