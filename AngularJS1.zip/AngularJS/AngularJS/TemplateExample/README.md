angular-dynamic-templates
=========================
http://onehungrymind.com/angularjs-dynamic-templates/
Illustrates how to use dynamic templates via a directive.